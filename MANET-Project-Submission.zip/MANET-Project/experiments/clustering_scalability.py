import json
import time
import statistics
import networkx as nx
import pandas as pd
import matplotlib.pyplot as plt

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"

sizes = [9, 25, 50, 100, 200]
seeds = [42, 43, 44, 45, 46]

rows = []
all_clusters = {}


def load_network(scenario, n, seed):

    filename = f"{scenario}_{n}_seed{seed}.json"

    with open(RESULTS / filename) as f:
        return json.load(f)


def build_graph(network):

    G = nx.Graph()

    for node in network["nodes"]:
        G.add_node(node["id"])

    for link in network["links"]:
        G.add_edge(
            link["source"],
            link["target"],
            loss=link["path_loss_db"]
        )

    return G


def create_clusters(G, scores):

    remaining = set(G.nodes)
    clusters = {}

    while remaining:

        head = max(
            remaining,
            key=lambda n: (scores[n], n)
        )

        members = (
            set(G.neighbors(head)) & remaining
        ) | {head}

        clusters[head] = sorted(members)

        remaining -= members

    return clusters


def traditional_clustering(G):

    return create_clusters(G, dict(G.degree()))


def adaptive_clustering(old, new, old_heads, threshold):

    max_degree = max(
        1, max(dict(new.degree()).values())
    )

    scores = {}

    for node in new.nodes:

        neighbors = set(new.neighbors(node))
        previous = set(old.neighbors(node))

        degree = len(neighbors) / max_degree

        quality = 0

        if neighbors:

            quality = sum(
                max(
                    0,
                    min(
                        1,
                        (threshold - new[node][n]["loss"]) / 10
                    )
                )
                for n in sorted(neighbors)
            ) / len(neighbors)

        common = neighbors & previous
        total = neighbors | previous

        stability = (
            len(common) / len(total)
            if total else 0
        )

        retention = (
            1 if node in old_heads and neighbors
            else 0
        )

        scores[node] = (
            0.3 * degree +
            0.3 * quality +
            0.3 * stability +
            0.1 * retention
        )

    return create_clusters(new, scores)


def get_assignments(clusters):

    assignments = {}

    for head, members in clusters.items():

        for member in members:
            assignments[member] = head

    return assignments


def membership_changes(initial, current):

    old = get_assignments(initial)
    new = get_assignments(current)

    return sum(
        old[node] != new[node]
        for node in old
    )


def retention_percentage(eligible, clusters):

    if not eligible:
        return float("nan")

    retained = eligible & set(clusters)

    return 100 * len(retained) / len(eligible)


def benchmark(function):

    times = []

    for _ in range(50):

        start = time.perf_counter()

        clusters = function()

        end = time.perf_counter()

        times.append((end - start) * 1000)

    return clusters, statistics.median(times)


for n in sizes:

    for seed in seeds:

        static = load_network("static", n, seed)
        mobile = load_network("mobile", n, seed)

        old = build_graph(static)
        new = build_graph(mobile)

        assert len(old) == n
        assert len(new) == n
        assert set(old.nodes) == set(new.nodes)
        assert static["threshold"] == mobile["threshold"]

        initial = traditional_clustering(old)

        old_heads = set(initial)

        eligible = {
            head for head in old_heads
            if new.degree(head) > 0
        }

        traditional, traditional_time = benchmark(
            lambda: traditional_clustering(new)
        )

        adaptive, adaptive_time = benchmark(
            lambda: adaptive_clustering(
                old,
                new,
                old_heads,
                mobile["threshold"]
            )
        )

        old_links = {
            frozenset(edge) for edge in old.edges
        }

        new_links = {
            frozenset(edge) for edge in new.edges
        }

        row = {
            "nodes": n,
            "seed": seed,
            "initial_clusters": len(initial),

            "traditional_clusters": len(traditional),
            "adaptive_clusters": len(adaptive),

            "traditional_retention_pct":
                retention_percentage(eligible, traditional),

            "adaptive_retention_pct":
                retention_percentage(eligible, adaptive),

            "traditional_membership_changes":
                membership_changes(initial, traditional),

            "adaptive_membership_changes":
                membership_changes(initial, adaptive),

            "traditional_time_ms": traditional_time,
            "adaptive_time_ms": adaptive_time,

            "static_links": len(old_links),
            "mobile_links": len(new_links),

            "lost_links": len(old_links - new_links),
            "added_links": len(new_links - old_links),

            "isolated_nodes": len(list(nx.isolates(new))),
            "connected_components":
                nx.number_connected_components(new)
        }

        rows.append(row)

        all_clusters[f"{n}_seed{seed}"] = {
            "initial": initial,
            "traditional": traditional,
            "adaptive": adaptive
        }

        print(
            f"Nodes={n} | Seed={seed} | "
            f"Traditional={row['traditional_retention_pct']:.2f}% | "
            f"SAAC={row['adaptive_retention_pct']:.2f}%"
        )


df = pd.DataFrame(rows)

assert len(df) == 25

df.to_csv(
    RESULTS / "clustering_scalability_multi_seed.csv",
    index=False
)

summary = df.drop(columns="seed").groupby("nodes").agg(
    ["mean", "std"]
)

summary.to_csv(
    RESULTS / "clustering_scalability_summary.csv"
)

with open(
    RESULTS / "scalable_clusters_multi_seed.json", "w"
) as f:

    json.dump(all_clusters, f, indent=4)


def plot_comparison(
    traditional_column,
    adaptive_column,
    title,
    ylabel,
    filename
):

    grouped = df.groupby("nodes")

    traditional_mean = grouped[traditional_column].mean()
    traditional_std = grouped[traditional_column].std()

    adaptive_mean = grouped[adaptive_column].mean()
    adaptive_std = grouped[adaptive_column].std()

    plt.figure(figsize=(8, 5))

    plt.errorbar(
        sizes,
        traditional_mean,
        yerr=traditional_std,
        marker="o",
        linewidth=2,
        capsize=5,
        color="#f59e0b",
        label="Traditional"
    )

    plt.errorbar(
        sizes,
        adaptive_mean,
        yerr=adaptive_std,
        marker="s",
        linewidth=2,
        capsize=5,
        color="#16a34a",
        label="SAAC"
    )

    plt.title(title, fontweight="bold")
    plt.xlabel("Number of Nodes")
    plt.ylabel(ylabel)
    plt.xticks(sizes)
    plt.grid(alpha=0.25)
    plt.legend()
    plt.tight_layout()

    plt.savefig(
        FIGURES / f"{filename}.png",
        dpi=300
    )

    plt.savefig(FIGURES / f"{filename}.pdf")

    plt.close()

    print("Saved:", filename)


plot_comparison(
    "traditional_retention_pct",
    "adaptive_retention_pct",
    "Cluster Head Retention",
    "Retention (%)",
    "scalability_retention"
)

plot_comparison(
    "traditional_clusters",
    "adaptive_clusters",
    "Number of Clusters",
    "Clusters",
    "scalability_clusters"
)

plot_comparison(
    "traditional_membership_changes",
    "adaptive_membership_changes",
    "Cluster Membership Changes",
    "Changed Nodes",
    "scalability_membership"
)

plot_comparison(
    "traditional_time_ms",
    "adaptive_time_ms",
    "Clustering Execution Time",
    "Time (ms)",
    "scalability_time"
)

print("\nFinal Average Results")
print("---------------------")

columns = [
    "traditional_retention_pct",
    "adaptive_retention_pct",
    "traditional_clusters",
    "adaptive_clusters",
    "traditional_membership_changes",
    "adaptive_membership_changes",
    "traditional_time_ms",
    "adaptive_time_ms"
]

print(
    df.groupby("nodes")[columns]
    .mean()
    .round(4)
    .to_string()
)

print("\nTotal scenarios:", len(df))
print("All scalability results saved successfully.")