from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"

FIGURES.mkdir(exist_ok=True)

df = pd.read_csv(RESULTS / "routing_comparison.csv")

modes = ["babel", "full", "traditional", "adaptive"]

labels = {
    "babel": "Babel",
    "full": "Full Graph",
    "traditional": "Traditional",
    "adaptive": "SAAC"
}

colors = {
    "babel": "#64748b",
    "full": "#2563eb",
    "traditional": "#f59e0b",
    "adaptive": "#16a34a"
}

assert len(df) == 20
assert df.groupby("mode").size().to_dict() == {
    mode: 5 for mode in modes
}

metrics = [
    "before_success_pct",
    "after_success_pct",
    "after_rtt_ms",
    "route_update_ms",
    "updated_routes"
]

summary = df.groupby("mode")[metrics].agg(["mean", "std"])

summary = summary.reindex(modes)

summary.to_csv(RESULTS / "routing_summary.csv")

print(summary.round(4))


def plot_metric(column, title, ylabel, filename,
                selected_modes, decimals=2):

    means = df.groupby("mode")[column].mean()
    stds = df.groupby("mode")[column].std()

    values = [means[m] for m in selected_modes]
    errors = [stds[m] for m in selected_modes]

    plt.figure(figsize=(8, 5))

    bars = plt.bar(
        [labels[m] for m in selected_modes],
        values,
        yerr=errors,
        capsize=5,
        color=[colors[m] for m in selected_modes],
        edgecolor="#333333",
        width=0.6
    )

    for bar, value, error in zip(bars, values, errors):
        plt.text(
            bar.get_x() + bar.get_width() / 2,
            value + error + max(values) * 0.025,
            f"{value:.{decimals}f}",
            ha="center",
            fontweight="bold"
        )

    plt.title(title, fontsize=14, fontweight="bold")
    plt.ylabel(ylabel)

    plt.ylim(
        0,
        max(v + e for v, e in zip(values, errors)) * 1.20
    )

    plt.grid(axis="y", alpha=0.25)
    plt.gca().set_axisbelow(True)

    plt.tight_layout()

    plt.savefig(FIGURES / f"{filename}.png", dpi=300)
    plt.savefig(FIGURES / f"{filename}.pdf")

    plt.close()

    print(f"Saved: {filename}")


plot_metric(
    "after_success_pct",
    "Packet Delivery Ratio After Mobility",
    "Packet Delivery Ratio (%)",
    "routing_pdr",
    modes
)

plot_metric(
    "updated_routes",
    "Routing Entry Updates",
    "Number of Updated Routes",
    "routing_updates",
    ["full", "traditional", "adaptive"],
    0
)

plot_metric(
    "route_update_ms",
    "Routing Update Processing Time",
    "Time (ms)",
    "routing_update_time",
    ["full", "traditional", "adaptive"]
)

plot_metric(
    "after_rtt_ms",
    "Average Round-Trip Time After Mobility",
    "RTT (ms)",
    "routing_rtt",
    modes,
    4
)

print("\nAll routing figures generated successfully.")