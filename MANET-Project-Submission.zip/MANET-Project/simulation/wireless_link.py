import mitsuba as mi

mi.set_variant("llvm_ad_mono_polarized")

import numpy as np
from sionna.rt import load_scene, PlanarArray
from sionna.rt import Transmitter, Receiver, PathSolver

scene = load_scene()
scene.frequency = 2.4e9

scene.tx_array = PlanarArray(
    num_rows=1,
    num_cols=1,
    pattern="iso",
    polarization="V"
)

scene.rx_array = scene.tx_array

tx = Transmitter(
    name="node_1",
    position=[0, 0, 1.5]
)

rx = Receiver(
    name="node_2",
    position=[10, 0, 1.5]
)

scene.add(tx)
scene.add(rx)

solver = PathSolver()

paths = solver(
    scene,
    max_depth=0,
    los=True
)

real, imag = paths.a

gain = np.sum(real.numpy()**2 + imag.numpy()**2)

path_loss = -10 * np.log10(gain)

print("MANET Wireless Simulation")
print("-------------------------")
print("Frequency: 2.4 GHz")
print("Distance: 10 m")
print("Path Loss:", round(float(path_loss), 2), "dB")