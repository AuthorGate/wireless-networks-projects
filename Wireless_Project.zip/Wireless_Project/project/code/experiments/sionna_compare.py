"""Compare distance graph, Sionna RT link-gain matrices and the analytic scene model
on the same layouts. Usage: python3 -I experiments/sionna_compare.py out.csv <dir with forest_* folders>
Sionna matrix mode uses link_min_gain_db = free-space gain at R (graph = distance graph minus blocked links)."""
import sys, os, csv, math, time
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_study as rs
SUP = sys.argv[2] if len(sys.argv) > 2 else "."
R, F = 18.0, 2.4e9
FSPL_R = -(20 * math.log10(4 * math.pi * R * F / 3e8))        # free-space gain at the nominal range
CH = {"distance": {"channel_model": "distance"}, "sionna": {"channel_model": "matrix"}, "scene_medium": {"channel_model": "scene", "tree_density_ha": 300.0, "link_margin_db": 0.0},
      "scene_dense": {"channel_model": "scene", "tree_density_ha": 600.0, "link_margin_db": 0.0}}
def job(a):
    ch, size, ss, th, sd, wind = a
    ov = dict(CH[ch])
    if ch == "sionna":
        ov.update(link_gain_csv=os.path.join(SUP, f"forest_{size}x{size}_s{ss}", "link_gain_forest.csv"), link_min_gain_db=FSPL_R + 0.05)
    # reuse the study runner: canopy label only selects tree density when channel_model=scene is not overridden
    r = rs.one((size, th, sd, "open", wind, ov))
    r.update(channel=ch, layout=f"{size}x{size}_s{ss}", wind=wind); return r
if __name__ == "__main__":
    jobs = [(ch, n, ss, th, sd, w) for ch in CH for n in (3, 4, 5) for ss in (11, 42) for th in (0, 90) for sd in range(15) for w in ("calm", "w20_fire", "w40_fire")]
    print(len(jobs), "runs", "FSPL_R", round(FSPL_R, 2), flush=True); t0 = time.time()
    with Pool(os.cpu_count()) as p:
        rows = p.map(job, jobs, chunksize=6)
    with open(sys.argv[1], "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print("done", round(time.time() - t0), "s", flush=True)
