"""Ablation (which physical term drives the loss) and 8x8 scaling.
Usage: python3 -I experiments/extra.py ablation.csv scaling.csv"""
import sys, os, csv, time
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_study as rs
ABL = {"full": {}, "no_trunk": {"trunk_loss_db": 0.0}, "no_crown": {"crown_radius_m": 0.01}, "neither": {"trunk_loss_db": 0.0, "crown_radius_m": 0.01}}
def job(a):
    tag, args, ov = a
    r = rs.one(args + (ov,)); r["variant"] = tag; return r
def dump(rows, path):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
if __name__ == "__main__":
    j1 = [(v, (4, th, sd, c, w), ABL[v]) for v in ABL for c in ("medium", "dense") for w in ("calm", "w40_fire+radio") for th in (0, 90) for sd in range(20)]
    j2 = [("g8", (8, 0, sd, c, w), {}) for c in rs.CANOPY for w in ("calm", "w40_fire+radio") for sd in range(10)]
    t0 = time.time()
    with Pool(os.cpu_count()) as p:
        dump(p.map(job, j1, chunksize=4), sys.argv[1]); print("ablation", round(time.time() - t0), flush=True)
        dump(p.map(job, j2, chunksize=1), sys.argv[2]); print("scaling", round(time.time() - t0), flush=True)
