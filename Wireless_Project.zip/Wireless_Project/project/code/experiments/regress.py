import sys, importlib, json, os
# usage: python3 regress.py <original_project_dir> [<modified_project_dir>]
ORIG = sys.argv[1]
MOD = sys.argv[2] if len(sys.argv) > 2 else os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def load(root):
    for k in [k for k in sys.modules if k=='sim' or k.startswith('sim.')]: del sys.modules[k]
    sys.path.insert(0,root)
    from sim.config import Config; from sim.engine import Engine
    sys.path.remove(root)
    return Config,Engine
def run(root,**kw):
    C,E=load(root); e=E(C(**kw))
    for _ in e.stream(): pass
    r=e.summarize(); return {k:r[k] for k in sorted(r) if isinstance(r[k],(int,float))}
cases=[dict(seed=s,mode="ours",grid_rows=n,grid_cols=n,theta_deg=th,speed_true=sp,**w)
  for s in(0,3) for n in(3,4,5) for th in(0,90) for sp in(1.0,2.0) for w in({},{'fire_shape':'ellipse','wind_kmh':20.0})]
bad=0
for c in cases:
    a=run(ORIG,**c); b=run(MOD,**c)
    if a!=b: bad+=1; print('DIFF',c)
print('cases',len(cases),'different',bad)
