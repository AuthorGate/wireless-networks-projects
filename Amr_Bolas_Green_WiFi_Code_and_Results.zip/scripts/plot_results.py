from __future__ import annotations

import json
from pathlib import Path
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
summary = json.loads((RESULTS / "summary.json").read_text(encoding="utf-8"))
labels = ["All APs always on", "Traffic-aware policy"]
values = [summary["baseline_energy_wh"], summary["proposed_energy_wh"]]
fig, ax = plt.subplots(figsize=(6.0, 3.5))
bars = ax.bar(labels, values, color=["#356A8A", "#2A9D8F"], width=0.58)
ax.set_ylabel("Energy over 2.25 hours (Wh)", fontsize=12)
ax.set_title("Ruckus H550 reference scenario", fontsize=12, pad=5)
ax.set_ylim(0, max(values) * 1.22)
ax.grid(axis="y", alpha=0.22)
ax.set_axisbelow(True)
ax.spines[["top", "right"]].set_visible(False)
ax.tick_params(axis="both", labelsize=10)
for bar, value in zip(bars, values):
    ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height(), f"{value:.3f} Wh", ha="center", va="bottom", fontsize=10)
ax.text(0.5, max(values) * 1.12,
        f"Estimated difference: {summary['estimated_energy_saved_wh']:.3f} Wh ({summary['estimated_saving_percent']:.2f}%)",
        ha="center", va="center", fontsize=9.5)
fig.tight_layout()
fig.savefig(RESULTS / "energy_comparison.png", dpi=240, facecolor="white")
