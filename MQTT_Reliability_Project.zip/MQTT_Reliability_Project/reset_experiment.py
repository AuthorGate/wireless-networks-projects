
import sqlite3

databases = {
    "mqtt_buffer.db": "messages",
    "received_messages.db": "received"
}

print("Resetting experiment data...")

for filename, table in databases.items():
    try:
        connection = sqlite3.connect(filename)

        # Check if the table exists
        exists = connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
            (table,)
        ).fetchone()

        if exists:
            count = connection.execute(
                f"SELECT COUNT(*) FROM {table}"
            ).fetchone()[0]

            connection.execute(f"DELETE FROM {table}")
            connection.commit()

            print(f"Cleared {count} records from {filename}")
        else:
            print(f"No table found in {filename}")

        connection.close()

    except sqlite3.Error as error:
        print(f"Database error in {filename}: {error}")

print("Experiment reset completed!")

