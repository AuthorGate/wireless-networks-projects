import json
import time
import argparse
import subprocess
import networkx as nx

from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

TABLE = "200"
PREFIX = "fdef:17a0:ffb1:300::/64"
PRIORITY = "1000"

parser = argparse.ArgumentParser()

parser.add_argument("--time", type=int, default=15)

parser.add_argument(
    "--mode",
    choices=["babel", "full", "traditional", "adaptive"],
    default="adaptive"
)

parser.add_argument(
    "--nodes",
    type=int,
    choices=[9, 25, 50],
    default=9
)

args = parser.parse_args()

start = time.perf_counter()

start = time.perf_counter()

if args.nodes == 9:
    network_dir = ROOT / "results"
else:
    network_dir = (
        ROOT / "results" / "large_routing"
        / str(args.nodes)
    )

if args.mode in ["full", "babel"]:

    with open(network_dir / f"urban_t{args.time}.json") as f:
        network = json.load(f)

else:

    with open(network_dir / "routing_backbones.json") as f:
        data = json.load(f)

    snapshot = next(
        s for s in data if s["time"] == args.time
    )

    network = snapshot[args.mode]

def run(node, *args):

    return subprocess.check_output(
        ["ip", "-n", "ns-" + node, *args],
        text=True
    )


G = nx.Graph()

G.add_nodes_from(
    node["id"] for node in network["nodes"]
)

G.add_edges_from(
    (link["source"], link["target"])
    for link in network["links"]
)

addresses = {}
local_addresses = {}
existing_rules = {}

for node in G.nodes:

    output = run(
        node,
        "-j", "-6", "addr", "show",
        "dev", "uplink"
    )

    for interface in json.loads(output):

        for address in interface["addr_info"]:

            if address["scope"] == "global":
                addresses[node] = address["local"]

            elif address["scope"] == "link":
                local_addresses[node] = address["local"]

    if node not in addresses or node not in local_addresses:
        raise ValueError("Missing address: " + node)

    rules = run(node, "-6", "rule", "show")

    matching = [
        line for line in rules.splitlines()
        if line.startswith(PRIORITY + ":")
    ]

    for line in matching:

        if PREFIX not in line or "lookup 200" not in line:
            raise ValueError("Routing priority conflict")

    existing_rules[node] = bool(matching)


if args.mode == "babel":

    for node in G.nodes:

        if existing_rules[node]:

            run(
                node,
                "-6", "rule", "del",
                "priority", PRIORITY,
                "to", PREFIX,
                "lookup", TABLE
            )

    print("Babel Routing Activated")
    raise SystemExit(0)


if not nx.is_connected(G):
    raise ValueError("Network is disconnected")


def current_routes(node):

    result = subprocess.run(
        [
            "ip", "-n", "ns-" + node,
            "-j", "-6", "route", "show",
            "table", TABLE
        ],
        capture_output=True,
        text=True
    )

    if result.returncode != 0:

        if "FIB table does not exist" in result.stderr:
            return {}

        raise RuntimeError(result.stderr)

    routes = {}

    for route in json.loads(result.stdout):

        destination = route.get("dst", "").split("/")[0]

        routes[destination] = route.get("gateway")

    return routes


updated = 0
unchanged = 0
total_routes = 0

for source in G.nodes:

    existing = current_routes(source)

    paths = nx.single_source_shortest_path(
        G, source
    )

    for destination, path in paths.items():

        if source == destination:
            continue

        target = addresses[destination]

        next_hop = local_addresses[path[1]]

        total_routes += 1

        if existing.get(target) == next_hop:

            unchanged += 1
            continue

        run(
            source,
            "-6", "route", "replace",
            target + "/128",
            "via", next_hop,
            "dev", "uplink",
            "table", TABLE
        )

        updated += 1

    print("Processed node:", source)


for node in G.nodes:

    if not existing_rules[node]:

        run(
            node,
            "-6", "rule", "add",
            "priority", PRIORITY,
            "to", PREFIX,
            "lookup", TABLE
        )


elapsed = (time.perf_counter() - start) * 1000

print("\nAdaptive Routing Update")
print("--------------------------")
print("Mode:", args.mode)
print("Time snapshot:", args.time)
print("Total nodes:", G.number_of_nodes())
print("Selected links:", G.number_of_edges())
print("Total routes:", total_routes)
print("Updated routes:", updated)
print("Unchanged routes:", unchanged)
print("Processing time:", round(elapsed, 2), "ms")

print("\nRoute verification:")

print(
    run(
        "0000",
        "-6", "route", "get",
        addresses["0008"]
    )
)

print("Routing Activated")