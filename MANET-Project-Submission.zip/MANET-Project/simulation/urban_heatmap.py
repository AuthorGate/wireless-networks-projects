import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import sionna.rt as rt
import json

from pathlib import Path
from sionna.rt import load_scene, Camera
from sionna.rt import Transmitter, PlanarArray
from sionna.rt import RadioMapSolver

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/urban_mobility.json") as f:
    data = json.load(f)

scene = load_scene(
    rt.scene.simple_street_canyon,
    merge_shapes=False
)

scene.frequency = data["frequency"]

scene.tx_array = PlanarArray(
    num_rows=1,
    num_cols=1,
    pattern="iso",
    polarization="V"
)

node = data["snapshots"][0]["nodes"][0]

scene.add(Transmitter(
    name="node_0000",
    position=[
        node["x"],
        node["y"],
        node["z"]
    ],
    power_dbm=10,
    display_radius=2
))

solver = RadioMapSolver()

radio_map = solver(
    scene,
    center=[0, 0, 1.5],
    orientation=[0, 0, 0],
    size=[186, 120],
    cell_size=[2, 2],
    samples_per_tx=1000000,
    max_depth=3,
    los=True,
    specular_reflection=True,
    diffuse_reflection=False,
    refraction=False,
    seed=42
)

camera = Camera(
    position=[140, -160, 220],
    look_at=[0, 0, 0]
)

scene.render_to_file(
    camera=camera,
    radio_map=radio_map,
    rm_metric="rss",
    rm_tx=0,
    rm_vmin=-100,
    rm_vmax=-40,
    rm_cmap="viridis",
    filename=str(
        ROOT / "figures/urban_heatmap_3d.png"
    ),
    resolution=(1600, 1000),
    num_samples=128,
    show_devices=True,
    show_orientations=False
)

camera_top = Camera(
    position=[0, -0.1, 250],
    look_at=[0, 0, 0]
)

scene.render_to_file(
    camera=camera_top,
    radio_map=radio_map,
    rm_metric="rss",
    rm_tx=0,
    rm_vmin=-100,
    rm_vmax=-40,
    rm_cmap="viridis",
    filename=str(
        ROOT / "figures/urban_heatmap_top.png"
    ),
    resolution=(1600, 1000),
    num_samples=128,
    show_devices=True,
    show_orientations=False
)

print("Urban Radio Coverage Map Created")
print("Frequency: 2.4 GHz")
print("Transmit Power: 10 dBm")
print("Cell Size: 2 x 2 m")
print("Saved: figures/urban_heatmap_3d.png")
print("Saved: figures/urban_heatmap_top.png")