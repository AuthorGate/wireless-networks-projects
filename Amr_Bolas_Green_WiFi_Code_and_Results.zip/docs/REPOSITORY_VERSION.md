# Repository snapshot used in the tutorial

- Repository: <https://github.com/openwrt/packages>
- Selected package: `net/wifischedule`
- Branch snapshot: `master`
- Pinned commit: `1ac54403af4a7b0f2743e92bbe7f2c5fe17a61df`
- Commit date: 2026-11-18 10:32:32 UTC+02:00
- Checked out and inspected: 2026-11-18

The commit-pinned source links are used in the IEEE article bibliography. The important package paths within that commit are:

- `net/wifischedule/README.md`
- `net/wifischedule/Makefile`
- `net/wifischedule/net/etc/init.d/wifi_schedule`
- `net/wifischedule/net/usr/bin/wifi_schedule.sh`
- `net/wifischedule/net/etc/config/wifi_schedule`

To reproduce the checkout on Ubuntu or WSL:

```sh
git clone --depth 1 --filter=blob:none --sparse \
  https://github.com/openwrt/packages.git openwrt-packages
cd openwrt-packages
git fetch --depth 1 origin 1ac54403af4a7b0f2743e92bbe7f2c5fe17a61df
git checkout --detach 1ac54403af4a7b0f2743e92bbe7f2c5fe17a61df
git sparse-checkout set net/wifischedule
git rev-parse HEAD
```

The final command should print the pinned commit above. The article studies this upstream package; the companion Python code is separate and does not modify it.
