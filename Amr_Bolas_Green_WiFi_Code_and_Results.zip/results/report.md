# Traffic-aware Green Wi-Fi evaluation

> IMPORTANT: This run uses the supplied trace and configured power assumptions. It is not a field measurement.

- Time windows: 9
- Access points: 3
- Baseline estimated energy: 38.070 Wh
- Proposed estimated energy: 37.685 Wh
- Estimated energy saved: 0.385 Wh (1.01%)
- Sleep recommendations: 7

## Decisions

| Time | AP | Action | Reason |
|---|---|---|---|
| 2026-10-15 22:00:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-15 22:00:00 | AP-2 | KEEP_ON | waiting for stable low demand (1/3) |
| 2026-10-15 22:00:00 | AP-3 | KEEP_ON | waiting for stable low demand (1/3) |
| 2026-10-15 22:15:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-15 22:15:00 | AP-2 | KEEP_ON | waiting for stable low demand (2/3) |
| 2026-10-15 22:15:00 | AP-3 | KEEP_ON | waiting for stable low demand (2/3) |
| 2026-10-15 22:30:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-15 22:30:00 | AP-2 | KEEP_ON | minimum active AP floor would be violated |
| 2026-10-15 22:30:00 | AP-3 | SLEEP_RECOMMENDED | low demand persisted for 3 windows; backup coverage and capacity checks passed |
| 2026-10-15 22:45:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-15 22:45:00 | AP-2 | KEEP_ON | minimum active AP floor would be violated |
| 2026-10-15 22:45:00 | AP-3 | SLEEP_RECOMMENDED | low demand persisted for 4 windows; backup coverage and capacity checks passed |
| 2026-10-15 23:00:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; channel load reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-15 23:00:00 | AP-2 | KEEP_ON | minimum active AP floor would be violated |
| 2026-10-15 23:00:00 | AP-3 | SLEEP_RECOMMENDED | low demand persisted for 5 windows; backup coverage and capacity checks passed |
| 2026-10-15 23:15:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; channel load reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-15 23:15:00 | AP-2 | KEEP_ON | minimum active AP floor would be violated |
| 2026-10-15 23:15:00 | AP-3 | SLEEP_RECOMMENDED | low demand persisted for 6 windows; backup coverage and capacity checks passed |
| 2026-10-15 23:30:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; channel load reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-15 23:30:00 | AP-2 | KEEP_ON | traffic reached wake threshold; channel load reached wake threshold |
| 2026-10-15 23:30:00 | AP-3 | SLEEP_RECOMMENDED | low demand persisted for 7 windows; backup coverage and capacity checks passed |
| 2026-10-15 23:45:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-15 23:45:00 | AP-2 | KEEP_ON | waiting for stable low demand (1/3) |
| 2026-10-15 23:45:00 | AP-3 | SLEEP_RECOMMENDED | low demand persisted for 8 windows; backup coverage and capacity checks passed |
| 2026-10-16 00:00:00 | AP-1 | KEEP_ON | protected client is connected; traffic reached wake threshold; backup signal is insufficient; no alternate AP is defined |
| 2026-10-16 00:00:00 | AP-2 | KEEP_ON | waiting for stable low demand (2/3) |
| 2026-10-16 00:00:00 | AP-3 | SLEEP_RECOMMENDED | low demand persisted for 9 windows; backup coverage and capacity checks passed |

## Safety note

The software is advisory-only. It does not switch off an AP. Any real radio shutdown requires a controlled maintenance window, verified client migration, a protected-device check, a minimum-coverage check, and an operator-approved rollback plan.
