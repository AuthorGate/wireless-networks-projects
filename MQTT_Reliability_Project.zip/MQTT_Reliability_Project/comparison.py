
import csv
import matplotlib.pyplot as plt

# Observations from the broker outage experiment
systems = ["Basic MQTT", "Reliable MQTT"]

observations = [
    "Connection failed during outage",
    "Messages buffered and delivered after recovery"
]

# Save the observed comparison
with open("comparison_results.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["System", "Observed Behavior"])
    for system, observation in zip(systems, observations):
        writer.writerow([system, observation])

# Measured results for Reliable MQTT
total_messages = 20
received_messages = 20
delivery_rate = received_messages / total_messages * 100

# Visualize observed behaviors
fig, ax = plt.subplots(figsize=(10, 5))

ax.axis("off")

table = ax.table(
    cellText=[
        ["Connection failed", "No automatic delivery observed"],
        ["Buffered and retried", "20/20 messages delivered (100%)"]
    ],
    rowLabels=systems,
    colLabels=["During Broker Outage", "After Broker Recovery"],
    cellLoc="center",
    loc="center"
)

table.auto_set_font_size(False)
table.set_fontsize(10)
table.scale(1, 2.5)

plt.title("Basic vs Reliable MQTT - Outage Experiment", pad=25)
plt.tight_layout()
plt.savefig("mqtt_comparison.png", dpi=300, bbox_inches="tight")
plt.show()

print("===== MQTT COMPARISON =====")
print("Basic MQTT: Connection failed during broker outage.")
print("Reliable MQTT: 20/20 messages delivered after recovery.")
print(f"Reliable MQTT Delivery Rate: {delivery_rate:.2f}%")
print("Files saved: comparison_results.csv, mqtt_comparison.png")

