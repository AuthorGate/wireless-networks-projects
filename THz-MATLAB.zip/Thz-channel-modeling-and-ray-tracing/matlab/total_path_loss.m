%% George Alfred Mensah - Total Path Loss Analysis in THz Band
clc(); clear();
close("all");

%% Load Data
load('../data/molecular_absorption.mat'); 
%% Parameters
distances = [1, 10, 100]; 
c = 3e8; 
constant_term = 20 * log10(4 * pi / c); 

%% Define Custom Colors (Same as Previous Plots)
light_blue = [0.4, 0.6, 1.0]; 
orange = [1.0, 0.6, 0.2]; 
light_green = [0.6, 1.0, 0.6]; 
colors = {light_blue, orange, light_green}; 

%% Convert Frequency to THz
f_THz = f / 1e12; 

%% Compute Spreading Loss
spreading_loss = zeros(length(f), length(distances));

for i = 1:length(distances)
    d = distances(i);
    spreading_loss(:, i) = 20 * log10(d) + 20 * log10(f) + constant_term; % Spreading loss in dB
end

%% Compute Molecular Absorption Loss
absorption_loss = zeros(length(f), length(distances));

for i = 1:length(distances)
    d = distances(i);
    absorption_loss(:, i) = 10 * log10(exp(k * d)); % Molecular absorption loss in dB
end

%% Compute Total Path Loss
total_path_loss = spreading_loss + absorption_loss;

%% Graph
figure;
hold on;

%% Plot for each distance with consistent colors
for i = 1:length(distances)
    plot(f_THz, total_path_loss(:, i), 'LineWidth', 1.5, 'Color', colors{i}, 'DisplayName', sprintf('%d meters', distances(i)));
end

%% Display graph
xlabel('Frequency (THz)');
ylabel('Total Path Loss (dB)');
title('Total Path Loss in the THz Band');
legend show;
xlim([0.1, 10]); 
%ylim([min(total_path_loss(:)), max(total_path_loss(:))]); 
ylim([0, 1000]);
grid on;
hold off;