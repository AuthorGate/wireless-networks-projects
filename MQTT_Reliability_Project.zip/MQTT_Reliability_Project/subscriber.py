
import json
import paho.mqtt.client as mqtt

BROKER = "localhost"
PORT = 1883
TOPIC = "iot/temperature"


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("Subscriber connected successfully!")
        client.subscribe(TOPIC, qos=1)
        print("Waiting for temperature messages...")
    else:
        print("Connection failed:", reason_code)


def on_message(client, userdata, message):
    data = json.loads(message.payload.decode("utf-8"))

    print("---------------------------")
    print("Message ID:", data["id"])
    print("Temperature:", data["temperature"], "°C")
    print("QoS:", message.qos)
    print("---------------------------")


client = mqtt.Client(
    callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
    client_id="temperature_receiver"
)

client.on_connect = on_connect
client.on_message = on_message

try:
    client.connect(BROKER, PORT, 60)
    print("Starting MQTT Subscriber...")
    client.loop_forever()

except KeyboardInterrupt:
    print("\nSubscriber stopped.")

except OSError as e:
    print("Connection error:", e)

finally:
    client.disconnect()
