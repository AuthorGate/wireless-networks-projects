// run_functions.js -- executes the flow's function nodes with a mocked Node-RED runtime.
// usage: node run_functions.js <path/to/flow.json> <engine_port>
const fs = require("fs");
const flow = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const port = process.argv[3];
const byName = n => flow.find(x => x.type === "function" && x.name === n);

function run(name, msg, env = {}, ctx = {}) {
  const store = ctx;
  const statusLog = [];
  const flowCtx = { get: k => store[k], set: (k, v) => { store[k] = v; } };
  const envObj = { get: k => env[k] };
  const nodeObj = { status: s => statusLog.push(s), warn() {}, error() {} };
  const fn = new Function("msg", "node", "flow", "context", "env", "global", byName(name).func);
  return { out: fn(msg, nodeObj, flowCtx, flowCtx, envObj, flowCtx), store, statusLog };
}
let failures = 0;
const check = (n, c) => { if (!c) failures++; console.log((c ? "[PASS] " : "[FAIL] ") + n); };

(async () => {
  // 1. URL builder
  let r = run("build engine URL", { req: { params: { endpoint: "state" }, query: { protocol: "LEACH", seed: "0", n: "100", round: "10" } } });
  check("URL builder forwards query string to the engine",
        r.out[0] && r.out[0].url === "http://127.0.0.1:8000/api/state?protocol=LEACH&seed=0&n=100&round=10" && r.out[1] === null);
  r = run("build engine URL", { req: { params: { endpoint: "state" }, query: {} } }, { ENGINE_URL: "http://10.0.0.5:9000" });
  check("ENGINE_URL environment variable is respected", r.out[0].url === "http://10.0.0.5:9000/api/state");
  for (const bad of ["../etc/passwd", "admin", ""]) {
    r = run("build engine URL", { req: { params: { endpoint: bad }, query: {} } });
    check("endpoint '" + bad + "' is rejected with 404", r.out[0] === null && r.out[1].statusCode === 404);
  }
  // 1b. gateway emulation: every endpoint the dashboard uses, through the URL builder, must return the engine's data
  const html = fs.readFileSync(require("path").join(__dirname, "..", "dashboard", "index.html"), "utf8");
  const used = [...new Set([...html.matchAll(/api\("(\w+)"/g)].map(m => m[1]))];
  const allowed = [...byName("build engine URL").func.match(/const allowed = \[(.*?)\]/)[1].matchAll(/"(\w+)"/g)].map(m => m[1]);
  for (const name of used) {
    check("dashboard endpoint '" + name + "' is whitelisted in the Node-RED gateway", allowed.includes(name));
    const q = { protocol: "LEACH", seed: "0", n: "100", round: "3", limit: "3" };
    const built = run("build engine URL", { req: { params: { endpoint: name }, query: q } }).out[0];
    const viaGateway = await (await fetch(built.url.replace("http://127.0.0.1:8000", "http://127.0.0.1:" + port))).json();
    const direct = await (await fetch("http://127.0.0.1:" + port + "/api/" + name + "?" + new URLSearchParams(q))).json();
    check("gateway URL for '" + name + "' returns the same JSON as the engine", JSON.stringify(viaGateway) === JSON.stringify(direct));
  }
  // 2. engine-down message
  r = run("502 message", {});
  check("engine-down function returns HTTP 502 with a help text", r.out.statusCode === 502 && /server\.py/.test(r.out.payload.error));
  r = run("drop engine headers", { statusCode: "ECONNREFUSED", payload: "Error: connect ECONNREFUSED : http://x" });
  check("failed request (string statusCode) becomes a clean 502 JSON message", r.out.statusCode === 502 && /server\.py/.test(r.out.payload.error));
  r = run("answer only once", { res: { _res: { headersSent: true } }, payload: 1 });
  check("guard drops a second answer when headers were already sent", r.out === null);
  r = run("answer only once", { res: { _res: { headersSent: false, writableEnded: false } }, payload: 1 });
  check("guard lets the first answer through", r.out && r.out.payload === 1);
  r = run("answer only once", { payload: 1 });
  check("guard tolerates messages without res", r.out && r.out.payload === 1);
  r = run("build engine URL", { req: { params: { endpoint: "state" }, query: {} } });
  check("URL builder no longer sets msg.method (removes the Node-RED warning)", r.out[0].method === undefined);
  r = run("drop engine headers", { headers: { "content-length": "999" }, payload: { a: 1 }, statusCode: 400 });
  check("engine headers are removed but status code and payload are kept",
        r.out.headers === undefined && r.out.statusCode === 400 && r.out.payload.a === 1);
  // 3. Flow 2 pieces, one by one
  const B = "http://127.0.0.1:8000";
  r = run("prepare step", { payload: 1 });
  check("prepare step builds the POST URL (5 h default) and removes the body", r.out.url === B + "/api/live/step?steps=5" && r.out.payload === undefined && r.out.method === undefined);
  r = run("prepare step", {}, { STEP: "24", ENGINE_URL: "http://10.0.0.5:9000" });
  check("STEP and ENGINE_URL environment variables are respected", r.out.url === "http://10.0.0.5:9000/api/live/step?steps=24");
  r = run("prepare reset", { topic: "LEACH" }, { LAYOUT: "random", SEED: "3", N: "40" });
  check("prepare reset uses the protocol on the button and the environment settings",
        r.out.url === B + "/api/live/reset?protocol=LEACH&layout=random&seed=3&n=40&source=node-red" && r.out.method === undefined);
  const stepResp = { round: 100, rounds: 900, alive: 90, coverage: 90, alerts: [{ node: 1, type: "low", level: 10 }, { node: 2, type: "overflow", level: 100 }], wrapped: false };
  const c2 = {};
  r = run("detect NEW alerts", { payload: stepResp }, {}, c2);
  check("first tick reports every current alert (2)", r.out && r.out.payload.new_alerts.length === 2);
  r = run("detect NEW alerts", { payload: stepResp }, {}, c2);
  check("identical second tick reports nothing (no duplicates)", r.out === null);
  r = run("detect NEW alerts", { payload: { ...stepResp, alerts: stepResp.alerts.concat([{ node: 3, type: "low", level: 5 }]) } }, {}, c2);
  check("a later tick reports only the 1 NEW alert", r.out && r.out.payload.new_alerts.length === 1 && /Tank #3 LOW/.test(r.out.payload.new_alerts[0]));
  run("detect NEW alerts", { payload: { ...stepResp, wrapped: true } }, {}, c2);
  check("when a new demo run starts the alert memory is cleared", Object.keys(c2.alerted).length === 0);
  r = run("detect NEW alerts", { payload: { error: "x" } }, {}, {});
  check("error payload from the engine is ignored safely", r.out === null);
  r = run("build notification", { payload: { hour: 5, nodes_alive: 9, coverage_pct: 9, new_alerts: ["Tank #1 LOW (10 %)", "Tank #2 LOW (9 %)", "Tank #3 LOW (8 %)", "Tank #4 LOW (7 %)"] } });
  check("notification: one URL-encoded message, 3 shown + '(+1 more)', report kept for the debug node",
        r.out.url.startsWith(B + "/api/notify?hour=5&source=node-red&text=") && decodeURIComponent(r.out.url).includes("(+1 more)") &&
        r.out.report.hour === 5 && r.out.payload === undefined);

  // 4. END-TO-END Flow 2 against the real engine (the http request nodes are emulated with fetch + POST)
  const post = async m => { const x = await fetch(m.url.replace(B, "http://127.0.0.1:" + port), { method: "POST" }); m.statusCode = x.status; m.payload = await x.json(); return m; };
  const E = { LAYOUT: "random", SEED: "2", N: "60", STEP: "7" }, fctx = {};
  let m = await post(run("prepare reset", { topic: "PEGASIS-E" }, E, fctx).out);
  check("pressing 'START live: PEGASIS-E' starts a live session in the engine", m.statusCode === 200 && m.payload.protocol === "PEGASIS-E" && m.payload.round === 0);
  let sent = 0; const texts = [];
  for (let i = 0; i < 40; i++) {
    m = await post(run("prepare step", {}, E, fctx).out);
    const d = run("detect NEW alerts", m, E, fctx).out;
    if (d) { const nm = run("build notification", d, E, fctx).out; await post(nm); sent++; texts.push(decodeURIComponent(nm.url.split("text=")[1])); }
  }
  // PAUSE / RESUME buttons
  m = await post(run("prepare pause", { topic: "pause" }, E, fctx).out);
  check("PAUSE button pauses the engine's live clock", m.payload.paused === true);
  const tick = await post(run("prepare step", {}, E, fctx).out);
  check("while paused a tick does not move the clock and 'detect NEW alerts' ignores the answer",
        tick.payload.paused === true && tick.payload.round === 280 && run("detect NEW alerts", tick, E, {}).out === null);
  const frozen = await post({ url: B + "/api/live/step?steps=7" });
  check("even a stray step request does not move a paused clock", frozen.payload.paused === true && frozen.payload.round === 280);
  m = await post(run("prepare pause", { topic: "resume" }, E, fctx).out);
  check("RESUME button un-pauses", m.payload.paused === false);
  const live = await (await fetch("http://127.0.0.1:" + port + "/api/live")).json();
  check("after 40 ticks the live clock stands at hour 280 (40 x 7 h), step counter 40", live.round === 280 && live.steps === 40 && live.age_s !== null && live.age_s < 30);
  const notes = (await (await fetch("http://127.0.0.1:" + port + "/api/notifications?limit=100")).json()).notifications;
  check("all " + sent + " notifications that Flow 2 sent are stored by the engine", sent > 0 && texts.every(t => notes.some(x => x.text === t)));
  console.log(failures ? "FUNCTION NODES FAILED" : "FUNCTION NODES OK");
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error("EXCEPTION", e); process.exit(1); });
