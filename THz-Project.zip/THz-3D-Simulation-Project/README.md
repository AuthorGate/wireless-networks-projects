
# Terahertz Wireless Communication – 3D Simulation

## Project Overview

This project studies signal propagation and blockage in indoor Terahertz (THz) wireless communication at 300 GHz.

The main problem is that physical obstacles can block the direct signal between the transmitter (Tx) and receiver (Rx), which can interrupt communication.

The project investigates a possible solution using signal reflection and directional beam steering to find an alternative communication path.

## Tools Used

- Python
- NVIDIA Sionna RT
- MATLAB-based channel modeling data
- NumPy and SciPy
- Matplotlib

The original MATLAB project was obtained from GitHub and used to study THz propagation and molecular absorption.

The Python simulation uses the molecular absorption dataset from the MATLAB project.

Original MATLAB project:
https://github.com/GeorgeFawkes/Thz-channel-modeling-and-ray-tracing

## Simulation Scenarios

The simulation was performed in a 7 m × 6 m × 3 m indoor room at 300 GHz.

Four main scenarios were tested:

1. Clear Line-of-Sight (LoS): Direct communication without obstacles.
2. Blocked LoS: A physical barrier blocks the direct signal.
3. Signal Reflection: The signal reaches the receiver through a wall reflection.
4. Beam Steering: Different transmitter angles are tested to find the direction with the lowest signal loss.

## Python Files

| File | Description |
|------|-------------|
| 01_validate_los.py | Validate free-space path loss |
| 02_room_3d.py | Simulate clear LoS communication |
| 03_room_blockage.py | Simulate signal blockage |
| 04_room_reflection.py | Simulate reflected signal propagation |
| 05_link_budget.py | Calculate received power, SNR, and theoretical capacity |
| 06_plot_comparison.py | Generate performance comparison graphs |
| 08_fine_beam_sweep.py | Test beam angles from -90 to 90 degrees |
| 09_best_beam_3d.py | Visualize the selected beam direction in 3D |

## Results

The beam-sweeping simulation tested transmitter orientations from -90 to 90 degrees in steps of 5 degrees.

The best tested angle was 50 degrees.

| Metric | 0 Degrees | 50 Degrees |
|--------|-----------|------------|
| Link Loss | 102.31 dB | 95.42 dB |
| SNR | -15.31 dB | -8.42 dB |
| Theoretical Capacity | 41.90 Mbps | 193.83 Mbps |

Beam steering reduced the effective link loss by approximately 6.88 dB compared with the 0-degree direction in the same blocked environment.

These results show that choosing a suitable beam direction can improve the reflected communication path.

The capacity values are theoretical estimates based on Shannon's formula, not measured data rates.

## How to Run

The project was run on Ubuntu using Python and NVIDIA Sionna RT.

### 1. Open the project folder

```bash
cd ~/THz-3D-Simulation-Project
```

### 2. Set up Python

If the virtual environment is not already available:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
```

### 3. Run the simulations

```bash
.venv/bin/python 01_validate_los.py
.venv/bin/python 02_room_3d.py
.venv/bin/python 03_room_blockage.py
.venv/bin/python 04_room_reflection.py
.venv/bin/python 08_fine_beam_sweep.py
.venv/bin/python 09_best_beam_3d.py
.venv/bin/python 05_link_budget.py
.venv/bin/python 06_plot_comparison.py
```

The simulation figures and CSV results are saved in the `results/` folder.

The molecular absorption dataset is stored in:

`data/molecular_absorption.mat`

The file contains frequency (`f`) and absorption coefficient (`k`) values used in the propagation calculations.

## Conclusion

The simulation shows that physical blockage can interrupt direct THz communication.

However, a reflected path can provide an alternative route. By adjusting the transmitter direction, the effective signal loss was reduced in the tested indoor environment.

The current implementation uses a static environment and does not include real-time beam tracking or moving obstacles.
