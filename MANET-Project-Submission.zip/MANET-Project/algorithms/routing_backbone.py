import json
import networkx as nx
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/urban_clusters.json") as f:
    data = json.load(f)

snapshots = data["snapshots"]


def build_graph(snapshot):

    G = nx.Graph()

    G.add_nodes_from(
        node["id"] for node in snapshot["nodes"]
    )

    for link in snapshot["links"]:

        G.add_edge(
            link["source"],
            link["target"],
            loss=link["path_loss_db"]
        )

    return G


def create_backbone(G, clusters, previous):

    backbone = nx.Graph()
    backbone.add_nodes_from(G.nodes)

    membership = {}

    for head, members in clusters.items():

        for node in members:

            membership[node] = head

            if node != head:

                backbone.add_edge(
                    head,
                    node,
                    loss=G[head][node]["loss"]
                )

    gateways = {}

    for a, b in G.edges:

        head_a = membership[a]
        head_b = membership[b]

        if head_a == head_b:
            continue

        pair = tuple(sorted((head_a, head_b)))

        stable = previous.has_edge(a, b)

        loss = G[a][b]["loss"]

        score = (
            0 if stable else 1,
            loss,
            min(a, b),
            max(a, b)
        )

        if (
            pair not in gateways
            or score < gateways[pair][0]
        ):

            gateways[pair] = (score, a, b)

    for score, a, b in gateways.values():

        backbone.add_edge(
            a,
            b,
            loss=G[a][b]["loss"]
        )

    original_components = {
        frozenset(c)
        for c in nx.connected_components(G)
    }

    backbone_components = {
        frozenset(c)
        for c in nx.connected_components(backbone)
    }

    if original_components != backbone_components:
        raise ValueError("Backbone connectivity error")

    return backbone


def export_graph(G):

    return {
        "nodes": [
            {"id": node} for node in G.nodes
        ],

        "links": [
            {
                "source": a,
                "target": b,
                "path_loss_db": G[a][b]["loss"]
            }
            for a, b in G.edges
        ]
    }


previous = build_graph(snapshots[0])

results = []

for snapshot in snapshots:

    G = build_graph(snapshot)

    traditional = create_backbone(
        G,
        snapshot["traditional_clusters"],
        previous
    )

    adaptive = create_backbone(
        G,
        snapshot["adaptive_clusters"],
        previous
    )

    result = {
        "time": snapshot["time"],
        "physical_links": G.number_of_edges(),
        "traditional_links": traditional.number_of_edges(),
        "adaptive_links": adaptive.number_of_edges(),
        "traditional_connected": nx.is_connected(traditional),
        "adaptive_connected": nx.is_connected(adaptive),
        "traditional": export_graph(traditional),
        "adaptive": export_graph(adaptive)
    }

    results.append(result)

    print("\nTime:", snapshot["time"], "s")
    print("---------------------------")
    print("Physical links:", G.number_of_edges())
    print("Traditional links:", traditional.number_of_edges())
    print("SAAC links:", adaptive.number_of_edges())
    print("Traditional connected:", nx.is_connected(traditional))
    print("SAAC connected:", nx.is_connected(adaptive))

    previous = G


with open(ROOT / "results/routing_backbones.json", "w") as f:

    json.dump(results, f, indent=4)


print("\nRouting Backbones Created")
print("Saved: results/routing_backbones.json")