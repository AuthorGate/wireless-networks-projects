#!/bin/sh
# Run on an OpenWrt access point with usteer installed.
# This script collects telemetry only; it does not change wireless state.
set -eu
OUT="${1:-/tmp/greenwifi-snapshot}"
mkdir -p "$OUT"
ubus call usteer local_info > "$OUT/local_info.json"
ubus call usteer remote_info > "$OUT/remote_info.json"
ubus call usteer get_clients > "$OUT/clients.json"
date -Iseconds > "$OUT/captured_at.txt"
echo "Read-only usteer snapshot saved under: $OUT"
echo "Collect traffic rates and radio power separately; see docs/measurement_protocol.md."
