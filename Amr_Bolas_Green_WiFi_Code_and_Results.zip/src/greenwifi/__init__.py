"""Traffic-aware energy-efficient Wi-Fi management prototype."""

__version__ = "1.0.0"
