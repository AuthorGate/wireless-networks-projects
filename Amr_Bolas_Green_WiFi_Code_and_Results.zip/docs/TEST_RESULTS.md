# Test and scenario verification

Verified on 2026-11-18 using Python 3.12.14.

Command:

```sh
PYTHONPATH=src python -m unittest discover -s tests -v
```

Result: **11 tests passed**. The suite covers persistence across low-demand windows, protected clients, weak alternate signal, backup capacity, the AP floor, dependent backup protection, traffic spikes, irregular sampling gaps, unknown AP identifiers, invalid client counts, and threshold ordering.

The scenario evaluator was also run with `data/demo_trace.csv` and `config/config.json`. It produced nine windows, three APs, seven sleep recommendations, 38.070 Wh always-on reference energy, 37.685 Wh modeled policy energy, and an estimated 0.385 Wh (1.01%) difference for the Ruckus H550 reference pair. The sensitivity script produced 3.045 Wh (7.96%) for the Aruba AP-505 reference pair on the same trace.

These checks validate software behavior and arithmetic for the supplied synthetic scenario. They do not validate local network conditions or field energy savings.

The final IEEEtran source also compiled successfully with the desktop LaTeX compiler and with Tectonic 0.17.0. The delivered Overleaf PDF has seven A4 pages, embeds the supplied author metadata, and was rendered page by page for visual inspection. Its metadata records pdfTeX; the Overleaf upload instructions use pdfLaTeX to match that build.
