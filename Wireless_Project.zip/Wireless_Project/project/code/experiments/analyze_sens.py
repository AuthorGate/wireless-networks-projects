"""Build the sensitivity table (LaTeX) from sens_raw.csv.  Usage: python3 -I analyze_sens.py sens_raw.csv out.tex"""
import sys, numpy as np, pandas as pd
from scipy import stats
df = pd.read_csv(sys.argv[1]); K = ["theta", "seed"]
order = ["baseline", "sigma_0.05", "sigma_0.2", "tau_1", "tau_4", "exp_2.4", "exp_3.0", "trunk_5", "trunk_15"]
name = {"baseline": "baseline", "sigma_0.05": "$s=0.05$", "sigma_0.2": "$s=0.2$", "tau_1": "$\\tau=1$", "tau_4": "$\\tau=4$",
        "exp_2.4": "$n=2.4$", "exp_3.0": "$n=3.0$", "trunk_5": "$L_t=5$", "trunk_15": "$L_t=15$"}
def ci(d):
    m = d.mean(); h = stats.t.ppf(.975, len(d) - 1) * d.std(ddof=1) / np.sqrt(len(d)); return m, m - h, m + h
rows = []
for v in order:
    g = df[df.variant == v]; o = g[g.canopy == "open"].set_index(K).delivery
    r = [name[v]]
    for c in ("medium", "dense"):
        x = g[g.canopy == c].set_index(K)
        r += [f"{x.links.mean():.1f}", f"{x.delivery.mean():.1f}"]
    x = g[g.canopy == "dense"].set_index(K).delivery
    m, lo, hi = ci(x - o)
    r.append(f"${m:.1f}$ [${lo:.1f},{hi:.1f}$]")
    rows.append(r)
base = df[(df.variant == "baseline") & (df.canopy == "open")].delivery.mean()
tex = ("Table~\\ref{tab:sens} reports the results. The open-field delivery is " + f"{base:.1f}" + "\\% in every variant, since in the open field the link set is the distance graph and fading is zero. ")
tex += ("\\begin{table}[t]\\centering\\caption{Sensitivity (4$\\times$4, 40\\,km/h with fading; 40 runs per cell). Links and delivery (\\%) for medium and dense canopy; last column is the paired difference of dense minus open delivery.}\\label{tab:sens}\\small\n"
        "\\begin{tabular}{lrrrrl}\\toprule\n & \\multicolumn{2}{c}{medium} & \\multicolumn{2}{c}{dense} & \\\\\nVariant & links & deliv. & links & deliv. & dense$-$open\\\\\\midrule\n")
tex += "\n".join(" & ".join(r) + "\\\\" for r in rows) + "\n\\bottomrule\\end{tabular}\\end{table}\n"
open(sys.argv[2], "w").write(tex)
print(tex)
