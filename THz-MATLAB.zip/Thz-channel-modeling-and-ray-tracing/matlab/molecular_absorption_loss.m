%% George Alfred Mensah - Molecular Absorption Loss Analysis in THz Band
clc(); clear();
close("all");

%% Load Data from file
load('../data/molecular_absorption.mat');

%% Parameters
distances = [1, 10, 100];

% Added custom colours for easy identification. 
light_blue = [0.4, 0.6, 1.0]; %light blue
orange = [1.0, 0.6, 0.2]; %orange
light_green = [0.6, 1.0, 0.6]; %light green
colors = {light_blue, orange, light_green};

%% Compute Absorption Loss
absorption_loss = zeros(length(f), length(distances));

for i = 1:length(distances)
    d = distances(i);
    absorption_loss(:, i) = 10 * log10(exp(k * d)); % Molecular absorption loss in dB
end

%% Convert Frequency to THz
f_THz = f / 1e12; %Frequency from Hz to THz

%% Graph
figure;
hold on;

%% Plot for each distance
for i = 1:length(distances)
    plot(f_THz, absorption_loss(:, i), 'LineWidth', 1.0, 'Color', colors{i});
end

%% Display graph
xlabel('Frequency (THz)');
ylabel('Molecular Absorption Loss (dB)');
title('Molecular Absorption Loss in the THz Band');
legend('1 meter', '10 meters', '100 meters');
xlim([0.1, 10]); % x-axis range set from 0.1 THz to 10 THz 
%ylim([0, max(absorption_loss(:))]); % y-axis = maximum
ylim([0, 1200]); %y-axis capped at 500
grid on;
hold off;