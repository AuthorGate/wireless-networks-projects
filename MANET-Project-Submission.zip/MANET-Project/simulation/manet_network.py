import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import numpy as np
import json
import csv
import argparse
import matplotlib.pyplot as plt

from pathlib import Path
from sionna.rt import load_scene, PlanarArray
from sionna.rt import Transmitter, Receiver, PathSolver

ROOT = Path(__file__).resolve().parents[1]

frequency = 2.4e9
spacing = 10
max_path_loss = 62

parser = argparse.ArgumentParser()
parser.add_argument("--mobile", action="store_true")
args = parser.parse_args()

prefix = "mobile_" if args.mobile else ""

if args.mobile:
    with open(ROOT / "results/mobile_positions.json") as f:
        nodes = json.load(f)["nodes"]
else:
    nodes = []

    for i in range(9):
        nodes.append({
            "id": format(i, "04x"),
            "x": (i % 3) * spacing,
            "y": (i // 3) * spacing,
            "z": 1.5
        })

links = []
results = []

solver = PathSolver()

for i in range(len(nodes) - 1):

    scene = load_scene()
    scene.frequency = frequency

    scene.tx_array = PlanarArray(
        num_rows=1,
        num_cols=1,
        pattern="iso",
        polarization="V"
    )

    scene.rx_array = scene.tx_array

    source = nodes[i]

    scene.add(Transmitter(
        name="tx",
        position=[
            source["x"],
            source["y"],
            source["z"]
        ]
    ))

    targets = nodes[i + 1:]

    for target in targets:
        scene.add(Receiver(
            name="rx_" + target["id"],
            position=[
                target["x"],
                target["y"],
                target["z"]
            ]
        ))

    paths = solver(scene, max_depth=0, los=True)

    real, imag = paths.a

    power = real.numpy()**2 + imag.numpy()**2

    for j, target in enumerate(targets):

        gain = np.sum(power[j])

        loss = -10 * np.log10(gain) if gain > 0 else float("inf")

        connected = loss <= max_path_loss

        results.append([
            source["id"],
            target["id"],
            round(float(loss), 2),
            connected
        ])

        if connected:
            links.append({
                "source": source["id"],
                "target": target["id"],
                "path_loss_db": round(float(loss), 2)
            })

        print(
            source["id"], "->", target["id"],
            "| Loss:", round(float(loss), 2),
            "| Connected:", connected
        )

with open(ROOT / f"results/{prefix}network.json", "w") as f:
    json.dump({
        "nodes": nodes,
        "links": links
    }, f, indent=4)

with open(ROOT / f"results/{prefix}wireless_links.csv", "w") as f:
    writer = csv.writer(f)

    writer.writerow([
        "Source", "Target", "Path Loss", "Connected"
    ])

    writer.writerows(results)

fig = plt.figure(figsize=(10, 8))
ax = fig.add_subplot(111, projection="3d")

positions = {node["id"]: node for node in nodes}

for node in nodes:
    ax.scatter(
        node["x"], node["y"], node["z"],
        color="blue", s=100
    )

    ax.text(
        node["x"], node["y"], node["z"] + 0.5,
        node["id"]
    )

for link in links:
    a = positions[link["source"]]
    b = positions[link["target"]]

    ax.plot(
        [a["x"], b["x"]],
        [a["y"], b["y"]],
        [a["z"], b["z"]],
        color="green"
    )

ax.set_xlabel("X (m)")
ax.set_ylabel("Y (m)")
ax.set_zlabel("Z (m)")

ax.set_xlim(-3, 23)
ax.set_ylim(-3, 23)
ax.set_zlim(0, 5)

if args.mobile:
    ax.set_title("Sionna RT - Mobile MANET Network")
else:
    ax.set_title("Sionna RT - Static MANET Network")

plt.savefig(
    ROOT / f"figures/{prefix}manet_network.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("-------------------------")
print("Scenario:", "Mobile" if args.mobile else "Static")
print("Total nodes:", len(nodes))
print("Tested links:", len(results))
print("Connected links:", len(links))
print("Disconnected links:", len(results) - len(links))
print("Simulation completed")