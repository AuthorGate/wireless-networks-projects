"""One-at-a-time sensitivity of the assumed channel parameters (4x4 grid, medium/dense canopy, 40 km/h + radio fading).
Usage: python3 -I experiments/sensitivity.py out.csv"""
import sys, os, csv, time
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_study as rs
VARIANTS = {"baseline": {}, "sigma_0.05": {"fade_sigma_db_per_kmh": 0.05}, "sigma_0.2": {"fade_sigma_db_per_kmh": 0.2},
            "tau_1": {"fade_tau_s": 1.0}, "tau_4": {"fade_tau_s": 4.0},
            "exp_2.4": {"pl_exponent": 2.4}, "exp_3.0": {"pl_exponent": 3.0},
            "trunk_5": {"trunk_loss_db": 5.0}, "trunk_15": {"trunk_loss_db": 15.0}}
def job(a):
    v, args = a
    r = rs.one(args + (VARIANTS[v],)); r["variant"] = v; return r
if __name__ == "__main__":
    out = sys.argv[1]
    jobs = [(v, (4, th, sd, c, "w40_fire+radio")) for v in VARIANTS for c in ("open", "medium", "dense") for th in (0, 90) for sd in range(20)]
    print(len(jobs), "runs", flush=True); t0 = time.time()
    with Pool(os.cpu_count()) as p:
        rows = p.map(job, jobs, chunksize=4)
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print("done", round(time.time() - t0), "s", flush=True)
