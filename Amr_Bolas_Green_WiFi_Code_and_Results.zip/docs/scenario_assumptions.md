# Modeled Nablus institutional scenario

## Purpose and scope

The project uses a reproducible simulation for a plausible late-evening period in a small university or institutional building in Nablus, Palestine. No site telemetry, device inventory, power-meter reading, or campus network export was available. The trace is synthetic and must not be described as a measurement from a specific Nablus institution.

The scenario represents an operational question: can a conservative traffic-aware policy recommend a lower-power state for one of several overlapping APs while keeping enough coverage and spare capacity for users and protected devices?

## Topology and telemetry assumptions

- Three APs share one managed institutional Wi-Fi area.
- The observation lasts 2.25 hours: nine consecutive 15-minute windows starting at 22:00 and ending at 00:15 on the next day.
- AP-1 remains active because one protected endpoint is associated with it.
- AP-2 and AP-3 have low but nonzero client counts during quiet windows.
- The strongest alternate signal for clients on candidate APs is between -62 and -64 dBm, above the example -67 dBm threshold.
- The projected backup load stays below the configured 70% limit in the low-demand windows.
- The policy keeps at least two APs active, uses a three-window low-demand persistence requirement, and returns AP-2 to `KEEP_ON` during a later traffic/channel-load spike.

These values are scenario inputs selected to exercise the guards. The signal, traffic, client count, and backup-load values are not local measurements.

## Power reference values

The primary run uses the published Ruckus H550 idle/standby values shown in the 2025 AP energy study: 5.64 W with both radios enabled and 5.42 W with both radios disabled. The sensitivity run uses the corresponding Aruba AP-505 reference values: 5.67 W and 3.93 W. The source discusses hardware-dependent radio-off savings; the figures are included to show that outcomes change materially across AP models.

For the primary Ruckus H550 scenario:

- Always-on energy: `3 APs × 9 windows × 0.25 h × 5.64 W = 38.070 Wh`.
- Seven AP-windows receive `SLEEP_RECOMMENDED` while the two-AP floor is preserved.
- Estimated saving: `7 × 0.25 h × (5.64 W − 5.42 W) = 0.385 Wh`.
- Modeled policy energy: `38.070 Wh − 0.385 Wh = 37.685 Wh`.
- Relative scenario difference: `0.385 / 38.070 × 100 = 1.01%`.

For the Aruba AP-505 reference pair, the same seven AP-windows yield 3.045 Wh of modeled savings, or 7.96% against that model's own 38.2725 Wh always-on reference.

This flat-state comparison does not model traffic-dependent power, PoE conversion loss, device-to-device variation, or uncertainty. It is a transparent scenario calculation, not a calibrated prediction for local equipment.

## Interpretation

The scenario shows how the software behaves when low demand, coverage, backup capacity, protected devices, and a minimum-active-AP rule are represented in a trace. It does not prove that a particular Nablus building keeps redundant APs active or that it will save the calculated energy. The policy remains advisory-only and issues no radio-control commands.
