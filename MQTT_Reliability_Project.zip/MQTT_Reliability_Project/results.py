
import sqlite3
import csv
import matplotlib.pyplot as plt

TOTAL_MESSAGES = 20

# Read received messages from Subscriber database
connection = sqlite3.connect("received_messages.db")

rows = connection.execute(
    "SELECT message_id, temperature FROM received ORDER BY message_id"
).fetchall()

connection.close()

received_ids = {row[0] for row in rows}
received_count = len(received_ids)

# Read pending messages from Publisher database
connection = sqlite3.connect("mqtt_buffer.db")

pending_count = connection.execute(
    "SELECT COUNT(*) FROM messages"
).fetchone()[0]

connection.close()

# Calculate metrics
delivery_rate = (received_count / TOTAL_MESSAGES) * 100
missing_count = max(TOTAL_MESSAGES - received_count, 0)

print("\n===== MQTT RELIABILITY RESULTS =====")
print("Total generated messages:", TOTAL_MESSAGES)
print("Unique received messages:", received_count)
print("Missing messages:", missing_count)
print(f"Delivery Rate: {delivery_rate:.2f}%")
print("Messages still in Publisher buffer:", pending_count)

# Save results to CSV
with open("results.csv", "w", newline="") as file:
    writer = csv.writer(file)

    writer.writerow(["Metric", "Value"])
    writer.writerow(["Generated Messages", TOTAL_MESSAGES])
    writer.writerow(["Unique Received", received_count])
    writer.writerow(["Missing Messages", missing_count])
    writer.writerow(["Delivery Rate (%)", delivery_rate])
    writer.writerow(["Pending Messages", pending_count])

print("\nResults saved to results.csv")

# Graph 1: Received vs Missing
plt.figure(figsize=(7, 5))
plt.bar(
    ["Received", "Missing"],
    [received_count, missing_count],
    color=["green", "red"]
)

plt.title("MQTT Message Delivery Results")
plt.ylabel("Number of Messages")
plt.ylim(0, TOTAL_MESSAGES + 2)
plt.tight_layout()
plt.savefig("delivery_results.png", dpi=300)
plt.show()

# Graph 2: Delivery Rate
plt.figure(figsize=(7, 5))
plt.bar(
    ["Delivery Rate"],
    [delivery_rate],
    color=["blue"]
)

plt.title("MQTT Reliability - Delivery Rate")
plt.ylabel("Delivery Rate (%)")
plt.ylim(0, 110)
plt.tight_layout()
plt.savefig("delivery_rate.png", dpi=300)
plt.show()

print("\nGraphs generated successfully!")
