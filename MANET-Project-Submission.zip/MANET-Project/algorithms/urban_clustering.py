import json
import networkx as nx
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/urban_mobility.json") as f:
    data = json.load(f)

threshold = data["threshold"]
snapshots = data["snapshots"]


def build_graph(snapshot):

    G = nx.Graph()

    for node in snapshot["nodes"]:
        G.add_node(node["id"])

    for link in snapshot["links"]:
        G.add_edge(
            link["source"],
            link["target"],
            loss=link["path_loss_db"]
        )

    return G


def create_clusters(G, scores):

    remaining = set(G.nodes)
    clusters = {}

    while remaining:

        head = max(
            remaining,
            key=lambda n: (scores[n], n)
        )

        members = (
            set(G.neighbors(head)) & remaining
        ) | {head}

        clusters[head] = sorted(members)

        remaining -= members

    return clusters


def adaptive_scores(old, new, old_heads):

    scores = {}

    max_degree = max(
        1, max(dict(new.degree()).values())
    )

    for node in new.nodes:

        neighbors = set(new.neighbors(node))
        previous = set(old.neighbors(node))

        degree = len(neighbors) / max_degree

        quality = 0

        if neighbors:
            quality = sum(
                max(0, min(
                    1,
                    (threshold - new[node][n]["loss"]) / 10
                ))
                for n in neighbors
            ) / len(neighbors)

        common = neighbors & previous
        total = neighbors | previous

        stability = (
            len(common) / len(total)
            if total else 0
        )

        retention = (
            1 if node in old_heads and neighbors else 0
        )

        scores[node] = (
            0.3 * degree +
            0.3 * quality +
            0.3 * stability +
            0.1 * retention
        )

    return scores


def membership(clusters):

    result = {}

    for head, members in clusters.items():
        for node in members:
            result[node] = head

    return result


old_graph = None

old_traditional = {}
old_adaptive = {}

total_traditional_changes = 0
total_adaptive_changes = 0

total_traditional_members = 0
total_adaptive_members = 0

for snapshot in snapshots:

    G = build_graph(snapshot)

    traditional = create_clusters(
        G, dict(G.degree())
    )

    if old_graph is None:

        adaptive = traditional.copy()

    else:

        scores = adaptive_scores(
            old_graph,
            G,
            set(old_adaptive)
        )

        adaptive = create_clusters(G, scores)

    traditional_changes = 0
    adaptive_changes = 0

    traditional_members = 0
    adaptive_members = 0

    if old_graph is not None:

        traditional_changes = len(
            set(old_traditional) ^
            set(traditional)
        )

        adaptive_changes = len(
            set(old_adaptive) ^
            set(adaptive)
        )

        old_t = membership(old_traditional)
        new_t = membership(traditional)

        old_a = membership(old_adaptive)
        new_a = membership(adaptive)

        traditional_members = sum(
            old_t[n] != new_t[n]
            for n in G.nodes
        )

        adaptive_members = sum(
            old_a[n] != new_a[n]
            for n in G.nodes
        )

    total_traditional_changes += traditional_changes
    total_adaptive_changes += adaptive_changes

    total_traditional_members += traditional_members
    total_adaptive_members += adaptive_members

    snapshot["traditional_clusters"] = traditional
    snapshot["adaptive_clusters"] = adaptive

    snapshot["clustering_statistics"] = {

        "traditional_clusters": len(traditional),
        "adaptive_clusters": len(adaptive),

        "traditional_head_changes":
            traditional_changes,

        "adaptive_head_changes":
            adaptive_changes,

        "traditional_member_changes":
            traditional_members,

        "adaptive_member_changes":
            adaptive_members
    }

    print("\nTime:", snapshot["time"], "s")
    print("---------------------------")
    print("Traditional clusters:", len(traditional))
    print("Adaptive clusters:", len(adaptive))
    print("Traditional head changes:", traditional_changes)
    print("Adaptive head changes:", adaptive_changes)

    old_graph = G
    old_traditional = traditional
    old_adaptive = adaptive


data["summary"] = {

    "traditional_head_changes":
        total_traditional_changes,

    "adaptive_head_changes":
        total_adaptive_changes,

    "traditional_member_changes":
        total_traditional_members,

    "adaptive_member_changes":
        total_adaptive_members
}


with open(ROOT / "results/urban_clusters.json", "w") as f:

    json.dump(data, f, indent=4)


print("\nFinal Urban Clustering Results")
print("------------------------------")

for key, value in data["summary"].items():
    print(key, ":", value)

print("\nSimulation completed")
print("Saved: results/urban_clusters.json")