
import json
import random
import sqlite3
import threading
import time

import paho.mqtt.client as mqtt

BROKER = "localhost"
PORT = 1883

DATA_TOPIC = "iot/reliable/temperature"
ACK_TOPIC = "iot/reliable/ack"

db = sqlite3.connect(
    "mqtt_buffer.db",
    check_same_thread=False
)

db.execute("""
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY,
    temperature REAL NOT NULL
)
""")
db.commit()

db_lock = threading.Lock()
ack_event = threading.Event()
waiting_for_id = None


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("Connected to MQTT Broker!")
        client.subscribe(ACK_TOPIC, qos=1)
    else:
        print("Connection failed:", reason_code)


def on_message(client, userdata, message):
    global waiting_for_id

    try:
        ack = json.loads(message.payload.decode("utf-8"))
        ack_id = int(ack["id"])

        if ack_id == waiting_for_id:
            print(f"ACK received for message {ack_id}")
            ack_event.set()

    except (ValueError, KeyError, TypeError):
        print("Invalid ACK received.")


client = mqtt.Client(
    callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
    client_id="reliable_temperature_sensor"
)

client.on_connect = on_connect
client.on_message = on_message


def save_messages():
    with db_lock:
        for i in range(1, 21):
            temperature = round(random.uniform(20, 35), 2)

            db.execute(
                "INSERT OR IGNORE INTO messages VALUES (?, ?)",
                (i, temperature)
            )

            print(f"Saved message {i}: {temperature} °C")

        db.commit()


def get_pending_messages():
    with db_lock:
        return db.execute(
            "SELECT id, temperature FROM messages ORDER BY id"
        ).fetchall()


def delete_message(message_id):
    with db_lock:
        db.execute(
            "DELETE FROM messages WHERE id = ?",
            (message_id,)
        )
        db.commit()


def send_messages():
    global waiting_for_id

    for message_id, temperature in get_pending_messages():
        waiting_for_id = message_id
        ack_event.clear()

        payload = json.dumps({
            "id": message_id,
            "temperature": temperature
        })

        print(f"Sending message {message_id}...")

        result = client.publish(
            DATA_TOPIC,
            payload,
            qos=1
        )

        if result.rc != mqtt.MQTT_ERR_SUCCESS:
            print("Publish failed. Retrying later.")
            return False

        # Wait for acknowledgment from Subscriber
        if ack_event.wait(timeout=5):
            delete_message(message_id)
            print(f"Message {message_id} confirmed and removed.")
        else:
            print(f"No ACK for message {message_id}. Will retry.")
            return False

    return True


save_messages()

try:
    while True:
        try:
            print("\nConnecting to MQTT Broker...")

            client.connect(BROKER, PORT, 60)
            client.loop_start()

            time.sleep(1)

            if send_messages():
                print("\nAll messages acknowledged by Subscriber!")
                break

        except OSError:
            print("Broker unavailable. Messages remain saved.")

        finally:
            client.disconnect()
            client.loop_stop()

        print("Retrying in 5 seconds...")
        time.sleep(5)

except KeyboardInterrupt:
    print("\nStopped. Pending messages remain saved.")

finally:
    db.close()
