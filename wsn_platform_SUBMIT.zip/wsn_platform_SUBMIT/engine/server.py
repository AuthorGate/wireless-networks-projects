"""
server.py -- HTTP front door of the water-tank monitoring platform (standard library only).

Start:   python server.py              -> http://127.0.0.1:8000
         python server.py --port 9000

Endpoints (all GET, all stateless, all JSON):
  /api/health                                   -> {"ok": true}
  /api/config                                   -> protocols and defaults
  /api/summary?protocol=PEGASIS&seed=0&n=100    -> FND/HND/LND and the alive-nodes curve
  /api/state?protocol=PEGASIS&seed=0&n=100&round=300
                                                -> full snapshot of the network at that round
  /api/compare?seed=0&n=100                     -> all protocols side by side
  /api/history?limit=20&protocol=LEACH          -> runs saved in the SQLite database (engine/wsn.db)
  /api/curve?id=3                               -> alive/energy curve of one saved run
  /api/live                                     -> the LIVE session (clock advanced by Node-RED) with its current state
  /api/notifications?limit=10                   -> messages pushed by Node-RED
  /api/deployments?limit=8                      -> saved experiments, one row per deployment (who won each metric)
  /api/export.csv                               -> every saved run as a CSV file (opens in Excel)
  /api/activity?limit=8  /api/activity.csv      -> what was done: replay loads, live start/pause/resume, with protocol and source
  POST /api/live/pause?on=1|0                   -> pause / resume the live clock      (called by Node-RED)
  POST /api/live/step?steps=5                   -> advance the live clock            (called by Node-RED)
  POST /api/live/reset?protocol=..&layout=..    -> start a new live session          (called by Node-RED)
  POST /api/notify?text=..&hour=..              -> store a notification              (called by Node-RED)
  every simulation endpoint also accepts  layout=real|random
  /                                             -> the dashboard (dashboard/index.html)
"""
from __future__ import annotations
import argparse, json, os, re, sys, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

import platform_core as core
import store

HERE = os.path.dirname(os.path.abspath(__file__))
# ConnectionAbortedError (WinError 10053), ConnectionResetError (10054) and BrokenPipeError are all ConnectionError subclasses
CONN_ERRORS = (ConnectionError, BrokenPipeError, TimeoutError)
START_TIME = time.strftime("%Y-%m-%d %H:%M:%S")          # notifications are shown "since this server started"
DASHBOARD = os.path.join(HERE, "..", "dashboard", "index.html")
LOCK = threading.Lock()          # simulations are cached; one at a time keeps it simple and safe


def _source(q) -> str:
    """Who triggered an action ('dashboard' or 'node-red'); anything odd becomes 'unknown'."""
    s = q.get("source", ["unknown"])[0]
    return s if re.fullmatch(r"[A-Za-z0-9_-]{1,20}", s) else "unknown"


def _int(q, key, default):
    try:
        return int(q.get(key, [default])[0])
    except ValueError:
        raise ValueError(f"'{key}' must be an integer")


def route(path: str, q: dict):
    """Return (status, python-object) for an API path."""
    if path == "/api/health":
        return 200, {"ok": True}
    if path == "/api/config":
        return 200, dict(protocols=core.PROTOCOL_NAMES, layouts=list(core.LAYOUTS), default_layout=core.default_layout(),
                         real_buildings=core.real_count(),
                         defaults=dict(protocol="PEGASIS", seed=0, n=100),
                         low_level=core.LOW_LEVEL, high_level=core.HIGH_LEVEL)
    if path == "/api/history":
        limit = _int(q, "limit", 20)
        proto = q.get("protocol", [None])[0]
        if not 1 <= limit <= 200:
            raise ValueError("limit must be 1..200")
        if proto is not None and proto not in core.PROTOCOL_NAMES:
            raise ValueError(f"protocol must be one of {core.PROTOCOL_NAMES}")
        with LOCK:
            return 200, dict(runs=store.history(limit, proto), total=store.count())
    if path == "/api/curve":
        with LOCK:
            c = store.curve(_int(q, "id", 0))
        return (200, c) if c else (404, {"error": "no such saved run"})
    if path == "/api/activity":
        limit = _int(q, "limit", 8)
        if not 1 <= limit <= 100:
            raise ValueError("limit must be 1..100")
        with LOCK:
            return 200, dict(activity=store.activity(limit))
    if path == "/api/deployments":
        limit = _int(q, "limit", 8)
        if not 1 <= limit <= 100:
            raise ValueError("limit must be 1..100")
        with LOCK:
            return 200, store.deployments(limit)
    if path == "/api/notifications":
        limit = _int(q, "limit", 10)
        if not 1 <= limit <= 100:
            raise ValueError("limit must be 1..100")
        with LOCK:
            return 200, dict(notifications=store.notifications(limit, START_TIME if _int(q, "session", 0) == 1 else None),
                             server_started=START_TIME)
    if path == "/api/live":
        with LOCK:
            return 200, core.live_status()
    if path in POST_ONLY:
        return 405, {"error": "use POST for this endpoint"}
    protocol = q.get("protocol", ["PEGASIS"])[0]
    seed, n = _int(q, "seed", 0), _int(q, "n", 100)
    layout = q.get("layout", [core.default_layout()])[0]
    core.check_args(protocol, seed, n, layout)
    with LOCK:
        if path == "/api/summary":
            s = core.summary(core.get_run(protocol, seed, n, layout))
            store.save_run(s, s["layout"])
            if q.get("action", [""])[0] == "load":            # the dashboard's Load / reset (not the live-mode refresh)
                store.log_activity("replay-load", s["protocol"], s["layout"], s["n"], s["seed"], "dashboard")
            return 200, s
        if path == "/api/state":
            return 200, core.state(core.get_run(protocol, seed, n, layout), _int(q, "round", 0))
        if path == "/api/compare":
            result = core.compare(seed, n, layout)
            for p in core.PROTOCOL_NAMES:                      # every simulated run is logged, not only the selected one
                s = core.summary(core.get_run(p, seed, n, layout))
                store.save_run(s, s["layout"])
            return 200, result
    return 404, {"error": "unknown endpoint"}


POST_ONLY = ("/api/live/step", "/api/live/reset", "/api/live/pause", "/api/notify")


def route_post(path: str, q: dict):
    """State-changing endpoints (called by Node-RED).  Everything is in the query string; any body is ignored."""
    if path == "/api/live/step":
        steps = _int(q, "steps", 5)
        if not 1 <= steps <= 500:
            raise ValueError("steps must be 1..500")
        with LOCK:
            return 200, core.live_step(steps)
    if path == "/api/live/reset":
        protocol = q.get("protocol", ["PEGASIS-E"])[0]
        seed, n = _int(q, "seed", 0), _int(q, "n", 100)
        layout = q.get("layout", [core.default_layout()])[0]
        with LOCK:
            st = core.live_reset(protocol, seed, n, layout)
            store.log_activity("live-start", st["protocol"], st["layout"], st["n"], st["seed"], _source(q))
            return 200, st
    if path == "/api/live/pause":
        on = _int(q, "on", 1)
        with LOCK:
            st = core.live_pause(on == 1)
            store.log_activity("live-pause" if on == 1 else "live-resume", st["protocol"], st["layout"], st["n"], st["seed"], _source(q))
            return 200, st
    if path == "/api/notify":
        text = q.get("text", [""])[0].strip()
        if not 1 <= len(text) <= 500:
            raise ValueError("text must be 1..500 characters")
        hour = _int(q, "hour", 0)
        with LOCK:
            return 200, dict(id=store.add_notification(text, hour, q.get("source", ["node-red"])[0]))
    return 404, {"error": "unknown endpoint"}


class Handler(BaseHTTPRequestHandler):
    server_version = "WSNPlatform/1.0"

    def _send(self, status, body: bytes, ctype: str, extra: dict | None = None):
        try:
            self.send_response(status)
            self.send_header("Content-Type", ctype)
            for k, v in (extra or {}).items():
                self.send_header(k, v)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Access-Control-Allow-Origin", "*")   # not needed for same-origin pages; harmless
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        except CONN_ERRORS:                 # the browser refreshed / closed the tab before we finished: nothing to do
            self.close_connection = True

    def do_GET(self):
        u = urlparse(self.path)
        try:
            if u.path in ("/", "/index.html"):
                with open(DASHBOARD, "rb") as f:
                    return self._send(200, f.read(), "text/html; charset=utf-8")
            if u.path == "/api/activity.csv":
                with LOCK:
                    text = store.export_activity_csv()
                return self._send(200, text.encode("utf-8"), "text/csv; charset=utf-8",
                                  {"Content-Disposition": "attachment; filename=wsn_activity_log.csv"})
            if u.path == "/api/export.csv":
                with LOCK:
                    text = store.export_csv()
                return self._send(200, text.encode("utf-8"), "text/csv; charset=utf-8",
                                  {"Content-Disposition": "attachment; filename=wsn_saved_runs.csv"})
            if u.path.startswith("/api/"):
                status, obj = route(u.path, parse_qs(u.query))
                return self._send(status, json.dumps(obj).encode(), "application/json")
            return self._send(404, b'{"error": "not found"}', "application/json")
        except ValueError as e:
            return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")
        except Exception as e:                              # never crash the server
            return self._send(500, json.dumps({"error": f"internal error: {e}"}).encode(), "application/json")

    def do_POST(self):
        u = urlparse(self.path)
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n:                                           # read and ignore any body so the connection stays clean
                self.rfile.read(min(n, 65536))
            if u.path in POST_ONLY:
                status, obj = route_post(u.path, parse_qs(u.query))
            else:
                status, obj = 404, {"error": "unknown endpoint"}
            return self._send(status, json.dumps(obj).encode(), "application/json")
        except ValueError as e:
            return self._send(400, json.dumps({"error": str(e)}).encode(), "application/json")
        except CONN_ERRORS:
            return
        except Exception as e:
            return self._send(500, json.dumps({"error": f"internal error: {e}"}).encode(), "application/json")

    def log_message(self, fmt, *args):                      # quiet console
        pass


class QuietServer(ThreadingHTTPServer):
    """Browsers that refresh or close a tab mid-request make the handler thread fail with ConnectionAbortedError /
    ConnectionResetError / BrokenPipeError. That is normal, so it is ignored instead of printing a long traceback;
    every OTHER exception is still reported by the standard handler."""

    def handle_error(self, request, client_address):
        if isinstance(sys.exc_info()[1], CONN_ERRORS):
            return
        super().handle_error(request, client_address)


def make_server(host="127.0.0.1", port=8000):
    return QuietServer((host, port), Handler)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    a = ap.parse_args()
    srv = make_server(a.host, a.port)
    print(f"Water-tank WSN platform running:  http://{a.host}:{a.port}   (Ctrl+C to stop)")
    print(f"Database file: {store.DB_PATH}")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nbye")
