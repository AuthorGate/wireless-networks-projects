%% George Alfred Mensah - Spreading Loss Analysis in THz Band
clc(); clear();
close("all");

%% Load Data
load('../data/molecular_absorption.mat'); 

%% Parameters
distances = [1, 10, 100]; 
c = 3e8; %speed of light
constant_term = 20 * log10(4 * pi / c); % set the constant term for c

%% Define Custom Colors (Same as Molecular Absorption Plot)
light_blue = [0.4, 0.6, 1.0]; 
orange = [1.0, 0.6, 0.2]; 
light_green = [0.6, 1.0, 0.6]; 
colors = {light_blue, orange, light_green}; 

%% Convert Frequency to THz
f_THz = f / 1e12; 

%% Compute Spreading Loss
spreading_loss = zeros(length(f), length(distances));

for i = 1:length(distances)
    d = distances(i);
    spreading_loss(:, i) = 20 * log10(d) + 20 * log10(f) + constant_term; % Spreading loss in dB
end

%% Graph
figure;
hold on;

%% Plot for each distance with consistent colors
for i = 1:length(distances)
    plot(f_THz, spreading_loss(:, i), 'LineWidth', 1.5, 'Color', colors{i}, 'DisplayName', sprintf('%d meters', distances(i)));
end

%% Display graph
xlabel('Frequency (THz)');
ylabel('Spreading Loss (dB)');
title('Spreading Loss in the THz Band for an Isotropic Antenna');
legend show;
xlim([0.1, 10]); % 0.1 THz to 10 THz 
ylim([min(spreading_loss(:)), max(spreading_loss(:))]); 
grid on;
hold off;