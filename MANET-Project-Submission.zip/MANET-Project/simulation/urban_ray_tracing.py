import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import numpy as np
import sionna.rt as rt

from pathlib import Path
from sionna.rt import load_scene, Camera
from sionna.rt import Transmitter, Receiver
from sionna.rt import PlanarArray, PathSolver

ROOT = Path(__file__).resolve().parents[1]

scene = load_scene(
    rt.scene.simple_street_canyon,
    merge_shapes=False
)

scene.frequency = 2.4e9

scene.tx_array = PlanarArray(
    num_rows=1,
    num_cols=1,
    pattern="iso",
    polarization="V"
)

scene.rx_array = scene.tx_array

scene.add(Transmitter(
    name="node_0",
    position=[-25, 15, 1.5],
    display_radius=2
))

positions = [
    [-25, 0, 1.5],
    [-25, 30, 1.5],
    [24, 15, 1.5],
    [24, 55, 1.5],
    [65, 0, 1.5],
    [88, 0, 1.5]
]

for i, position in enumerate(positions):

    scene.add(Receiver(
        name=f"node_{i + 1}",
        position=position,
        display_radius=2
    ))

solver = PathSolver(deterministic=True)

paths = solver(
    scene,
    max_depth=3,
    los=True,
    specular_reflection=True,
    diffuse_reflection=False,
    refraction=False,
    samples_per_src=200000,
    seed=42
)

real, imag = paths.a

power = real.numpy()**2 + imag.numpy()**2

print("Urban MANET Ray Tracing")
print("-----------------------")

for i in range(len(positions)):

    gain = np.sum(power[i])

    if gain > 0:
        loss = -10 * np.log10(gain)

        print(
            f"Node 0 -> Node {i + 1}",
            "| Path Loss:",
            round(float(loss), 2),
            "dB"
        )
    else:
        print(
            f"Node 0 -> Node {i + 1}",
            "| No propagation path found"
        )

camera = Camera(
    position=[140, -160, 220],
    look_at=[15, 0, 0]
)

scene.render_to_file(
    camera=camera,
    paths=paths,
    filename=str(ROOT / "figures/urban_ray_tracing.png"),
    resolution=(1600, 1000),
    num_samples=128,
    show_devices=True,
    show_orientations=False
)

print("-----------------------")
print("Total nodes: 7")
print("Ray tracing completed")
print("Saved: figures/urban_ray_tracing.png")