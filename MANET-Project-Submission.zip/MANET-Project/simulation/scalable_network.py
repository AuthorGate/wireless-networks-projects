import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import numpy as np
import networkx as nx
import json
import math
import random
import argparse

from pathlib import Path
from sionna.rt import load_scene, PlanarArray
from sionna.rt import Transmitter, Receiver, PathSolver

ROOT = Path(__file__).resolve().parents[1]

parser = argparse.ArgumentParser()
parser.add_argument("--nodes", type=int, default=25)
parser.add_argument("--seed", type=int, default=42)
parser.add_argument("--movement", type=float, default=2.0)
args = parser.parse_args()

frequency = 2.4e9
spacing = 10
max_path_loss = 62

rng = random.Random(args.seed)

width = math.ceil(math.sqrt(args.nodes))

nodes = []

for i in range(args.nodes):
    nodes.append({
        "id": format(i, "04x"),
        "x": (i % width) * spacing,
        "y": (i // width) * spacing,
        "z": 1.5
    })


def calculate_network(nodes, scenario):

    links = []
    solver = PathSolver()

    for i in range(len(nodes) - 1):

        scene = load_scene()
        scene.frequency = frequency

        scene.tx_array = PlanarArray(
            num_rows=1,
            num_cols=1,
            pattern="iso",
            polarization="V"
        )

        scene.rx_array = scene.tx_array

        source = nodes[i]

        scene.add(Transmitter(
            name="tx",
            position=[
                source["x"],
                source["y"],
                source["z"]
            ]
        ))

        targets = nodes[i + 1:]

        for target in targets:
            scene.add(Receiver(
                name="rx_" + target["id"],
                position=[
                    target["x"],
                    target["y"],
                    target["z"]
                ]
            ))

        paths = solver(
            scene,
            max_depth=0,
            los=True
        )

        real, imag = paths.a

        power = real.numpy()**2 + imag.numpy()**2

        for j, target in enumerate(targets):

            gain = np.sum(power[j])

            loss = (
                -10 * np.log10(gain)
                if gain > 0 else float("inf")
            )

            if loss <= max_path_loss:
                links.append({
                    "source": source["id"],
                    "target": target["id"],
                    "path_loss_db": round(float(loss), 2)
                })

        print(
            scenario,
            "| Progress:",
            i + 1,
            "/",
            len(nodes) - 1
        )

    G = nx.Graph()

    G.add_nodes_from(node["id"] for node in nodes)

    G.add_edges_from(
        (link["source"], link["target"])
        for link in links
    )

    components = list(nx.connected_components(G))

    output = {
        "nodes": nodes,
        "links": links,
        "frequency": frequency,
        "threshold": max_path_loss,
        "seed": args.seed,
        "scenario": scenario,
        "statistics": {
            "total_nodes": len(nodes),
            "connected_links": len(links),
            "isolated_nodes": len(list(nx.isolates(G))),
            "connected_components": len(components),
            "largest_component": max(map(len, components)),
            "network_connected": nx.is_connected(G)
        }
    }

    filename = (
        f"{scenario}_{args.nodes}_seed{args.seed}.json"
    )

    with open(ROOT / "results" / filename, "w") as f:
        json.dump(output, f, indent=4)

    return output


reference = ROOT / "results" / f"static_{args.nodes}_seed42.json"

static = None

if reference.exists():

    with open(reference) as f:
        saved = json.load(f)

    if (
        saved["nodes"] == nodes
        and saved["frequency"] == frequency
        and saved["threshold"] == max_path_loss
    ):
        static = saved
        static["seed"] = args.seed

        filename = f"static_{args.nodes}_seed{args.seed}.json"

        with open(ROOT / "results" / filename, "w") as f:
            json.dump(static, f, indent=4)

        print("Reusing existing static network")

if static is None:
    static = calculate_network(nodes, "static")

mobile_nodes = []

for node in nodes:

    angle = rng.uniform(0, 2 * math.pi)

    mobile_nodes.append({
        "id": node["id"],
        "x": node["x"] + args.movement * math.cos(angle),
        "y": node["y"] + args.movement * math.sin(angle),
        "z": node["z"]
    })

mobile = calculate_network(mobile_nodes, "mobile")

print("\nScalability Simulation Results")
print("------------------------------")

print("Total nodes:", args.nodes)
print("Movement:", args.movement, "m")
print("Seed:", args.seed)

print("\nStatic Network")

for key, value in static["statistics"].items():
    print(key, ":", value)

print("\nMobile Network")

for key, value in mobile["statistics"].items():
    print(key, ":", value)

print("\nSimulation completed")