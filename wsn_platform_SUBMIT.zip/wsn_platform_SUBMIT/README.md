# Rooftop Water-Tank Monitoring Platform (energy-aware WSN routing, Nablus)

> Use ONE folder only (the newest zip). Older folders (v1..v5) have older dashboards and will confuse you. The title of the last card tells you which version runs: **"Saved experiments"** = current.

**Idea.** In the West Bank, households keep water in rooftop tanks. A battery sensor on each tank reports its level to one
base station - but the batteries must last. *How the sensors route their data* (Direct, LEACH, PEGASIS and improved
PEGASIS variants) decides how long the network lives. This project simulates that for **80 real buildings from
OpenStreetMap (Nablus)**, compares the protocols, and wraps everything in a tested software platform.

## The three parts and how they connect
```
 Browser  ◄──────────  Python engine (port 8000)  ◄──────────  Node-RED (port 1880)
 dashboard             simulator + tank model                   control layer: moves the LIVE clock,
 (one HTML page)       + API + SQLite database                  applies the alert rule, sends notifications
```
* **Python engine** (`engine/`): the simulation, the API, the database (`engine/wsn.db`) and the dashboard page.
* **Dashboard**: what you look at. Two modes: **Replay** (stand-alone, you press Play) and **Live** (the clock is moved by Node-RED).
* **Node-RED** (`node-red/flow.json`): in *Live* mode it is the **driver**. Every 2 s it tells the engine "advance 5 hours",
  checks which tank alerts are NEW, and posts a notification that appears on the dashboard. Stop Node-RED and the live clock stops.

## Which address do I open?  ->  **http://127.0.0.1:8000** (always)
`http://127.0.0.1:1880/wsn` is the *same page* served through Node-RED (Flow 1, optional). Ignore it unless you want to show that gateway.

## Run it
```
pip install numpy scipy matplotlib        (scipy/matplotlib only for benchmark/figures)
cd engine
python server.py                          -> open http://127.0.0.1:8000
```
Windows: double-click `run_engine.bat`. Keep that window open.

## Demo script (about 3 minutes)
1. **Replay.** Press **Play**. The map shows who sends to whom (PEGASIS-E: one chain, the red square is the leader, the star is the base station).
   Battery colour goes green -> red; grey X = dead node (that tank is no longer monitored).
2. **Controls that change the result** (all re-run the simulation):
   | Control | Effect |
   |---|---|
   | Layout = Real map | the 80 real buildings. *Tanks* below 80 = a random subset (the *seed* picks which buildings) |
   | Layout = Random block | *Tanks* random positions in a 200 x 200 m block (the *seed* picks where) |
   | Protocol | which routing rule the highlighted line/table row/insight refers to |
   | Seed | a different random subset / layout (and a different random draw for LEACH) |
   Tip: with Real map + 80 tanks the deterministic protocols do not depend on the seed - lower *Tanks* to 40 and change the seed to see differences.
3. **Read the panel "What the selected protocol achieves"**: first / half / last node death, change versus LEACH and plain PEGASIS,
   and the weakest tank (distance to the base station, how often it was leader).
4. **Live mode (Node-RED moves the clock).** Second terminal: `node-red` -> http://127.0.0.1:1880 -> menu -> Import -> `node-red/flow.json` -> Deploy.
   (Deploying does NOT start anything: a fresh engine is READY.) On the dashboard choose **Mode = Live**: the bar says READY.
   Choose layout / protocol / seed / tanks and click **Start live session** on the dashboard (or click the small square left of an inject node named
   **START live: ...** in Node-RED). The bar turns green "LIVE - the clock is driven by Node-RED", the map moves, notifications appear.
   **Pause / Resume** exist on the dashboard and as PAUSE live / RESUME live buttons in Node-RED (the bar says PAUSED).
   Press Ctrl+C in Node-RED: after ~8 s the bar says STOPPED - proof that Node-RED is what moves the clock.
5. **Activity log** = what was done and with which protocol (replay loads; live start / pause / resume; by the dashboard or by Node-RED).
   **Saved experiments** = the database, one row per deployment (layout + tanks + seed), with the winner of each metric. On port 8000 a link downloads every run as a CSV file that opens in Excel.

## Reading the numbers
One *round* = one hour = every tank reports once. **FND** = round when the first node's battery dies, **HND** = half dead, **LND** = last.
Energy is *normalised* (0.5 J per node), so rounds are comparable between protocols but are **not** days.

## Tests, benchmarks, report figures
```
python tests/test_platform.py     30 automated tests (simulator, API, database, Node-RED flow functions end-to-end, dashboard JS)
python engine/wsn_sim.py          10 simulator self-tests (hand calculations)
python engine/ablation.py         ablation + realism study (parallel; --workers 1 for sequential)
python engine/benchmark.py        all protocols on the real map and 30 random layouts
python engine/make_figures.py     figures for the report
python engine/prepare_layout.py file.geojson --block 400   make a new real layout from OpenStreetMap buildings
```
After editing `dashboard/index.html` run `python node-red/make_flow.py` and re-import the flow (`check_flow.py` fails if the copy inside the flow is stale).

## What is real and what is assumed (say this in the defence)
* Real: building footprints (OpenStreetMap, 83 buildings, 80 used), the Heinzelman radio-energy model, the algorithms.
* Assumed: one building = one tank; base-station position (50 m north of the block); tank levels and water-supply schedule (4 zones, 8 h per 72 h);
  normalised battery energy. Retries / sleep energy are simple factors (see report).
* The PEGASIS improvements (2-opt chain, energy-aware leader) are **variations of published ideas** (EEPB, IEEPB, EECB, Pegant), not new inventions.
  The contribution is the controlled ablation, the real-data evaluation and the tested platform.

## FAQ - the questions everybody asks first
**Why do all protocols appear (and change) whenever I change one setting?**
Because the point is to compare protocols on the *same* deployment. Loading a deployment (layout + tanks + seed) simulates all six protocols on it
(under a second) and saves them. The protocol menu only chooses which one is highlighted and animated.

**What is the seed?** A number that makes randomness repeatable - like a particular shuffle of a deck of cards. Same seed = same shuffle = same result.
It decides (a) which buildings are used when you ask for fewer tanks than the real map has, (b) the random positions in a Random block,
(c) LEACH's random choice of cluster heads and (d) the water levels of the tanks. With the real map and all 80 tanks, PEGASIS-family lifetimes
do not depend on the seed (nothing random is left) - that is correct, not a bug.

**Are the numbers pre-calculated?** Yes: the whole life of a network is simulated at once when you load a deployment, and the dashboard (Replay or Live)
steps through that saved simulation. It is a simulator / digital twin: no real sensor data enters the system. Live mode means *time is driven by Node-RED*.

**What do the notifications mean?** Every 2 s Node-RED advances the clock by 5 hours and looks at the tanks that nodes can still report.
"Tank #7 OVERFLOW (100 %)" = that tank is full while water is being supplied (water is being wasted); "Tank #24 LOW (11.6 %)" = nearly empty.
Only alerts that were NOT present in the previous tick are sent, otherwise the list would repeat itself forever. "(hour 380)" = simulated hour.

**Where is the database file?** The server prints it when it starts ("Database file: ...\engine\wsn.db"); it is created on the first run, inside the `engine` folder.
**Why can't I read wsn.db?** It is a SQLite database file. Use the CSV download link on the dashboard (port 8000) or the free program "DB Browser for SQLite".

**Why does Live mode always start with PEGASIS-E?** It is the default session. Click another **START live: ...** button in Node-RED to change it.

**Why did the notifications card show old messages before I started Node-RED?** They are stored in the database. Now the card shows only messages received
since the server was started (they stay in the database and in the CSV export).

**Why does the Tanks box say 100 but the display says 80?** The real map has 80 buildings; the box is corrected to 80 when you load the real map.

**When does something get saved in the database?** (a) the **Load / reset** button; (b) automatically when you change the **Layout** or **Protocol**
menu (the page reloads); (c) when a live session starts. Typing in **Seed** or **Tanks** saves nothing until you press Load / reset - but if you change the
Layout menu after typing a seed, that intermediate combination is loaded and saved too (that is where "I never played that one" rows come from).
Loading a deployment simulates and saves all 6 protocols at once; the **Activity log** and the **Opened with** column tell you which protocol you had selected.

**How do I know a run came from Node-RED / live mode?** Live mode does not create new simulations, it steps through the saved run of its deployment,
so it never adds rows to the runs table. What it adds is an entry in the **Activity log** ("Live session started ... by node-red" or "by dashboard"),
plus its notifications. In the deployments table, **Opened with** shows e.g. `LEACH (Live by node-red)`.

## Pre-submission checklist
1. `python tests/test_platform.py` prints `OK` (30 tests).  2. Dashboard: Replay Play works; Live: Start, Pause, Resume work; `http://127.0.0.1:1880/wsn` shows the same page.
3. Node-RED: Import the flow, Deploy, click START live: LEACH and PAUSE / RESUME once.  4. Report: compile on Overleaf (pdfLaTeX), check the references against their sources.
