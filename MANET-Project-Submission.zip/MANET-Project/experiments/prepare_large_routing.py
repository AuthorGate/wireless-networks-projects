import json
import networkx as nx
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"

SIZES = [25, 50]
SEED = 42


def load_json(path):

    with open(path) as f:
        return json.load(f)


def save_json(path, data):

    with open(path, "w") as f:
        json.dump(data, f, indent=4)


def build_graph(network):

    G = nx.Graph()

    G.add_nodes_from(
        node["id"] for node in network["nodes"]
    )

    for link in network["links"]:

        G.add_edge(
            link["source"],
            link["target"],
            loss=link["path_loss_db"]
        )

    return G


def create_backbone(G, clusters, previous):

    B = nx.Graph()
    B.add_nodes_from(G.nodes)

    membership = {}

    for head, members in clusters.items():

        for node in members:

            membership[node] = head

            if node != head:

                B.add_edge(
                    head,
                    node,
                    loss=G[head][node]["loss"]
                )

    assert set(membership) == set(G.nodes)

    gateways = {}

    for a, b in G.edges:

        head_a = membership[a]
        head_b = membership[b]

        if head_a == head_b:
            continue

        pair = tuple(sorted((head_a, head_b)))

        score = (
            0 if previous.has_edge(a, b) else 1,
            G[a][b]["loss"],
            min(a, b),
            max(a, b)
        )

        if pair not in gateways or score < gateways[pair][0]:

            gateways[pair] = (score, a, b)

    for score, a, b in gateways.values():

        B.add_edge(
            a,
            b,
            loss=G[a][b]["loss"]
        )

    original = {
        frozenset(c)
        for c in nx.connected_components(G)
    }

    selected = {
        frozenset(c)
        for c in nx.connected_components(B)
    }

    assert original == selected

    return B


def export_graph(G):

    return {

        "nodes": [
            {"id": node}
            for node in G.nodes
        ],

        "links": [
            {
                "source": a,
                "target": b
            }
            for a, b in G.edges
        ]
    }


clusters_data = load_json(
    RESULTS / "scalable_clusters_multi_seed.json"
)


for n in SIZES:

    folder = RESULTS / "large_routing" / str(n)
    folder.mkdir(parents=True, exist_ok=True)

    static = load_json(
        RESULTS / f"static_{n}_seed{SEED}.json"
    )

    mobile = load_json(
        RESULTS / f"mobile_{n}_seed{SEED}.json"
    )

    old = build_graph(static)
    new = build_graph(mobile)

    assert len(old) == n
    assert len(new) == n

    assert nx.is_connected(old)
    assert nx.is_connected(new)

    clusters = clusters_data[f"{n}_seed{SEED}"]

    initial = create_backbone(
        old,
        clusters["initial"],
        old
    )

    traditional = create_backbone(
        new,
        clusters["traditional"],
        old
    )

    adaptive = create_backbone(
        new,
        clusters["adaptive"],
        old
    )

    save_json(
        folder / "urban_t0.json",
        export_graph(old)
    )

    save_json(
        folder / "urban_t15.json",
        export_graph(new)
    )

    backbones = [

        {
            "time": 0,
            "traditional": export_graph(initial),
            "adaptive": export_graph(initial)
        },

        {
            "time": 15,
            "traditional": export_graph(traditional),
            "adaptive": export_graph(adaptive)
        }

    ]

    save_json(
        folder / "routing_backbones.json",
        backbones
    )

    print("\nNetwork Size:", n)
    print("---------------------------")
    print("Static links:", old.number_of_edges())
    print("Mobile links:", new.number_of_edges())
    print("Initial backbone:", initial.number_of_edges())
    print("Traditional backbone:", traditional.number_of_edges())
    print("SAAC backbone:", adaptive.number_of_edges())
    print("Traditional connected:", nx.is_connected(traditional))
    print("SAAC connected:", nx.is_connected(adaptive))
    print("Saved:", folder)


print("\nLarge routing networks prepared successfully")