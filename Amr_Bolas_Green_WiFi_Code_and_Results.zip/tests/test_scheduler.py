import csv
import tempfile
import unittest
from dataclasses import replace
from datetime import datetime, timedelta
from pathlib import Path

from greenwifi.scheduler import SchedulerConfig, evaluate, load_trace


class SchedulerTests(unittest.TestCase):
    def setUp(self):
        self.cfg = SchedulerConfig(
            interval_minutes=15,
            low_traffic_mbps=2.0,
            wake_traffic_mbps=5.0,
            low_channel_load_pct=15.0,
            wake_channel_load_pct=35.0,
            min_consecutive_low_windows=2,
            min_backup_rssi_dbm=-67,
            max_projected_backup_load_pct=70.0,
            minimum_active_aps=1,
            active_power_w=8.0,
            radio_sleep_power_w=5.0,
        )

    @staticmethod
    def row(ts, ap, **kwargs):
        base = {
            "timestamp": ts,
            "ap_id": ap,
            "clients": 1,
            "traffic_mbps": 0.5,
            "channel_load_pct": 4,
            "critical_clients": 0,
            "best_backup_rssi_dbm": -60,
            "backup_ap_id": "AP-1" if ap != "AP-1" else "",
            "backup_base_load_pct": 20,
            "backup_increment_pct": 10,
        }
        base.update(kwargs)
        return base

    def make_two_windows(self, candidate_overrides=None):
        rows = []
        start = datetime(2026, 1, 1, 0, 0)
        for idx in range(2):
            ts = (start + timedelta(minutes=15 * idx)).isoformat(sep=" ")
            rows += [
                self.row(ts, "AP-1", critical_clients=1, traffic_mbps=8, channel_load_pct=30, backup_ap_id="", backup_increment_pct=0),
                self.row(ts, "AP-2", **(candidate_overrides or {})),
            ]
        return rows

    def test_sleep_after_consecutive_low_windows(self):
        decisions, summary = evaluate(self.make_two_windows(), self.cfg)
        ap2 = [d for d in decisions if d["ap_id"] == "AP-2"]
        self.assertEqual([d["action"] for d in ap2], ["KEEP_ON", "SLEEP_RECOMMENDED"])
        self.assertGreater(summary["estimated_energy_saved_wh"], 0)

    def test_protected_clients_prevent_sleep(self):
        decisions, _ = evaluate(self.make_two_windows({"critical_clients": 1}), self.cfg)
        self.assertTrue(all(d["action"] == "KEEP_ON" for d in decisions if d["ap_id"] == "AP-2"))

    def test_weak_backup_signal_prevents_sleep(self):
        decisions, _ = evaluate(self.make_two_windows({"best_backup_rssi_dbm": -78}), self.cfg)
        self.assertTrue(all(d["action"] == "KEEP_ON" for d in decisions if d["ap_id"] == "AP-2"))

    def test_backup_capacity_prevents_sleep(self):
        decisions, _ = evaluate(self.make_two_windows({"backup_base_load_pct": 65, "backup_increment_pct": 10}), self.cfg)
        self.assertTrue(all(d["action"] == "KEEP_ON" for d in decisions if d["ap_id"] == "AP-2"))

    def test_minimum_active_ap_floor(self):
        # Both APs are quiet, but AP-1 is also eligible after its configured
        # critical-client guard is removed. The policy must keep one AP active.
        rows = []
        start = datetime(2026, 1, 1, 0, 0)
        for idx in range(2):
            ts = (start + timedelta(minutes=15 * idx)).isoformat(sep=" ")
            rows.append(self.row(ts, "AP-1", backup_ap_id="", backup_increment_pct=0))
            rows.append(self.row(ts, "AP-2"))
        decisions, _ = evaluate(rows, self.cfg)
        last = [d for d in decisions if d["timestamp"].endswith("00:15:00")]
        sleep_count = sum(d["action"] == "SLEEP_RECOMMENDED" for d in last)
        self.assertLessEqual(sleep_count, 1)


    def test_backup_target_is_not_scheduled_to_sleep(self):
        rows = []
        start = datetime(2026, 1, 1, 0, 0)
        for idx in range(2):
            ts = (start + timedelta(minutes=15 * idx)).isoformat(sep=" ")
            # AP-1 is itself quiet and would otherwise be a candidate, but AP-2
            # still relies on AP-1 as its alternate target. Both must not sleep.
            rows.append(self.row(ts, "AP-1", backup_ap_id="AP-3", backup_base_load_pct=10))
            rows.append(self.row(ts, "AP-2", backup_ap_id="AP-1", backup_base_load_pct=10))
            rows.append(self.row(ts, "AP-3", clients=0, backup_ap_id="", best_backup_rssi_dbm=-100))
        decisions, _ = evaluate(rows, self.cfg)
        last = [d for d in decisions if d["timestamp"].endswith("00:15:00")]
        ap1 = next(d for d in last if d["ap_id"] == "AP-1")
        self.assertEqual(ap1["action"], "KEEP_ON")
        self.assertIn("depends on this AP", ap1["reason"])


    def test_irregular_sampling_gap_resets_low_demand_counter(self):
        rows = []
        start = datetime(2026, 1, 1, 0, 0)
        for offset in (0, 30):  # A 15-minute window is missing.
            ts = (start + timedelta(minutes=offset)).isoformat(sep=" ")
            rows.append(self.row(ts, "AP-1", critical_clients=1, traffic_mbps=8, channel_load_pct=30, backup_ap_id="", backup_increment_pct=0))
            rows.append(self.row(ts, "AP-2"))
        decisions, _ = evaluate(rows, self.cfg)
        ap2 = [d for d in decisions if d["ap_id"] == "AP-2"]
        self.assertEqual([d["action"] for d in ap2], ["KEEP_ON", "KEEP_ON"])
        self.assertIn("stable low demand (1/2)", ap2[-1]["reason"])

    def test_unknown_backup_ap_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "backup_ap_id"):
            evaluate(self.make_two_windows({"backup_ap_id": "AP-UNKNOWN"}), self.cfg)

    def test_fractional_client_count_is_rejected(self):
        row = {
            "timestamp": "2026-01-01T00:00:00",
            "ap_id": "AP-1",
            "clients": "1.5",
            "traffic_mbps": "0.1",
            "channel_load_pct": "2",
            "critical_clients": "0",
            "best_backup_rssi_dbm": "-65",
            "backup_ap_id": "",
            "backup_base_load_pct": "0",
            "backup_increment_pct": "0",
        }
        with tempfile.TemporaryDirectory() as tmp:
            csv_path = Path(tmp) / "trace.csv"
            with csv_path.open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(row))
                writer.writeheader()
                writer.writerow(row)
            with self.assertRaisesRegex(ValueError, "whole numbers"):
                load_trace(csv_path)

    def test_invalid_threshold_order_is_rejected(self):
        bad_cfg = replace(self.cfg, low_traffic_mbps=6.0, wake_traffic_mbps=5.0)
        with self.assertRaisesRegex(ValueError, "low_traffic_mbps"):
            evaluate(self.make_two_windows(), bad_cfg)

    def test_traffic_spike_resets_low_counter(self):
        rows = self.make_two_windows()
        ts = "2026-01-01 00:30:00"
        rows.extend([
            self.row(ts, "AP-1", critical_clients=1, traffic_mbps=8, channel_load_pct=30, backup_ap_id="", backup_increment_pct=0),
            self.row(ts, "AP-2", traffic_mbps=6, channel_load_pct=40),
        ])
        decisions, _ = evaluate(rows, self.cfg)
        ap2 = [d for d in decisions if d["ap_id"] == "AP-2"]
        self.assertEqual(ap2[-1]["action"], "KEEP_ON")


if __name__ == "__main__":
    unittest.main()
