// js_smoke.js -- runs the dashboard's JavaScript against the REAL engine with a fake DOM.
// It cannot check how things LOOK, but it proves the code runs without exceptions,
// fetches the right URLs, and draws every protocol at several rounds.
// usage: node js_smoke.js <port>
const fs = require("fs"), vm = require("vm"), path = require("path");
const port = process.argv[2];
const html = fs.readFileSync(path.join(__dirname, "..", "dashboard", "index.html"), "utf8");
const script = html.split("<script>")[1].split("</script>")[0];

const drawCalls = { n: 0 };
const ctx = new Proxy({}, { get: (t, k) => (k in t ? t[k] : (...a) => { drawCalls.n++; }), set: (t, k, v) => { t[k] = v; return true; } });
const values = { protocol: "PEGASIS", seed: "0", n: "100", speed: "5", slider: "0", layout: "random", mode: "replay" };
function el(id) {
  const o = { style: {}, value: values[id] || "", textContent: "", innerHTML: "", width: 520, height: 640, max: 0,
    getContext: () => ctx, querySelector: () => el(id + "_q"), appendChild: () => {}, getBoundingClientRect: () => ({ left: 0, top: 0, width: 520 }) };
  return o;
}
const els = {};
const document = { getElementById: id => (els[id] = els[id] || el(id)), createElement: () => el("tmp") };
const sandbox = { window: { __NO_AUTOINIT__: true }, document, location: { pathname: "/" }, console,
  fetch: (u, o) => fetch("http://127.0.0.1:" + port + u, o), setInterval, clearInterval, Math, JSON, Promise };
vm.createContext(sandbox);
vm.runInContext(script, sandbox);

(async () => {
  let failures = 0;
  const check = (name, cond) => { if (!cond) failures++; console.log((cond ? "[PASS] " : "[FAIL] ") + name); };
  for (const proto of ["PEGASIS", "PEGASIS-2opt", "PEGASIS-E", "PEGASIS-MC", "LEACH", "Direct"]) {
    els["protocol"] = el("protocol"); els["protocol"].value = proto; values.protocol = proto;
    await vm.runInContext("load()", sandbox);
    const rounds = vm.runInContext("S.rounds", sandbox);
    check(proto + ": loaded run with rounds > 100 (" + rounds + ")", rounds > 100);
    for (const r of [0, 1, Math.floor(rounds / 2), rounds]) {
      await vm.runInContext("showRound(" + r + ")", sandbox);
      const got = vm.runInContext("S.state.round", sandbox);
      check(proto + ": showRound(" + r + ") -> state.round " + got, got === r);
    }
    check(proto + ": KPI text written", String(els["k_alive"].textContent).includes("/"));
    const body = String(els["cmpbody"].innerHTML);
    const selRows = body.match(/<tr class="sel">/g) || [];
    check(proto + ": comparison table has 6 rows and exactly the selected protocol highlighted",
          (body.match(/<tr /g) || []).length === 6 && selRows.length === 1 && new RegExp('<tr class="sel"><td[^>]*><b>' + proto + '</b>').test(body));
    check(proto + ": insight panel names this protocol and gives the three lifetimes", String(els["insight"].innerHTML).includes("<b>" + proto + "</b>") && /first<\/b> tank loses/.test(String(els["insight"].innerHTML)));
    check(proto + ": hint under 'Tanks' explains what seed/n do", /Random block/.test(String(els["nhint"].textContent)));
    check(proto + ": saved-runs card shows the database", String(els["hist"].innerHTML).includes("deployments are stored in engine/wsn.db"));
  }
  check("canvas drawing calls happened (" + drawCalls.n + ")", drawCalls.n > 1000);
  // LIVE mode: pretend to be Node-RED (reset + a few steps), then let the page poll the live session
  const postTo = p => fetch("http://127.0.0.1:" + port + p, { method: "POST" }).then(x => x.json());
  await postTo("/api/live/reset?protocol=LEACH&layout=random&seed=5&n=50");
  for (let i = 0; i < 4; i++) await postTo("/api/live/step?steps=10");
  check("activity log shows the replay loads with the selected protocol", /Replay loaded<\/b> - /.test(String(els["activity"].innerHTML)));
  // fresh session that has not been started yet -> READY message
  await postTo("/api/live/reset?protocol=LEACH&layout=random&seed=5&n=50");
  await postTo("/api/live/pause?on=1");
  els["mode"] = el("mode"); els["mode"].value = "live"; values.mode = "live";
  await vm.runInContext("setMode()", sandbox);
  check("live mode on a fresh session says READY and shows Start/Resume controls",
        /^READY/.test(String(els["livebar"].textContent)) && els["liveStart"].style.display === "inline-block" && els["livePause"].textContent === "Resume");
  // the dashboard's own Start button (instead of a Node-RED button) starts a session with the chosen settings
  els["protocol"].value = "PEGASIS"; els["layout"].value = "random"; els["seed"].value = "8"; els["n"].value = "45";
  await vm.runInContext("startLive()", sandbox);
  const started = await (await fetch("http://127.0.0.1:" + port + "/api/live")).json();
  check("Start button begins a live session with the chosen protocol/seed/tanks, un-paused, at round 0",
        started.protocol === "PEGASIS" && started.seed === 8 && started.round === 0 && started.paused === false);
  check("activity log shows the live start, with its source (dashboard) and protocol", /Live session started<\/b> - PEGASIS, random, 45 tanks, seed 8 <i>\(by dashboard\)/.test(String(els["activity"].innerHTML)));
  await postTo("/api/live/step?steps=10");
  await vm.runInContext("liveTick()", sandbox);
  await vm.runInContext("togglePause()", sandbox);
  check("Pause button freezes the clock and the bar says PAUSED", /^PAUSED/.test(String(els["livebar"].textContent)) && els["livePause"].textContent === "Resume");
  await vm.runInContext("togglePause()", sandbox);
  check("Resume button continues (bar no longer paused)", !/^PAUSED/.test(String(els["livebar"].textContent)) && els["livePause"].textContent === "Pause");
  await postTo("/api/live/reset?protocol=LEACH&layout=random&seed=5&n=50");
  for (let i = 0; i < 4; i++) await postTo("/api/live/step?steps=10");
  els["mode"].value = "replay"; values.mode = "replay";
  await vm.runInContext("setMode()", sandbox);
  els["mode"].value = "live"; values.mode = "live";
  await vm.runInContext("setMode()", sandbox);
  check("live mode follows the engine's session (protocol, round 40)", vm.runInContext("S.protocol", sandbox) === "LEACH" && vm.runInContext("S.round", sandbox) === 40);
  check("live status bar says LIVE after recent steps", /^LIVE/.test(String(els["livebar"].textContent)) && /live/.test(String(els["livebar"].className)));
  check("live mode disables the replay controls (Load, Play, slider) but keeps the session settings editable on port 8000",
        els["load"].disabled === true && els["play"].disabled === true && els["slider"].disabled === true && els["protocol"].disabled === false);
  await postTo("/api/notify?hour=40&text=Tank%20%237%20LOW");
  await vm.runInContext("liveTick()", sandbox);
  check("notification pushed by Node-RED appears in the dashboard card", /Tank #7 LOW/.test(String(els["notes"].innerHTML)));
  els["mode"].value = "replay"; values.mode = "replay";
  await vm.runInContext("setMode()", sandbox);
  check("switching back to replay re-enables the controls", els["load"].disabled === false && els["play"].disabled === false);
  // the page must work under BOTH addresses: http://127.0.0.1:8000/  and  http://127.0.0.1:1880/wsn
  for (const [path, base] of [["/", "/"], ["/wsn", "/wsn/"], ["/wsn/", "/wsn/"]]) {
    const sb = { window: { __NO_AUTOINIT__: true }, document, location: { pathname: path }, console, fetch: sandbox.fetch, setInterval, clearInterval, Math, JSON, Promise };
    vm.createContext(sb); vm.runInContext(script, sb);
    check("BASE for page path '" + path + "' is '" + base + "'", vm.runInContext("BASE", sb) === base);
  }
  // every API name the dashboard calls must exist on the engine
  const used = [...new Set([...script.matchAll(/api\("(\w+)"/g)].map(m => m[1]))];
  for (const name of used) {
    const r = await fetch("http://127.0.0.1:" + port + "/api/" + name + "?protocol=PEGASIS&seed=0&n=100&round=1&limit=3");
    check("engine route /api/" + name + " exists (dashboard uses it) -> HTTP " + r.status, r.status === 200);
  }
  // banner shown when engine is unreachable
  sandbox.fetch = () => Promise.reject(new Error("offline"));
  await vm.runInContext("load()", sandbox);
  check("offline engine -> banner shows error", els["banner"].textContent.includes("Cannot reach"));
  console.log(failures ? "JS SMOKE FAILED" : "JS SMOKE OK");
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error("EXCEPTION", e); process.exit(1); });
