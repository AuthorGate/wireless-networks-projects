import json
import plotly.graph_objects as go

from plotly.subplots import make_subplots
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/urban_clusters.json") as f:
    data = json.load(f)

snapshots = data["snapshots"]
buildings = data["buildings"]

colors = [
    "#38bdf8",
    "#f59e0b",
    "#22c55e",
    "#a855f7",
    "#ec4899",
    "#eab308",
    "#14b8a6",
    "#6366f1",
    "#fb923c"
]

fig = make_subplots(
    rows=1,
    cols=2,
    specs=[[{"type": "scene"}, {"type": "scene"}]],
    subplot_titles=[
        "Traditional Clustering",
        "Proposed SAAC Algorithm"
    ],
    horizontal_spacing=0.02
)


def draw_buildings(col):

    for building in buildings:

        if building["name"] == "floor":
            continue

        x0, y0, z0 = building["min"]
        x1, y1, z1 = building["max"]

        fig.add_trace(
            go.Mesh3d(
                x=[x0, x1, x1, x0, x0, x1, x1, x0],
                y=[y0, y0, y1, y1, y0, y0, y1, y1],
                z=[z0, z0, z0, z0, z1, z1, z1, z1],

                i=[0, 0, 4, 4, 0, 0, 1, 1, 2, 2, 3, 3],
                j=[1, 2, 5, 6, 1, 5, 2, 6, 3, 7, 0, 4],
                k=[2, 3, 6, 7, 5, 4, 6, 5, 7, 6, 4, 7],

                color="#94a3b8",
                opacity=0.20,
                flatshading=True,
                name=building["name"],
                hoverinfo="name",
                showlegend=False
            ),
            row=1,
            col=col
        )


draw_buildings(1)
draw_buildings(2)


def cluster_color(head):
    return colors[int(head, 16) % len(colors)]


def network_traces(snapshot, algorithm, scene_name):

    clusters = snapshot[algorithm + "_clusters"]

    nodes = snapshot["nodes"]
    links = snapshot["links"]

    positions = {n["id"]: n for n in nodes}

    heads = set(clusters)

    isolated = set(
        snapshot["statistics"]["isolated_nodes"]
    )

    membership = {}

    for head, members in clusters.items():
        for node in members:
            membership[node] = head

    internal = [[], [], []]
    external = [[], [], []]

    for link in links:

        a = positions[link["source"]]
        b = positions[link["target"]]

        same_cluster = (
            membership[a["id"]] ==
            membership[b["id"]]
        )

        target = internal if same_cluster else external

        target[0].extend([a["x"], b["x"], None])
        target[1].extend([a["y"], b["y"], None])
        target[2].extend([a["z"], b["z"], None])

    internal_trace = go.Scatter3d(
        x=internal[0],
        y=internal[1],
        z=internal[2],
        mode="lines",
        line=dict(color="#22c55e", width=4),
        name="Intra-Cluster Links",
        hoverinfo="skip",
        scene=scene_name,
        showlegend=False
    )

    external_trace = go.Scatter3d(
        x=external[0],
        y=external[1],
        z=external[2],
        mode="lines",
        line=dict(
            color="#64748b",
            width=3,
            dash="dash"
        ),
        name="Inter-Cluster Links",
        hoverinfo="skip",
        scene=scene_name,
        showlegend=False
    )

    node_colors = []
    node_sizes = []
    node_symbols = []
    labels = []
    hover = []

    for node in nodes:

        n = node["id"]
        head = membership[n]

        if n in isolated:

            node_colors.append("#ef4444")
            node_sizes.append(10)
            node_symbols.append("x")
            labels.append(n)
            role = "Isolated Node"

        elif n in heads:

            node_colors.append(cluster_color(head))
            node_sizes.append(13)
            node_symbols.append("diamond")
            labels.append("CH " + n)
            role = "Cluster Head"

        else:

            node_colors.append(cluster_color(head))
            node_sizes.append(7)
            node_symbols.append("circle")
            labels.append(n)
            role = "Cluster Member"

        hover.append(
            f"Node: {n}<br>"
            f"Role: {role}<br>"
            f"Cluster Head: {head}"
        )

    node_trace = go.Scatter3d(

        x=[n["x"] for n in nodes],
        y=[n["y"] for n in nodes],
        z=[n["z"] for n in nodes],

        ids=[n["id"] for n in nodes],

        mode="markers+text",
        text=labels,
        textposition="top center",
        hovertext=hover,
        hoverinfo="text",

        marker=dict(
            color=node_colors,
            size=node_sizes,
            symbol=node_symbols,
            line=dict(color="white", width=1)
        ),

        scene=scene_name,
        showlegend=False
    )

    return [
        internal_trace,
        external_trace,
        node_trace
    ]


def get_traces(snapshot):

    return (
        network_traces(
            snapshot, "traditional", "scene"
        ) +
        network_traces(
            snapshot, "adaptive", "scene2"
        )
    )


def frame_title(snapshot):

    stats = snapshot["clustering_statistics"]

    return (
        f"MANET 3D Simulation | "
        f"Time: {snapshot['time']} s"
        f" | Links: {len(snapshot['links'])}"
        "<br>"
        f"Traditional: {stats['traditional_clusters']} clusters"
        f" | SAAC: {stats['adaptive_clusters']} clusters"
    )


first_trace = len(fig.data)

for i, trace in enumerate(get_traces(snapshots[0])):

    fig.add_trace(
        trace,
        row=1,
        col=1 if i < 3 else 2
    )


fig.frames = [

    go.Frame(
        name=str(snapshot["time"]),
        data=get_traces(snapshot),

        traces=list(
            range(first_trace, first_trace + 6)
        ),

        layout=go.Layout(
            title_text=frame_title(snapshot)
        )
    )

    for snapshot in snapshots
]


slider_steps = []

for snapshot in snapshots:

    slider_steps.append(dict(

        label=str(snapshot["time"]) + "s",
        method="animate",

        args=[
            [str(snapshot["time"])],
            {
                "mode": "immediate",
                "frame": {
                    "duration": 0,
                    "redraw": True
                },
                "transition": {"duration": 0}
            }
        ]
    ))


scene_settings = dict(

    xaxis=dict(title="X (m)", range=[-95, 95]),
    yaxis=dict(title="Y (m)", range=[-62, 62]),
    zaxis=dict(title="Z (m)", range=[0, 55]),

    aspectmode="data",

    camera=dict(
        eye=dict(x=1.4, y=-1.6, z=1.6)
    ),

    uirevision="urban"
)


fig.update_layout(

    title=dict(
        text=frame_title(snapshots[0]),
        x=0.5,
        font=dict(size=20)
    ),

    template="plotly_dark",
    paper_bgcolor="#0b1120",

    scene=scene_settings,
    scene2=scene_settings,

    height=800,

    updatemenus=[dict(

        type="buttons",
        direction="left",

        x=0.05,
        y=0,

        buttons=[

            dict(
                label="Play",
                method="animate",
                args=[
                    None,
                    {
                        "frame": {
                            "duration": 1000,
                            "redraw": True
                        },
                        "transition": {"duration": 0},
                        "fromcurrent": True
                    }
                ]
            ),

            dict(
                label="Pause",
                method="animate",
                args=[
                    [None],
                    {
                        "mode": "immediate",
                        "frame": {
                            "duration": 0,
                            "redraw": True
                        },
                        "transition": {"duration": 0}
                    }
                ]
            )
        ]
    )],

    sliders=[dict(
        active=0,
        currentvalue={"prefix": "Time: "},
        steps=slider_steps
    )],

    margin=dict(l=0, r=0, t=120, b=100)
)


fig.write_html(
    str(ROOT / "figures/urban_clustering_3d.html"),
    include_plotlyjs=True,
    auto_play=False
)

print("3D Clustering Comparison Created")
print("Total frames:", len(snapshots))
print("Saved: figures/urban_clustering_3d.html")