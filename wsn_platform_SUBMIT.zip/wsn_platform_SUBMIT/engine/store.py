"""
store.py -- SQLite experiment store (standard library only).
Every simulated run that the API computes is saved, so results survive restarts and can be listed / compared later.

  runs(id, key UNIQUE, created, protocol, layout, seed, n, rounds, fnd, hnd, lnd, avg_hops, sink_packets, readings)
  curves(run_id -> runs.id ON DELETE CASCADE, alive JSON, energy JSON)

All SQL uses ? placeholders (parameterised queries), so user input can never change the SQL statement.
"""
import csv, io, json, os, sqlite3, time
from contextlib import closing

HERE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("WSN_DB", os.path.join(HERE, "wsn.db"))
SCHEMA = """
CREATE TABLE IF NOT EXISTS runs(
  id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT UNIQUE NOT NULL, created TEXT NOT NULL,
  protocol TEXT NOT NULL, layout TEXT NOT NULL, seed INTEGER NOT NULL, n INTEGER NOT NULL, rounds INTEGER,
  fnd INTEGER, hnd INTEGER, lnd INTEGER, avg_hops REAL, sink_packets INTEGER, readings INTEGER);
CREATE TABLE IF NOT EXISTS curves(
  run_id INTEGER PRIMARY KEY REFERENCES runs(id) ON DELETE CASCADE, alive TEXT NOT NULL, energy TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS activity(
  id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL, kind TEXT NOT NULL, protocol TEXT, layout TEXT,
  n INTEGER, seed INTEGER, source TEXT NOT NULL, detail TEXT);
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL, hour INTEGER, source TEXT NOT NULL, text TEXT NOT NULL);
"""


def connect():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys = ON")
    c.executescript(SCHEMA)
    return c


def save_run(s: dict, layout: str) -> int:
    """Insert (or replace) one run summary produced by platform_core.summary()."""
    key = f"{s['protocol']}|{layout}|{s['seed']}|{s['n']}"
    with closing(connect()) as c, c:
        c.execute("DELETE FROM runs WHERE key = ?", (key,))          # replacing also deletes the old curve (CASCADE)
        cur = c.execute(
            "INSERT INTO runs(key, created, protocol, layout, seed, n, rounds, fnd, hnd, lnd, avg_hops, sink_packets, readings)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (key, time.strftime("%Y-%m-%d %H:%M:%S"), s["protocol"], layout, s["seed"], s["n"], s["rounds"],
             s["fnd"], s["hnd"], s["lnd"], s["avg_hops"], s["sink_packets"], s["readings"]))
        c.execute("INSERT INTO curves(run_id, alive, energy) VALUES (?,?,?)",
                  (cur.lastrowid, json.dumps(s["alive_curve"]), json.dumps(s["energy_curve"])))
        return cur.lastrowid


def history(limit: int = 20, protocol: str | None = None) -> list:
    sql = "SELECT id, created, protocol, layout, seed, n, rounds, fnd, hnd, lnd, avg_hops FROM runs"
    args: tuple = ()
    if protocol:
        sql += " WHERE protocol = ?"
        args = (protocol,)
    sql += " ORDER BY id DESC LIMIT ?"
    with closing(connect()) as c:
        return [dict(r) for r in c.execute(sql, args + (int(limit),))]


def curve(run_id: int):
    with closing(connect()) as c:
        r = c.execute("SELECT r.protocol, r.layout, r.seed, r.n, c.alive, c.energy FROM runs r JOIN curves c ON c.run_id = r.id"
                      " WHERE r.id = ?", (int(run_id),)).fetchone()
    if r is None:
        return None
    return dict(id=int(run_id), protocol=r["protocol"], layout=r["layout"], seed=r["seed"], n=r["n"],
                alive=json.loads(r["alive"]), energy=json.loads(r["energy"]))


def add_notification(text: str, hour: int | None = None, source: str = "node-red") -> int:
    """Store a message pushed to the engine from outside (Node-RED's alert flow)."""
    with closing(connect()) as c, c:
        cur = c.execute("INSERT INTO notifications(created, hour, source, text) VALUES (?,?,?,?)",
                        (time.strftime("%Y-%m-%d %H:%M:%S"), hour, source[:40], text[:500]))
        c.execute("DELETE FROM notifications WHERE id <= ?", (cur.lastrowid - 500,))      # keep the latest 500 only
        return cur.lastrowid


def notifications(limit: int = 10, since: str | None = None) -> list:
    """Latest notifications; `since` = 'YYYY-MM-DD HH:MM:SS' keeps only those created at or after that moment."""
    sql, args = "SELECT id, created, hour, source, text FROM notifications", ()
    if since:
        sql += " WHERE created >= ?"
        args = (since,)
    with closing(connect()) as c:
        return [dict(r) for r in c.execute(sql + " ORDER BY id DESC LIMIT ?", args + (int(limit),))]


def deployments(limit: int = 8) -> dict:
    """One row per DEPLOYMENT (layout, number of tanks, seed) instead of one row per protocol:
    which protocols were simulated on it and which one won each lifetime metric."""
    with closing(connect()) as c:
        rows = c.execute("SELECT created, protocol, layout, n, seed, fnd, hnd, lnd FROM runs ORDER BY id").fetchall()
        acts = c.execute("SELECT kind, protocol, layout, n, seed, source FROM activity "
                         "WHERE kind IN ('replay-load', 'live-start') ORDER BY id").fetchall()
    opened = {(a["layout"], a["n"], a["seed"]): dict(protocol=a["protocol"],
              mode="Replay" if a["kind"] == "replay-load" else "Live by " + a["source"]) for a in acts}
    groups: dict = {}
    for r in rows:
        g = groups.setdefault((r["layout"], r["n"], r["seed"]),
                              dict(layout=r["layout"], n=r["n"], seed=r["seed"], protocols=0, created=r["created"], best={},
                                   opened_with=opened.get((r["layout"], r["n"], r["seed"]))))
        g["protocols"] += 1
        g["created"] = max(g["created"], r["created"])
        for m in ("fnd", "hnd", "lnd"):
            v = r[m]
            if v is not None and (m not in g["best"] or v > g["best"][m]["value"]):
                g["best"][m] = dict(protocol=r["protocol"], value=v)
    out = sorted(groups.values(), key=lambda g: g["created"], reverse=True)[: int(limit)]
    return dict(deployments=out, total_runs=len(rows), total_deployments=len(groups))


def log_activity(kind: str, protocol=None, layout=None, n=None, seed=None, source: str = "dashboard", detail: str = "") -> int:
    """Record WHAT WAS DONE: replay-load / live-start / live-pause / live-resume, with the selected protocol and the source."""
    with closing(connect()) as c, c:
        cur = c.execute("INSERT INTO activity(created, kind, protocol, layout, n, seed, source, detail) VALUES (?,?,?,?,?,?,?,?)",
                        (time.strftime("%Y-%m-%d %H:%M:%S"), kind[:30], protocol, layout, n, seed, source[:20], detail[:200]))
        c.execute("DELETE FROM activity WHERE id <= ?", (cur.lastrowid - 2000,))
        return cur.lastrowid


def activity(limit: int = 10) -> list:
    with closing(connect()) as c:
        return [dict(r) for r in c.execute(
            "SELECT id, created, kind, protocol, layout, n, seed, source FROM activity ORDER BY id DESC LIMIT ?", (int(limit),))]


def export_activity_csv() -> str:
    with closing(connect()) as c:
        rows = c.execute("SELECT id, created, kind, protocol, layout, n, seed, source FROM activity ORDER BY id").fetchall()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "created", "action", "selected_protocol", "layout", "tanks", "seed", "source"])
    for r in rows:
        w.writerow(list(r))
    return buf.getvalue()


def export_csv() -> str:
    """Every saved run as CSV text (opens in Excel)."""
    with closing(connect()) as c:
        rows = c.execute("SELECT id, created, protocol, layout, n, seed, rounds, fnd, hnd, lnd, avg_hops, sink_packets, readings"
                         " FROM runs ORDER BY id").fetchall()
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["id", "created", "protocol", "layout", "tanks", "seed", "rounds", "first_node_dead", "half_dead", "last_dead",
                "avg_hops_per_round", "sink_packets", "readings"])
    for r in rows:
        w.writerow(list(r))
    return buf.getvalue()


def count() -> int:
    with closing(connect()) as c:
        return c.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
