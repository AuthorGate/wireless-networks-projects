
from pathlib import Path
import csv

import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import numpy as np

# Use the original MATLAB absorption dataset directly (no copied data files).
from scipy.io import loadmat
_matlab_file = Path(__file__).resolve().parent / "data" / "molecular_absorption.mat"
_matlab_data = loadmat(_matlab_file)
_f = np.asarray(_matlab_data["f"]).reshape(-1)
_k = np.asarray(_matlab_data["k"]).reshape(-1)
if not (_f.min() <= 300e9 <= _f.max()):
    raise ValueError("300 GHz is outside the MATLAB dataset")
_k300 = float(np.interp(300e9, _f, _k))

def absorbed_path_power(radio_paths):
    # MATLAB convention: power attenuation exp(-k * distance).
    coefficients, delays = radio_paths.cir(out_type="numpy", normalize_delays=False)
    valid = radio_paths.valid.numpy().reshape(-1).astype(bool)
    powers = np.abs(coefficients.reshape(-1)[valid]) ** 2
    lengths = delays.reshape(-1)[valid] * 299792458.0
    return float(np.sum(powers * np.exp(-_k300 * lengths)))


import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sionna.rt import (
    load_scene,
    SceneObject,
    RadioMaterial,
    PlanarArray,
    Transmitter,
    Receiver,
    PathSolver
)

# ==========================================
# Experiment 07: Directional Beam Sweeping
# Frequency: 300 GHz
# ==========================================

BASE_DIR = Path(__file__).resolve().parent
ASSETS = BASE_DIR / "assets"
RESULTS = BASE_DIR / "results"
RESULTS.mkdir(exist_ok=True)

FREQUENCY = 300e9
TX_POWER_DBM = 10.0
BANDWIDTH_HZ = 1e9
NOISE_FIGURE_DB = 7.0

# 1. Create the existing blocked room
scene = load_scene()
scene.frequency = FREQUENCY

components = [
    "floor",
    "back_wall",
    "left_wall",
    "right_wall",
    "barrier"
]

def make_box(name, bounds):
    x0, x1, y0, y1, z0, z1 = bounds

    vertices = [
        (x0,y0,z0), (x1,y0,z0),
        (x1,y1,z0), (x0,y1,z0),
        (x0,y0,z1), (x1,y0,z1),
        (x1,y1,z1), (x0,y1,z1)
    ]

    faces = [
        (1,4,3), (1,3,2),
        (5,6,7), (5,7,8),
        (1,2,6), (1,6,5),
        (4,8,7), (4,7,3),
        (1,5,8), (1,8,4),
        (2,3,7), (2,7,6)
    ]

    filename = ASSETS / f"{name}.obj"

    with open(filename, "w") as file:
        for x, y, z in vertices:
            file.write(f"v {x} {y} {z}\n")

        for a, b, c in faces:
            file.write(f"f {a} {b} {c}\n")

    return str(filename)
ASSETS.mkdir(exist_ok=True)
_geometry = {
 "floor": (-1,6,-3,3,-0.2,0),
 "back_wall": (-1,6,2.9,3.1,0,3),
 "left_wall": (-1.2,-1,-3,3,0,3),
 "right_wall": (6,6.2,-3,3,0,3),
 "barrier": (2.4,2.6,-0.8,0.8,0,2.2)
}
for _name, _bounds in _geometry.items():
    if not (ASSETS / f"{_name}.obj").exists():
        make_box(_name, _bounds)


for name in components:
    mesh_file = ASSETS / f"{name}.obj"

    if not mesh_file.exists():
        raise FileNotFoundError(
            f"Missing 3D geometry: {mesh_file}"
        )

    if name == "barrier":
        color = (0.85, 0.3, 0.25)
    elif name == "floor":
        color = (0.52, 0.58, 0.63)
    else:
        color = (0.64, 0.76, 0.88)

    material = RadioMaterial(
        name=f"{name}_beam_material",
        relative_permittivity=4.0,
        conductivity=0.01,
        thickness=0.2,
        color=color
    )

    scene.add(SceneObject(
        fname=str(mesh_file),
        name=name,
        radio_material=material
    ))

# 2. Configure directional transmitter
scene.tx_array = PlanarArray(
    num_rows=1,
    num_cols=1,
    pattern="tr38901",
    polarization="V"
)

# Keep receiver isotropic
scene.rx_array = PlanarArray(
    num_rows=1,
    num_cols=1,
    pattern="iso",
    polarization="V"
)

# 3. Add devices
tx = Transmitter(
    name="tx",
    position=[0, 0, 1],
    orientation=[0, 0, 0]
)

rx = Receiver(
    name="rx",
    position=[5, 0, 1]
)

scene.add(tx)
scene.add(rx)

solver = PathSolver(deterministic=True)

# 4. Confirm direct LoS is still blocked
los_paths = solver(
    scene,
    max_depth=0,
    refraction=False
)

if np.any(los_paths.valid.numpy()):
    raise RuntimeError(
        "Expected blocked LoS, but a direct path exists"
    )

print("\n=== THz Directional Beam Sweeping ===")
print("Frequency: 300 GHz")
print("Direct LoS: Blocked")
print("Antenna: 3GPP TR 38.901 directional pattern")

# 5. Sweep transmitter pointing angles
angles = np.arange(-90, 91, 5)
results = []

for angle in angles:

    # Rotate Tx antenna around vertical axis
    tx.orientation = [
        float(np.deg2rad(angle)),
        0.0,
        0.0
    ]

    # Search for reflected propagation paths
    paths = solver(
        scene,
        max_depth=1,
        los=False,
        specular_reflection=True,
        diffuse_reflection=False,
        refraction=False,
        diffraction=False,
        seed=42
    )

    valid_count = int(
        np.count_nonzero(paths.valid.numpy())
    )

    if valid_count > 0:
        a, tau = paths.cir(out_type="numpy")

        # Noncoherent sum of path powers
        # Appropriate as a power metric;
        # not a coherent wideband channel model.
        power_gain = absorbed_path_power(paths)

        if power_gain > 0:
            link_loss_db = -10 * np.log10(power_gain)
        else:
            link_loss_db = float("inf")
    else:
        link_loss_db = float("inf")

    results.append({
        "angle": int(angle),
        "paths": valid_count,
        "loss": float(link_loss_db)
    })

    print(
        f"Angle: {angle:+4d} deg | "
        f"Paths: {valid_count:2d} | "
        f"Link Loss: {link_loss_db:.2f} dB"
    )

# 6. Select the best direction
valid_results = [
    r for r in results
    if np.isfinite(r["loss"])
]

if not valid_results:
    raise RuntimeError(
        "No usable reflected paths found"
    )

best = min(valid_results, key=lambda r: r["loss"])

baseline = next(
    r for r in results if r["angle"] == 0
)

print("\n=== Beam Selection Results ===")
print(f"Best angle: {best['angle']} degrees")
print(f"Best link loss: {best['loss']:.4f} dB")

if np.isfinite(baseline["loss"]):
    improvement = baseline["loss"] - best["loss"]
    print(
        f"Improvement vs 0 degrees: "
        f"{improvement:.4f} dB"
    )

# 7. Estimate best-angle SNR and capacity
noise_dbm = (
    -174
    + 10 * np.log10(BANDWIDTH_HZ)
    + NOISE_FIGURE_DB
)

received_dbm = TX_POWER_DBM - best["loss"]
snr_db = received_dbm - noise_dbm
snr_linear = 10 ** (snr_db / 10)

capacity_mbps = (
    BANDWIDTH_HZ * np.log2(1 + snr_linear)
) / 1e6

print(f"Best-angle SNR: {snr_db:.4f} dB")
print(
    f"Best-angle theoretical capacity: "
    f"{capacity_mbps:.4f} Mbps"
)

# 8. Save CSV results
csv_file = RESULTS / "fine_beam_sweep_300ghz.csv"

with open(csv_file, "w", newline="") as file:
    writer = csv.DictWriter(
        file,
        fieldnames=["angle", "paths", "loss"]
    )
    writer.writeheader()
    writer.writerows(results)

# 9. Presentation only: annotate the existing sweep results.
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11})
fig, ax = plt.subplots(figsize=(12, 7))
fig.subplots_adjust(left=0.10, right=0.96, top=0.76, bottom=0.28)
step = int(angles[1] - angles[0])
fig.text(0.07, 0.93, "Directional beam sweep" + (" | Fine scan" if step == 5 else " | Coarse scan"),
         fontsize=24, weight="bold", color="#172d46")
fig.text(0.07, 0.865, f"300 GHz | Direct LoS blocked | Absorption included | Angular step {step} degrees",
         fontsize=12, color="#53647a")
ax.plot([r["angle"] for r in results], [r["loss"] for r in results],
        "o-", color="#087cba", markersize=4, linewidth=2, label="Simulated link loss")
ax.axvline(best["angle"], color="#087849", linestyle="--", linewidth=1.2)
ax.scatter(best["angle"], best["loss"], s=75, color="#087849", zorder=5)
ax.annotate(f"Best sampled angle: {best['angle']} deg\nMinimum loss: {best['loss']:.4f} dB",
            xy=(best["angle"], best["loss"]), xytext=(0.61, 0.76), textcoords="axes fraction",
            bbox=dict(boxstyle="round,pad=0.5", fc="white", ec="#087849"), color="#087849",
            arrowprops=dict(arrowstyle="->", color="#087849"))
if np.isfinite(baseline["loss"]):
    ax.scatter(0, baseline["loss"], s=55, color="#b86b18", zorder=5)
    ax.annotate(f"0 deg reference\n{baseline['loss']:.4f} dB", xy=(0, baseline["loss"]),
                xytext=(0.30, 0.48), textcoords="axes fraction", color="#93500d",
                bbox=dict(boxstyle="round,pad=0.4", fc="white", ec="#b86b18"),
                arrowprops=dict(arrowstyle="->", color="#b86b18"))
ax.set(xlabel="Tx azimuth (degrees) | rotation about the vertical z-axis",
       ylabel="Effective link loss (dB) | lower is better", xlim=(-95, 95))
ax.set_ylim(min(r["loss"] for r in valid_results)-3, max(r["loss"] for r in valid_results)+3)
ax.spines[["top", "right"]].set_visible(False)
ax.grid(alpha=0.2)
ax.legend(loc="upper left", frameon=False)
fig.text(0.07, 0.16, f"At the best sampled angle: SNR {snr_db:.2f} dB | Theoretical capacity {capacity_mbps:.2f} Mbps",
         fontsize=12, color="#172d46")
fig.text(0.07, 0.105, f"Tx {TX_POWER_DBM:g} dBm | Bandwidth {BANDWIDTH_HZ/1e9:g} GHz | Noise figure {NOISE_FIGURE_DB:g} dB | Directional Tx; isotropic Rx",
         fontsize=10, color="#53647a")
fig.text(0.07, 0.055, "Angle is antenna pointing direction, not path height. Best means lowest loss among sampled angles.",
         fontsize=10, color="#53647a")
fig.savefig(csv_file.with_suffix(".png"), dpi=200, facecolor="white")
plt.close(fig)
print("Labeled beam sweep PNG saved successfully!")

