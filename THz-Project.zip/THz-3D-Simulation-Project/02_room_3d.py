
from pathlib import Path

import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import numpy as np

# Use the original MATLAB absorption dataset directly (no copied data files).
from scipy.io import loadmat
_matlab_file = Path(__file__).resolve().parent / "data" / "molecular_absorption.mat"
_matlab_data = loadmat(_matlab_file)
_f = np.asarray(_matlab_data["f"]).reshape(-1)
_k = np.asarray(_matlab_data["k"]).reshape(-1)
if not (_f.min() <= 300e9 <= _f.max()):
    raise ValueError("300 GHz is outside the MATLAB dataset")
_k300 = float(np.interp(300e9, _f, _k))

def absorbed_path_power(radio_paths):
    # MATLAB convention: power attenuation exp(-k * distance).
    coefficients, delays = radio_paths.cir(out_type="numpy", normalize_delays=False)
    valid = radio_paths.valid.numpy().reshape(-1).astype(bool)
    powers = np.abs(coefficients.reshape(-1)[valid]) ** 2
    lengths = delays.reshape(-1)[valid] * 299792458.0
    return float(np.sum(powers * np.exp(-_k300 * lengths)))


from sionna.rt import (
    load_scene, SceneObject, RadioMaterial,
    PlanarArray, Transmitter, Receiver,
    PathSolver, Camera
)

# Project folders
ASSETS = Path(__file__).resolve().parent / "assets"
RESULTS = Path(__file__).resolve().parent / "results"
ASSETS.mkdir(exist_ok=True)
RESULTS.mkdir(exist_ok=True)

FREQUENCY = 300e9

# Create a closed rectangular 3D mesh (OBJ)
def make_box(name, bounds):
    x0, x1, y0, y1, z0, z1 = bounds

    vertices = [
        (x0,y0,z0), (x1,y0,z0),
        (x1,y1,z0), (x0,y1,z0),
        (x0,y0,z1), (x1,y0,z1),
        (x1,y1,z1), (x0,y1,z1)
    ]

    faces = [
        (1,4,3), (1,3,2),
        (5,6,7), (5,7,8),
        (1,2,6), (1,6,5),
        (4,8,7), (4,7,3),
        (1,5,8), (1,8,4),
        (2,3,7), (2,7,6)
    ]

    filename = ASSETS / f"{name}.obj"

    with open(filename, "w") as file:
        for x, y, z in vertices:
            file.write(f"v {x} {y} {z}\n")

        for a, b, c in faces:
            file.write(f"f {a} {b} {c}\n")

    return str(filename)


# Initialize Sionna scene
scene = load_scene()
scene.frequency = FREQUENCY

# Room dimensions: 7 m x 6 m x 3 m
components = {
    "floor": (-1, 6, -3, 3, -0.2, 0),
    "back_wall": (-1, 6, 2.9, 3.1, 0, 3),
    "left_wall": (-1.2, -1, -3, 3, 0, 3),
    "right_wall": (6, 6.2, -3, 3, 0, 3)
}

for name, bounds in components.items():

    color = (
        (0.52, 0.58, 0.63)
        if name == "floor"
        else (0.64, 0.76, 0.88)
    )

    # Illustrative material values, not measured
    # THz wall properties.
    material = RadioMaterial(
        name=f"{name}_material",
        relative_permittivity=4.0,
        conductivity=0.01,
        thickness=0.2,
        color=color
    )

    obj = SceneObject(
        fname=make_box(name, bounds),
        name=name,
        radio_material=material
    )

    scene.add(obj)


# Directional transmitter, matching the reflection experiment
scene.tx_array = PlanarArray(
    num_rows=1, num_cols=1,
    pattern="tr38901", polarization="V"
)

scene.rx_array = PlanarArray(
    num_rows=1, num_cols=1,
    pattern="iso", polarization="V"
)

# Position devices inside the room
scene.add(Transmitter(
    name="tx",
    position=[0, 0, 1]
))

scene.add(Receiver(
    name="rx",
    position=[5, 0, 1]
))

# Calculate direct propagation
solver = PathSolver()
paths = solver(scene, max_depth=0)

valid = bool(np.any(paths.valid.numpy()))

print("=== THz Indoor 3D Simulation ===")
print("Frequency: 300 GHz")
print("Room size: 7 x 6 x 3 meters")
print("Direct LoS exists:", valid)

if not valid:
    raise RuntimeError("Expected LoS path was not found")


# ==========================================
# Professional Clear LoS 3D Visualization
# ==========================================

# Calculate effective link loss from Sionna paths
a_real = paths.a[0].numpy()
a_imag = paths.a[1].numpy()

power_gain = absorbed_path_power(paths)

los_loss = -10 * np.log10(power_gain)

print(f"Clear LoS Link Loss: {los_loss:.4f} dB")

# Reuse the equipment meshes created by Experiment 09
tx_file = ASSETS / "tx_equipment.obj"
rx_file = ASSETS / "rx_equipment.obj"

if not tx_file.exists() or not rx_file.exists():
    def create_device_mesh(filename, parts):
        vertices = []
        faces = []
    
        for x0, x1, y0, y1, z0, z1 in parts:
            offset = len(vertices)
    
            vertices.extend([
                (x0, y0, z0),
                (x1, y0, z0),
                (x1, y1, z0),
                (x0, y1, z0),
                (x0, y0, z1),
                (x1, y0, z1),
                (x1, y1, z1),
                (x0, y1, z1)
            ])
    
            box_faces = [
                (1, 4, 3), (1, 3, 2),
                (5, 6, 7), (5, 7, 8),
                (1, 2, 6), (1, 6, 5),
                (4, 8, 7), (4, 7, 3),
                (1, 5, 8), (1, 8, 4),
                (2, 3, 7), (2, 7, 6)
            ]
    
            for face in box_faces:
                faces.append(tuple(offset + v for v in face))
    
        output = ASSETS / filename
    
        with open(output, "w") as file:
            for x, y, z in vertices:
                file.write(f"v {x} {y} {z}\n")
    
            for a, b, c in faces:
                file.write(f"f {a} {b} {c}\n")
    
        return str(output)
    
    tx_parts = [
        (-0.22, 0.16, -0.22, 0.22, 0.03, 0.10),
        (-0.05, 0.05, -0.05, 0.05, 0.10, 0.80),
        (-0.20, 0.04, -0.16, 0.16, 0.75, 0.92),
        (-0.14, -0.06, -0.30, 0.30, 0.96, 1.36)
    ]
    
    # Receiver: base, support, radio unit, antenna panel
    rx_parts = [
        (4.80, 5.20, -0.22, 0.22, 0.03, 0.10),
        (4.95, 5.05, -0.05, 0.05, 0.10, 0.80),
        (4.96, 5.20, -0.16, 0.16, 0.75, 0.92),
        (5.08, 5.16, -0.30, 0.30, 0.96, 1.36)
    ]
    
    
    create_device_mesh("tx_equipment.obj", tx_parts)
    create_device_mesh("rx_equipment.obj", rx_parts)

# Add visual equipment AFTER propagation calculations
tx_model = SceneObject(
    fname=str(tx_file),
    name="tx_equipment_visual",
    radio_material=RadioMaterial(
        name="tx_visual_material",
        relative_permittivity=4.0,
        conductivity=0.01,
        color=(0.85, 0.15, 0.12)
    )
)

rx_model = SceneObject(
    fname=str(rx_file),
    name="rx_equipment_visual",
    radio_material=RadioMaterial(
        name="rx_visual_material",
        relative_permittivity=4.0,
        conductivity=0.01,
        color=(0.10, 0.65, 0.35)
    )
)

scene.add([tx_model, rx_model])

# Same camera settings as reflection experiment
camera = Camera(
    position=[6, -10, 9],
    look_at=[2.5, 0, 1.2]
)

scene.render_to_file(
    camera=camera,
    paths=paths,
    filename=str(RESULTS / "thz_clear_los_3d.png"),
    resolution=(1400, 900),
    fov=45.0,
    num_samples=128,
    show_devices=False,
    show_orientations=False
)

print("Professional Clear LoS 3D scene saved!")
print("Output: results/thz_clear_los_3d.png")

# Publication layout only: all propagation calculations above are unchanged.
# Keep this helper in each existing script so neither needs a new Python file.
def label_png(filename, radio_paths, reflected=False):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle

    tx = scene.transmitters["tx"].position.numpy().reshape(3)
    rx = scene.receivers["rx"].position.numpy().reshape(3)
    routes = []
    if reflected:
        valid = radio_paths.valid.numpy().reshape(-1)
        codes = radio_paths.interactions.numpy().reshape(-1)
        vertices = radio_paths.vertices.numpy().reshape(-1, 3)
        # These experiments use one Tx, one Rx and max_depth=1.
        if len(vertices) != len(valid) or len(codes) != len(valid):
            raise ValueError("Unexpected one-bounce path dimensions")
        routes = [np.vstack((tx, p, rx)) for p in vertices[valid & (codes == 1)]]
    else:
        routes = [np.vstack((tx, rx))]

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 11})
    fig = plt.figure(figsize=(16, 9), facecolor="white")
    ax = fig.add_axes([0.025, 0.15, 0.70, 0.72])
    raster = plt.imread(filename)
    ax.imshow(raster)
    ax.axis("off")
    height, width = raster.shape[:2]
    world_to_camera = np.linalg.inv(camera.world_transform.matrix.numpy()[:, :, 0])

    def project(point):
        local = world_to_camera @ np.r_[point, 1.0]
        scale = width / (2 * np.tan(np.deg2rad(45.0 / 2)))
        return (width / 2 - scale * local[0] / local[2],
                height / 2 - scale * local[1] / local[2])

    def label(text, point, location, color):
        ax.annotate(text, xy=project(point), xytext=location,
                    textcoords="axes fraction", ha="center", va="center",
                    fontsize=11, color=color,
                    bbox=dict(boxstyle="round,pad=0.45", fc="white", ec=color, alpha=0.96),
                    arrowprops=dict(arrowstyle="-", color=color, lw=1.2))

    label("Tx | Transmitter", tx, (0.16, 0.19), "#ad2828")
    label("Rx | Receiver", rx, (0.84, 0.19), "#087849")
    plan = fig.add_axes([0.755, 0.43, 0.22, 0.36])
    plan.set_title("TOP VIEW | distances in meters", fontsize=11, pad=12)
    plan.add_patch(Rectangle((-1, -3), 7, 6, fc="#f1f5f9", ec="#93a4b8"))
    plan.plot([-1, 6], [2.9, 2.9], color="#536b86", lw=4)
    plan.text(2.5, 3.18, "Back wall", ha="center", fontsize=10)
    note = "Direct path; no barrier in this scene."
    if reflected:
        mesh_vertices = np.array([list(map(float, line.split()[1:4]))
                                  for line in (ASSETS / "barrier.obj").read_text().splitlines()
                                  if line.startswith("v ")])
        low, high = mesh_vertices.min(axis=0), mesh_vertices.max(axis=0)
        plan.add_patch(Rectangle(low[:2], *(high-low)[:2], fc="#cf6457", ec="#9f3b30"))
        label(f"Blocking barrier | {high[2]:.1f} m high",
              [(low[0]+high[0])/2, low[1], high[2]], (0.36, 0.94), "#9f3b30")
        plan.text(high[0]+0.15, -0.6, "Barrier", fontsize=9, color="#9f3b30")
        note = "No valid first-order reflection found."
        for index, route in enumerate(routes):
            point = route[1]
            on_back_wall = np.isclose(point[1], 2.9, atol=1e-4)
            name = "Back-wall reflection point" if on_back_wall else "Reflection point"
            label(f"{name}" + (f" {index+1}" if len(routes)>1 else "") +
                  f"\n({point[0]:.2f}, {point[1]:.2f}, {point[2]:.2f}) m",
                  point, (0.74, 0.84-index*0.12), "#8b5700")
            ax.scatter(*project(point), s=45, c="#ffbd43", edgecolors="#704300", zorder=5)
            plan.scatter(*point[:2], s=55, c="#ffbd43", edgecolors="#704300", zorder=5)
        if len(routes) == 1:
            route = routes[0]
            # Only make the height statement when supported by traced vertices.
            if np.allclose(route[:, 2], tx[2], atol=1e-4) and tx[2] < high[2]:
                note = (f"Path height: z = {tx[2]:.2f} m throughout.\n"
                        f"Barrier height: {high[2]:.2f} m.\n"
                        "The top view shows the route around\nthe side of the barrier.")
    for route in routes:
        plan.plot(route[:, 0], route[:, 1], color="#087cba", lw=2.2)
    plan.scatter(*tx[:2], c="#ad2828", s=45, zorder=6)
    plan.scatter(*rx[:2], c="#087849", s=45, zorder=6)
    plan.text(tx[0]-0.35, tx[1]-0.5, "Tx", color="#ad2828", weight="bold")
    plan.text(rx[0], rx[1]-0.5, "Rx", color="#087849", weight="bold")
    plan.set(xlim=(-1.4, 6.4), ylim=(-3.3, 3.6), xlabel="x (m)", ylabel="y (m)")
    plan.set_aspect("equal")
    plan.spines[["top", "right"]].set_visible(False)
    plan.grid(alpha=0.15)
    if routes:
        label("Reflected THz path" if reflected else "Direct LoS path",
              (routes[0][0]+routes[0][1])/2, (0.15, 0.65), "#087cba")
    fig.text(0.755, 0.33, "GEOMETRY CHECK", fontsize=11, weight="bold", color="#172d46")
    fig.text(0.755, 0.30, note, fontsize=10, va="top", linespacing=1.6, color="#37465a")
    fig.text(0.04, 0.94, "THz indoor propagation", fontsize=24, weight="bold", color="#172d46")
    subtitle = (f"Single-bounce reflection | Tx azimuth {BEST_ANGLE:.0f} deg | Direct LoS blocked"
                if reflected else "Clear line of sight | Direct Tx-to-Rx path")
    fig.text(0.04, 0.895, subtitle + " | 300 GHz", fontsize=13, color="#53647a")
    fig.text(0.04, 0.075, "3D: Sionna RT render   |   Top view: traced path coordinates   |   Thin gray/color leaders indicate labels only",
             fontsize=10, color="#53647a")
    fig.text(0.04, 0.04, "Illustrative wall materials; visual equipment added after propagation calculations.", fontsize=9, color="#64748b")
    fig.savefig(filename, dpi=160, facecolor="white")
    plt.close(fig)


label_png(RESULTS / "thz_clear_los_3d.png", paths)



