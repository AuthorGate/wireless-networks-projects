import mitsuba as mi

mi.set_variant("llvm_ad_mono_polarized")

from sionna.rt import load_scene

scene = load_scene()
scene.frequency = 2.4e9

print("Backend:", mi.variant())
print("Frequency: 2.4 GHz")
print("Sionna RT is ready")