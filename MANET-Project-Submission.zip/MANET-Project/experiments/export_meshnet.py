import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/urban_clusters.json") as f:
    data = json.load(f)

for snapshot in data["snapshots"]:

    graph = {
        "nodes": [
            {"id": node["id"]}
            for node in snapshot["nodes"]
        ],

        "links": [
            {
                "source": link["source"],
                "target": link["target"]
            }
            for link in snapshot["links"]
        ]
    }

    filename = f"urban_t{snapshot['time']}.json"

    with open(ROOT / "results" / filename, "w") as f:
        json.dump(graph, f, indent=4)

    print(
        filename,
        "| Nodes:", len(graph["nodes"]),
        "| Links:", len(graph["links"])
    )

print("\nMesh Network Lab export completed")