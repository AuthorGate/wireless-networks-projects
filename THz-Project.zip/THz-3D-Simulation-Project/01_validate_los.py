from pathlib import Path

import mitsuba as mi

# Use CPU because OptiX is unavailable in our WSL setup
mi.set_variant("llvm_ad_mono_polarized")

import numpy as np

# Use the original MATLAB absorption dataset directly (no copied data files).
from scipy.io import loadmat
_matlab_file = Path(__file__).resolve().parent / "data" / "molecular_absorption.mat"
_matlab_data = loadmat(_matlab_file)
_f = np.asarray(_matlab_data["f"]).reshape(-1)
_k = np.asarray(_matlab_data["k"]).reshape(-1)
if not (_f.min() <= 300e9 <= _f.max()):
    raise ValueError("300 GHz is outside the MATLAB dataset")
_k300 = float(np.interp(300e9, _f, _k))

def absorbed_path_power(radio_paths):
    # MATLAB convention: power attenuation exp(-k * distance).
    coefficients, delays = radio_paths.cir(out_type="numpy", normalize_delays=False)
    valid = radio_paths.valid.numpy().reshape(-1).astype(bool)
    powers = np.abs(coefficients.reshape(-1)[valid]) ** 2
    lengths = delays.reshape(-1)[valid] * 299792458.0
    return float(np.sum(powers * np.exp(-_k300 * lengths)))


from sionna.rt import (
    load_scene,
    PlanarArray,
    Transmitter,
    Receiver,
    PathSolver
)

# Simulation parameters
FREQUENCY = 300e9
DISTANCE = 5.0
SPEED_OF_LIGHT = 299792458.0

# Empty propagation environment
scene = load_scene()
scene.frequency = FREQUENCY

# Isotropic antennas
scene.tx_array = PlanarArray(
    num_rows=1,
    num_cols=1,
    pattern="iso",
    polarization="V"
)

scene.rx_array = PlanarArray(
    num_rows=1,
    num_cols=1,
    pattern="iso",
    polarization="V"
)

# Transmitter and receiver
scene.add(Transmitter(
    name="tx",
    position=[0, 0, 1]
))

scene.add(Receiver(
    name="rx",
    position=[DISTANCE, 0, 1]
))

# Calculate direct LoS propagation
solver = PathSolver()
paths = solver(scene, max_depth=0)

if not np.any(paths.valid.numpy()):
    raise RuntimeError("No valid LoS path found")

# Extract channel coefficient
a, tau = paths.cir(out_type="numpy")
h = a[0, 0, 0, 0, 0, 0]

# Sionna path loss
sionna_loss = -10 * np.log10(np.abs(h)**2)

# Theoretical free-space path loss
fspl = 20 * np.log10(
    4 * np.pi * FREQUENCY * DISTANCE / SPEED_OF_LIGHT
)

difference = abs(sionna_loss - fspl)

print("\n=== THz LoS Validation ===")
print(f"Frequency: {FREQUENCY / 1e9:.0f} GHz")
print(f"Distance: {DISTANCE:.1f} m")
print(f"Sionna Path Loss: {sionna_loss:.4f} dB")
print(f"Theoretical FSPL: {fspl:.4f} dB")
print(f"Absolute Difference: {difference:.6f} dB")

assert difference < 0.1, "Path-loss validation failed"

print("VALIDATION PASSED")

print(f"Loss including MATLAB absorption: {-10*np.log10(absorbed_path_power(paths)):.4f} dB")
