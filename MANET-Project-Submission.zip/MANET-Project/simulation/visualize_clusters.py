import json
import matplotlib.pyplot as plt
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/mobile_network.json") as f:
    network = json.load(f)

with open(ROOT / "results/clusters.json") as f:
    data = json.load(f)

positions = {
    node["id"]: node
    for node in network["nodes"]
}

isolated = set(data["isolated_nodes"])

fig = plt.figure(figsize=(16, 8))
colors = plt.get_cmap("tab10")


def draw_clusters(ax, clusters, title):

    membership = {}

    for i, (head, members) in enumerate(clusters.items()):
        for node in members:
            membership[node] = i

    for link in network["links"]:
        a = positions[link["source"]]
        b = positions[link["target"]]

        same = (
            membership[link["source"]] ==
            membership[link["target"]]
        )

        color = (
            colors(membership[link["source"]] % 10)
            if same else "gray"
        )

        ax.plot(
            [a["x"], b["x"]],
            [a["y"], b["y"]],
            [a["z"], b["z"]],
            color=color,
            linestyle="-" if same else "--",
            alpha=0.8
        )

    for i, (head, members) in enumerate(clusters.items()):

        for node in members:
            p = positions[node]

            if node in isolated:
                color = "red"
                marker = "x"
                size = 180
            elif node == head:
                color = colors(i % 10)
                marker = "*"
                size = 350
            else:
                color = colors(i % 10)
                marker = "o"
                size = 100

            ax.scatter(
                p["x"], p["y"], p["z"],
                color=color,
                marker=marker,
                s=size
            )

            ax.text(
                p["x"], p["y"], p["z"] + 0.4,
                node
            )

    ax.set_xlim(-3, 23)
    ax.set_ylim(-3, 23)
    ax.set_zlim(0, 5)

    ax.set_xlabel("X (m)")
    ax.set_ylabel("Y (m)")
    ax.set_zlabel("Z (m)")

    ax.view_init(elev=25, azim=-60)

    ax.set_title(
        f"{title}\nClusters: {len(clusters)}"
    )


ax1 = fig.add_subplot(121, projection="3d")
ax2 = fig.add_subplot(122, projection="3d")

draw_clusters(
    ax1,
    data["traditional_clusters"],
    "Traditional Clustering"
)

draw_clusters(
    ax2,
    data["adaptive_clusters"],
    "Proposed SAAC Algorithm"
)

fig.suptitle(
    "MANET Clustering Comparison - Sionna RT",
    fontsize=16
)

plt.tight_layout()

plt.savefig(
    ROOT / "figures/clustering_comparison.png",
    dpi=300,
    bbox_inches="tight"
)

plt.close()

print("Clustering visualization completed")
print("Saved: figures/clustering_comparison.png")