import json
import time
import subprocess
import ipaddress
import argparse

parser = argparse.ArgumentParser()

parser.add_argument(
    "--nodes",
    type=int,
    choices=[9, 25, 50, 100, 200],
    default=9
)

args = parser.parse_args()

nodes = [
    format(i, "04x")
    for i in range(args.nodes)
]

prefix = int(
    ipaddress.IPv6Address("fdef:17a0:ffb1:300::")
)


def run(node, *args):

    return subprocess.check_output(
        ["ip", "-n", "ns-" + node, *args],
        text=True
    )


for node in nodes:

    local = None

    for attempt in range(50):

        output = run(
            node,
            "-j", "-6", "addr", "show",
            "dev", "uplink"
        )

        for interface in json.loads(output):

            for address in interface["addr_info"]:

                if address["scope"] == "link":
                    local = address["local"]

        if local:
            break

        time.sleep(0.1)

    if not local:
        raise ValueError(
            "Missing link-local address: " + node
        )

    interface_id = (
        int(ipaddress.IPv6Address(local))
        & ((1 << 64) - 1)
    )

    address = str(
        ipaddress.IPv6Address(prefix | interface_id)
    )

    run(
        node,
        "-6", "addr", "replace",
        address + "/64",
        "dev", "uplink",
        "nodad"
    )

    subprocess.run(
        [
            "ip", "netns", "exec", "ns-" + node,
            "sysctl", "-w",
            "net.ipv6.conf.all.forwarding=1"
        ],
        check=True,
        capture_output=True
    )

    print(node, "| IPv6:", address)


print("--------------------------")
print("Total nodes:", len(nodes))
print("All nodes prepared successfully")