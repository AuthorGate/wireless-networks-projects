# THz Channel Modeling & Ray Tracing

Analytical and simulation-based study of how a 6G terahertz (THz) link degrades with frequency, distance, and material composition — combining MATLAB propagation modeling with full 3D ray-tracing (CADFEKO, WALLMAN, PROMAN) for indoor office and outdoor campus scenarios.

## Overview

Wireless links above 100 GHz behave very differently from the sub-6GHz and mmWave bands most networks run on today. Two effects dominate: **spreading loss** (the signal weakens over distance, same as any wireless link) and **molecular absorption loss** (water vapor and other atmospheric molecules resonate at specific THz frequencies and absorb energy directly out of the signal). This project quantifies both effects, then validates them against real material behavior and full 3D ray-tracing simulations of an indoor office and an outdoor university campus.

The goal throughout: understand *why* THz is attractive for 6G (huge bandwidth, tiny antennas) and *why* it's hard (severe path loss, poor wall penetration, near-total reliance on line-of-sight).

## Part 1 — Analytical Channel Modeling (MATLAB)

Three scripts build up the full picture of THz propagation loss as a function of frequency (0.1–10 THz) at three distances (1 m, 10 m, 100 m):

| Script | Computes | Key finding |
|---|---|---|
| `matlab/molecular_absorption_loss.m` | Molecular absorption loss from HITRAN-derived absorption coefficient data | Loss spikes sharply at specific resonance frequencies — these gaps between spikes are the **absorption-free windows** that make THz communication viable at all |
| `matlab/spreading_loss.m` | Free-space spreading loss (isotropic antenna) | Loss increases monotonically with both frequency and distance — the fundamental $1/d^2$ and $1/\lambda^2$ scaling |
| `matlab/total_path_loss.m` | Combined spreading + absorption loss | At 100 m, path loss exceeds 1000 dB at several resonance frequencies — a clear illustration of why THz links need to hunt for absorption-free windows and stay short-range |

**Molecular Absorption Loss**
![Molecular Absorption Loss](figures/molecular_absorption_loss.png)

**Spreading Loss**
![Spreading Loss](figures/spreading_loss.png)

**Total Path Loss**
![Total Path Loss](figures/total_path_loss.png)

### Running it
```matlab
cd matlab
molecular_absorption_loss   % or spreading_loss, total_path_loss
```
Each script loads `../data/molecular_absorption.mat`, which contains the frequency vector `f` and absorption coefficient `k` used throughout.

### Selected analysis

**Antenna sizing at THz frequencies.** A half-wave dipole at 1 THz works out to a physical length of just 0.15 mm; at 2 THz, 0.075 mm. This is the flip side of the propagation-loss coin — the same short wavelengths that cause severe path loss also make THz antennas small enough for on-chip integration, which is a big part of the appeal for dense IoT and short-range links.

**Reducing spreading loss.** Three practical levers: switch from an isotropic to a directional antenna (e.g. a parabolic dish) to concentrate energy toward the receiver; operate lower in the THz band where spreading loss is smaller; or shorten the link distance directly, e.g. via relay nodes.

**300 GHz in context.** Spreading loss at 300 GHz (1 m) computes to 81.99 dB — well above 2.4 GHz (40.05 dB) and 60 GHz (68.00 dB), but still well below 200 THz / optical (138.46 dB). This places sub-THz bands like 300 GHz as a genuine middle ground between today's RF bands and free-space optical links.

## Part 2 — Material Interaction (Experimental)

Using the `compute_power` testbed script (course-provided), transmission and reflection power were measured for five common materials to characterize how THz signals interact with real building materials:

| Material | Transmission | Reflection | Behavior |
|---|---|---|---|
| Air | 21.07 dBm | — | Mostly transparent, negligible reflection |
| Glass | 15.86 dBm | 10.12 dBm | Mostly transparent *and* mostly reflective |
| Plastic | 11.65 dBm | −6.58 dBm | Mostly transparent, minor reflection |
| Wood | 2.32 dBm | 7.85 dBm | Highly absorbing, some reflection |
| Metal | — | 20.62 dBm | Fully reflective — blocks transmission entirely |

This table becomes the basis for interpreting the ray-tracing results below: metal is a hard wall for THz, wood absorbs rather than reflects, and glass does a bit of both.

## Part 3 — Ray Tracing (CADFEKO / WALLMAN / PROMAN)

The analytical model tells you *how much* loss to expect; ray tracing shows *where* the signal actually goes once real geometry and materials are involved.

**Antenna design (CADFEKO/POSTFEKO).** Built a WR7-based horn antenna in CADFEKO for 130 GHz, ran the FEKO solver, and validated far-field gain in POSTFEKO — 18.40 dBi total gain with a clean, symmetric main lobe.

**Indoor scenario (WALLMAN/PROMAN).** Modeled a two-corridor, eight-room office floor plan — brick walls, glass windows, wooden doors, metal drawers, wooden tables, plastic chairs — and simulated propagation at both 2.4 GHz and 130 GHz from the same transmitter location:

| | 2.4 GHz | 130 GHz |
|---|---|---|
| Path loss range | −50 to −95 dB | −80 to −320 dB |
| Wall penetration | Good — usable signal through brick | Very poor — walls are a near-total block |
| Coverage | Reaches all 8 rooms | Confined to line-of-sight corridor + 2 adjacent rooms |
| Metal drawers | Fully reflective — signal blocked | Fully reflective — signal blocked |

Repeating the simulation with brick wall thickness tripled (10 cm → 30 cm) showed almost no change at 2.4 GHz, but reinforced how completely 130 GHz depends on direct line-of-sight rather than penetration.

**Outdoor scenario (OpenStreetMap → WALLMAN/PROMAN).** Exported a real campus building layout from OpenStreetMap and repeated the comparison outdoors. Same pattern holds at larger scale: 2.4 GHz diffracts around buildings and maintains partial coverage across the site; 130 GHz is confined almost entirely to its direct beam path, with buildings acting as hard obstacles rather than diffraction surfaces.

### Key takeaways
- **Line of sight is everything at THz.** Below 6 GHz, signals diffract around obstacles well enough to fill non-line-of-sight space. At 130 GHz, that stops being true — coverage is essentially wherever the beam points, plus whatever survives a reflection.
- **Material matters more as frequency increases.** The same wall that mildly attenuates a 2.4 GHz signal can be a near-total block at 130 GHz.
- **Antenna height and placement compound this.** Elevating a THz antenna to clear furniture/desks measurably helps, since even small obstacles cause disproportionate attenuation at these frequencies.

## Repository Structure
```
matlab/
  molecular_absorption_loss.m   # Part 1: absorption loss vs frequency
  spreading_loss.m              # Part 1: spreading loss vs frequency
  total_path_loss.m             # Part 1: combined path loss vs frequency
data/
  molecular_absorption.mat      # HITRAN-derived absorption coefficient + frequency vector (course-provided)
figures/
  *.png                         # Output plots referenced above
```

## Tools Used
MATLAB · CADFEKO · POSTFEKO · WALLMAN · PROMAN (Altair WinProp) · OpenStreetMap

## Course Context
Coursework for *EECE 5698: Terahertz Communications for 6G*, Northeastern University (Prof. Josep Miquel Jornet, Ultrabroadband Nanonetworking Laboratory). The molecular absorption dataset and the `compute_power` material-testing script were provided as part of the course; the analytical MATLAB scripts, ray-tracing model builds, and all analysis/discussion above are my own work.
