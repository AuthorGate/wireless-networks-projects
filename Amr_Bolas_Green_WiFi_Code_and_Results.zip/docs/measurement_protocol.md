# Optional future field protocol for a multi-AP site in Nablus

This protocol is for future validation if an authorized site and equipment become available. It is not required to reproduce the current software simulation. The report's sample data are synthetic and are not measurements from a Nablus institution. Obtain written permission from the network owner before scanning, capturing, or altering any network.

## 1. Select and map the test site

Choose a building with at least two OpenWrt-managed APs broadcasting the same SSID (an educational lab, training centre, office, or shop). Give each AP a neutral ID (`AP-1`, `AP-2`, ...). Record its physical location, radio interface, band, channel, and wired backhaul status. Draw a simple floor plan and mark user areas and protected-device areas.

Do not assume that a site has overlapping coverage: verify it with a walk test or a survey before running any sleep experiment.

## 2. Establish the safety policy

Create an inventory of critical devices with the network owner: security cameras, alarms, access-control devices, medical/monitoring equipment, or essential voice endpoints. Store their MAC addresses only in a local protected configuration file. Do not put MAC addresses, names, or IP addresses in the report; publish aggregate counts only.

Set a conservative `minimum_active_aps`. For a first test, do not allow the scheduler to sleep the final AP serving a floor or a protected area. Define a rollback contact and a time window when service interruption is acceptable.

## 3. Prepare the selected `wifischedule` package and collect telemetry

The selected Green Wireless repository component is `openwrt/packages/net/wifischedule` at commit `1ac54403af4a7b0f2743e92bbe7f2c5fe17a61df`. Install it on each AP that is intended to be managed, but do not enable a radio-off schedule during the initial observation phase. Inspect the init script at `/etc/init.d/wifi_schedule` and the command logic in `/usr/bin/wifi_schedule.sh`. The service start path checks the configured time window and can enable or disable the AP radio. The companion Python controller in this project is advisory-only; keep the original package disabled or leave its schedule entries disabled until a controlled test is approved.

For multi-AP client and signal telemetry, optionally install and configure `usteer` on the OpenWrt APs. Follow the OpenWrt documentation for compatible `wpad` and 802.11k/802.11v configuration. Start by collecting, not changing, network state:

```sh
ubus call usteer local_info
ubus call usteer remote_info
ubus call usteer get_clients
```

`usteer` exposes information about local/remote nodes and client connection state/signal. Save timestamped JSON snapshots using `scripts/collect_ubus_snapshot.sh`. Use the client signal information to verify that each connected station has an adequate alternate BSS; the conservative default used in the example is -67 dBm, but the correct threshold depends on band, device class, data-rate requirements, and the building. If `usteer` is unavailable, use a documented hostapd/OpenWrt source for associated-client and RSSI data.

## 4. Measure traffic and channel occupancy

Collect at least 24 hours, preferably several weekdays and a weekend, at a fixed interval (15 minutes is used in the demonstration). For each AP/radio:

- Traffic rate: read the interface `rx_bytes` and `tx_bytes` counters at the beginning and end of the interval. Calculate `Mbps = 8 * (delta_rx_bytes + delta_tx_bytes) / (elapsed_seconds * 1,000,000)`. Discard intervals where counters reset or the interface restarts.
- Channel occupancy: use `iw dev <interface> survey dump` twice and calculate `100 * delta(channel busy time) / delta(channel active time)`. The busy and active counters are cumulative; always use deltas from the same channel and ensure the denominators are positive.
- Associated clients and signal: use `ubus call usteer get_clients` and count connected stations per BSS. For every station on a candidate AP, find the strongest measured alternate BSS and record the weakest of those best-alternate RSSI values in `best_backup_rssi_dbm`.
- Protected clients: count the protected inventory devices currently connected to each AP.

Make sure the traffic rate and channel occupancy are collected over the same interval. Do not interpret the `usteer` load field as a percentage unless you have verified its units for your installed OpenWrt/hostapd version.

## 5. Estimate post-migration capacity

For each candidate AP, choose an alternate AP that can serve all of its clients. `backup_base_load_pct` is the measured utilization of that target AP before migration. `backup_increment_pct` is the additional airtime/load expected after migration. Prefer estimating this from a controlled low-risk migration trial; a simplistic proportional estimate from client count is only an initial approximation and must be labelled as such.

If clients require multiple backup APs, aggregate them conservatively or split the candidate AP into multiple migration groups before creating the CSV. Do not count a candidate as covered merely because one nearby AP has a good signal for some clients.

## 6. Measure AP power

Use a calibrated plug-in power meter or PoE power analyzer. Measure each AP in at least these two states:

1. Normal operation with Wi-Fi radio active under representative idle/low traffic.
2. The exact lower-power state you plan to test (for example, radio disabled while the wired router/control plane remains on).

Take multiple samples of equal duration, record the device model, firmware, radio configuration, measurement device and uncertainty, then use the mean power in watts. Repeat for each AP model; do not assume all models draw the same power. The current code accepts one shared pair of power values, so run separate evaluations for homogeneous AP model groups unless you extend it with per-AP power configuration. The bundled simulation uses literature reference pairs of 5.64/5.42 W for a Ruckus H550 and 5.67/3.93 W for an Aruba AP-505. Do not present those published reference values as measurements of local equipment.

## 7. Populate the CSV and run the evaluator

Map each measured interval to the schema in `README.md`. Verify that every timestamp contains every AP row. Then run:

```bash
PYTHONPATH=src python -m greenwifi.cli --input data/site_trace.csv --config config/config.json --out results/site
python scripts/plot_results.py
```

For a fair comparison, use the same measured AP inventory and the same duration for the always-on baseline and the proposed policy. Report both energy and QoS metrics.

## 8. Validate service quality before any operational sleep action

In a controlled test, compare the baseline and proposed policy using:

- RSSI distribution and coverage holes from the same survey points.
- Throughput (downlink and uplink) at fixed test locations.
- RTT/latency and packet loss to the same test endpoint.
- Roaming success rate and time to reconnect.
- Count of protected devices that remained connected.
- AP power measured by the same instrument.

A successful energy result is not sufficient if coverage, latency, packet loss, or availability gets materially worse. Define acceptance limits with the site owner before the experiment and report every failed window.

## 9. Reproducibility record

Archive the raw anonymized snapshots, CSV, configuration, software commit/version, OpenWrt version, AP model, measurement interval, time zone, calibration details, and all commands. Keep personal/device identifiers out of public supplementary material.
