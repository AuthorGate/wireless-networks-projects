import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import sionna.rt as rt

from pathlib import Path
from sionna.rt import load_scene, Camera

ROOT = Path(__file__).resolve().parents[1]

scene = load_scene(
    rt.scene.simple_street_canyon,
    merge_shapes=False
)

scene.frequency = 2.4e9

camera = Camera(
    position=[50, 0, 130],
    look_at=[10, 0, 0]
)

scene.render_to_file(
    camera=camera,
    filename=str(ROOT / "figures/urban_3d.png"),
    resolution=(1280, 900),
    num_samples=64
)

print("3D Urban Environment Created")
print("Frequency: 2.4 GHz")
print("Objects:", list(scene.objects.keys()))
print("Saved: figures/urban_3d.png")