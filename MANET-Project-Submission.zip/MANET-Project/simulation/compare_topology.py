import json
import networkx as nx
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/network.json") as f:
    static = json.load(f)

with open(ROOT / "results/mobile_network.json") as f:
    mobile = json.load(f)


def get_links(network):
    return {
        tuple(sorted((link["source"], link["target"])))
        for link in network["links"]
    }


old_links = get_links(static)
new_links = get_links(mobile)

lost = old_links - new_links
added = new_links - old_links
stable = old_links & new_links

G = nx.Graph()

G.add_nodes_from(node["id"] for node in mobile["nodes"])
G.add_edges_from(new_links)

isolated = list(nx.isolates(G))
components = list(nx.connected_components(G))

results = {
    "total_nodes": G.number_of_nodes(),
    "static_links": len(old_links),
    "mobile_links": len(new_links),
    "lost_links": len(lost),
    "added_links": len(added),
    "stable_links": len(stable),
    "isolated_nodes": isolated,
    "connected_components": len(components),
    "largest_component": max(map(len, components)),
    "network_connected": nx.is_connected(G)
}

for key, value in results.items():
    print(key, ":", value)

with open(ROOT / "results/topology_comparison.json", "w") as f:
    json.dump(results, f, indent=4)

print("Analysis completed")