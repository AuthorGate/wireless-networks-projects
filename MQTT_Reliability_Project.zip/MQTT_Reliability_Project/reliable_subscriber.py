
import json
import sqlite3
import paho.mqtt.client as mqtt

BROKER = "localhost"
PORT = 1883

DATA_TOPIC = "iot/reliable/temperature"
ACK_TOPIC = "iot/reliable/ack"

# Store received message IDs to detect duplicates
db = sqlite3.connect(
    "received_messages.db",
    check_same_thread=False
)

db.execute("""
CREATE TABLE IF NOT EXISTS received (
    message_id INTEGER PRIMARY KEY,
    temperature REAL NOT NULL
)
""")
db.commit()


def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("Reliable Subscriber connected!")
        client.subscribe(DATA_TOPIC, qos=1)
        print("Waiting for reliable messages...")
    else:
        print("Connection failed:", reason_code)


def on_message(client, userdata, message):
    try:
        data = json.loads(message.payload.decode("utf-8"))

        message_id = int(data["id"])
        temperature = float(data["temperature"])

        # Check whether message was already received
        existing = db.execute(
            "SELECT 1 FROM received WHERE message_id = ?",
            (message_id,)
        ).fetchone()

        if existing:
            print(f"Duplicate message {message_id} ignored.")
        else:
            db.execute(
                "INSERT INTO received VALUES (?, ?)",
                (message_id, temperature)
            )
            db.commit()

            print(
                f"Received message {message_id}: "
                f"{temperature} °C"
            )

        # Send ACK for both new and duplicate messages
        ack = {"id": message_id}

        client.publish(
            ACK_TOPIC,
            json.dumps(ack),
            qos=1
        )

        print(f"ACK sent for message {message_id}")

    except (ValueError, KeyError, TypeError) as e:
        print("Invalid message:", e)


client = mqtt.Client(
    callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
    client_id="reliable_temperature_receiver"
)

client.on_connect = on_connect
client.on_message = on_message

try:
    client.connect(BROKER, PORT, 60)
    client.loop_forever()

except KeyboardInterrupt:
    print("\nReliable Subscriber stopped.")

except OSError as e:
    print("Connection error:", e)

finally:
    db.close()
    client.disconnect()

