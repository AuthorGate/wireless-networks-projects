
import csv
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE_DIR = Path(__file__).resolve().parent
RESULTS = BASE_DIR / "results"

with open(RESULTS / "link_budget_comparison.csv", newline="") as f:
    data = list(csv.DictReader(f))

scenarios = [row["Scenario"] for row in data]
snr = [float(row["SNR (dB)"]) for row in data]

# Support either CSV header used in our earlier versions
capacity_key = next(
    key for key in data[0]
    if "Capacity" in key
)
capacity = [
    float(row[capacity_key]) * 1000
    for row in data
]

# Presentation only: retain the CSV values and capacity conversion above.
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 12})
labels = [name.replace("Blocked LoS with Reflection", "Blocked LoS\nwith reflection")
          for name in scenarios]
for values, ylabel, title, output, explanation in [
    (snr, "Signal-to-noise ratio (dB)", "Received signal quality", "snr_comparison.png",
     "Higher SNR is better. Negative dB means signal power is below noise power."),
    (capacity, "Theoretical Shannon capacity (Mbps)", "Theoretical channel capacity", "capacity_comparison.png",
     "Higher is better. Shannon capacity is a theoretical bound, not measured throughput.")
]:
    fig, ax = plt.subplots(figsize=(12, 7))
    fig.subplots_adjust(left=0.12, right=0.96, top=0.77, bottom=0.28)
    fig.text(0.08, 0.93, title, fontsize=24, weight="bold", color="#172d46")
    fig.text(0.08, 0.865, "300 GHz | Isotropic baseline scenarios | Tx power 10 dBm | Bandwidth 1 GHz | Noise figure 7 dB",
             fontsize=11, color="#53647a")
    bars = ax.bar(labels, values, color=["#087cba", "#cf6457"], width=0.48)
    ax.bar_label(bars, labels=[f"{value:.2f}" for value in values], padding=8, fontsize=13, weight="bold")
    ax.axhline(0, color="#53647a", linewidth=0.8)
    ax.set_ylabel(ylabel)
    ax.margins(y=0.22)
    ax.spines[["top", "right"]].set_visible(False)
    ax.set_axisbelow(True)
    ax.grid(axis="y", alpha=0.2)
    fig.text(0.08, 0.15, explanation, fontsize=11, color="#37465a")
    losses = "  |  ".join(f"{row['Scenario']}: {float(row['Path Loss (dB)']):.4f} dB" for row in data)
    fig.text(0.08, 0.095, "Input link loss: " + losses, fontsize=10, color="#53647a")
    fig.text(0.08, 0.05, "MATLAB absorption included | Isotropic baseline; separate from directional best-beam results.",
             fontsize=10, color="#53647a")
    fig.savefig(RESULTS / output, dpi=200, facecolor="white")
    plt.close(fig)
    print(f"Labeled PNG saved: {output}")

