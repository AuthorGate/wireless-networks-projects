import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import sionna.rt as rt
from sionna.rt import load_scene

scene = load_scene(
    rt.scene.simple_street_canyon,
    merge_shapes=False
)

print("Urban Environment Layout")
print("------------------------")

for name, obj in scene.objects.items():

    box = obj.mi_mesh.bbox()

    print("\nObject:", name)

    print(
        "X:",
        float(box.min.x),
        "to",
        float(box.max.x)
    )

    print(
        "Y:",
        float(box.min.y),
        "to",
        float(box.max.y)
    )

    print(
        "Z:",
        float(box.min.z),
        "to",
        float(box.max.z)
    )

print("\nLayout analysis completed")