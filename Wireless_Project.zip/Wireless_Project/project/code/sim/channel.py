"""channel.py - scene-aware radio channel for the mesh simulator (added module).

Purpose
-------
The original simulator declares a link whenever two nodes are within ``radio_range_m``.
That is an ideal, obstacle-free radio. This module lets the simulator account for

  * obstacles       : tree trunks that block or strongly attenuate a link,
  * vegetation      : foliage (crown) attenuation proportional to the path length inside canopy
                      (Weissberger / ITU-R P.833 type model),
  * wind            : wind-induced foliage motion = slow, correlated fading on vegetated links,
  * a physical link : SNR -> packet-reception ratio (IEEE 802.15.4 O-QPSK), used both to decide
                      which links exist and to drop packets tick by tick.

Everything is OFF by default (``channel_model="distance"``): the simulator is then bit-identical
to the original. Modes: "distance" (original), "scene" (this module's analytic scene model),
"matrix" (a per-pair gain matrix, e.g. from Sionna RT, read from ``link_gain_csv``).

Open-field calibration: the link budget is anchored so that, without any tree, a link at
``radio_range_m`` has ``link_margin_db`` dB of margin over PRR = ``prr_link_min``. With
link_margin_db = 0 the open-field neighbor graph equals the original distance graph; the default
1 dB margin extends the open-field range slightly (about 19.6 m instead of 18 m).
"""
from __future__ import annotations

import math
from math import comb

import numpy as np


# ------------------------------------------------------------------ physical link layer
def oqpsk_ber(snr_db) -> np.ndarray:
    """IEEE 802.15.4 2.4 GHz O-QPSK bit error rate vs SNR (standard's annex formula)."""
    snr = 10.0 ** (np.asarray(snr_db, dtype=float) / 10.0)
    s = np.zeros_like(snr)
    for k in range(2, 17):
        s = s + ((-1) ** k) * comb(16, k) * np.exp(20.0 * snr * (1.0 / k - 1.0))
    return np.clip((8.0 / 15.0) * (1.0 / 16.0) * s, 0.0, 0.5)


def prr(snr_db, packet_bytes: int = 30) -> np.ndarray:
    return (1.0 - oqpsk_ber(snr_db)) ** (8 * packet_bytes)


def snr_for_prr(target: float, packet_bytes: int = 30) -> float:
    lo, hi = -10.0, 30.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if float(prr(mid, packet_bytes)) < target:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# ------------------------------------------------------------------ geometry
def _chord_lengths(P, Q, C, r):
    """Length of segment P->Q inside each circle (centres C, radius r). P,Q: (2,), C: (m,2)."""
    d = Q - P
    L = float(np.hypot(*d))
    if L == 0.0 or len(C) == 0:
        return np.zeros(len(C))
    u = d / L
    w = C - P
    t_c = w @ u                                   # projection of centre on the line
    h2 = np.einsum("ij,ij->i", w, w) - t_c ** 2   # squared distance centre-line
    disc = r * r - h2
    out = np.zeros(len(C))
    ok = disc > 0
    half = np.sqrt(np.where(ok, disc, 0.0))
    a = np.clip(t_c - half, 0.0, L)
    b = np.clip(t_c + half, 0.0, L)
    out[ok] = (b - a)[ok]
    return out


def _seg_point_dist(P, Q, C):
    d = Q - P
    L2 = float(d @ d)
    if L2 == 0.0:
        return np.hypot(*(C - P).T)
    t = np.clip(((C - P) @ d) / L2, 0.0, 1.0)
    proj = P + t[:, None] * d
    return np.hypot(*(C - proj).T)


def weissberger_db(depth_m, f_ghz: float = 2.4):
    """Weissberger (1982) in-leaf foliage excess loss, as adopted in ITU-R P.833."""
    d = np.asarray(depth_m, dtype=float)
    short = 0.45 * f_ghz ** 0.284 * d
    long_ = 1.33 * f_ghz ** 0.284 * np.maximum(d, 1e-9) ** 0.588
    return np.where(d <= 14.0, short, long_)


# ------------------------------------------------------------------ channel
class Channel:
    def __init__(self, cfg, nodes):
        self.cfg = cfg
        self.nodes = nodes
        self.n = len(nodes)
        self.ids = [nd.id for nd in nodes]
        pos = np.array([nd.pos for nd in nodes], dtype=float)
        self.pos = pos
        R = cfg.radio_range_m
        self.snr_ref = snr_for_prr(cfg.prr_link_min, cfg.packet_bytes)
        self.snr_at_R = self.snr_ref + cfg.link_margin_db
        self.pairs: list[tuple[int, int]] = []          # node *ids* (u<v)
        self.mean_snr: dict[tuple[int, int], float] = {}
        self.veg_depth: dict[tuple[int, int], float] = {}
        self.trunk_hits: dict[tuple[int, int], int] = {}
        self.trees = None
        self._fade: dict[tuple[int, int], float] = {}
        self._sigma: dict[tuple[int, int], float] = {}
        self._rng = np.random.default_rng(cfg.seed + 314159)
        mode = cfg.channel_model
        if mode == "scene":
            self._build_scene()
            self._link_budget_scene()
        elif mode == "matrix":
            self._link_budget_matrix()
        else:
            raise ValueError(f"unknown channel_model {mode!r}")

    # --- scene ---
    def _build_scene(self):
        cfg = self.cfg
        pos = self.pos
        lo, hi = pos.min(0) - 3.0, pos.max(0) + 3.0
        area_ha = float(np.prod(hi - lo)) / 1e4
        seed = cfg.scene_seed if cfg.scene_seed is not None else cfg.seed + 1000003
        rng = np.random.default_rng(seed)
        m = rng.poisson(cfg.tree_density_ha * area_ha)
        C = lo + rng.random((m, 2)) * (hi - lo)
        if m:                                           # keep a clear 0.5 m around each sensor
            far = np.all(np.hypot(*(C[:, None, :] - pos[None, :, :]).transpose(2, 0, 1)) > 0.5, axis=1)
            C = C[far]
        self.trees = C

    def _link_budget_scene(self):
        cfg = self.cfg
        R, nexp = cfg.radio_range_m, cfg.pl_exponent
        C = self.trees
        for i in range(self.n):
            for j in range(i + 1, self.n):
                P, Q = self.pos[i], self.pos[j]
                d = float(np.hypot(*(Q - P)))
                if d <= 0:
                    continue
                depth = float(_chord_lengths(P, Q, C, cfg.crown_radius_m).sum()) if len(C) else 0.0
                depth = min(depth, d)
                hits = int((_seg_point_dist(P, Q, C) < cfg.trunk_radius_m).sum()) if len(C) else 0
                loss = float(weissberger_db(depth, cfg.freq_ghz)) + min(hits, 2) * cfg.trunk_loss_db
                snr = self.snr_at_R - 10.0 * nexp * math.log10(d / R) - loss
                key = (self.ids[i], self.ids[j])
                self.pairs.append(key)
                self.mean_snr[key] = snr
                self.veg_depth[key] = depth
                self.trunk_hits[key] = hits
                W = cfg.radio_wind_kmh if cfg.radio_wind_kmh is not None else (cfg.wind_kmh or 0.0)
                if cfg.radio_wind_fading and W > 0 and depth > 0:
                    self._sigma[key] = cfg.fade_sigma_db_per_kmh * W * min(1.0, depth / cfg.fade_ref_depth_m)
                else:
                    self._sigma[key] = 0.0
                self._fade[key] = 0.0

    def _link_budget_matrix(self):
        cfg = self.cfg
        M = np.loadtxt(cfg.link_gain_csv, delimiter=",")
        side = int(round(math.sqrt(self.n)))
        sp = cfg.spacing_m
        idx = [int(round(p[0] / sp)) * side + int(round(p[1] / sp)) for p in self.pos]
        for i in range(self.n):
            for j in range(i + 1, self.n):
                g = min(M[idx[i], idx[j]], M[idx[j], idx[i]])
                key = (self.ids[i], self.ids[j])
                self.pairs.append(key)
                self.mean_snr[key] = 99.0 if g > cfg.link_min_gain_db else -99.0
                self.veg_depth[key] = 0.0
                self.trunk_hits[key] = 0
                self._sigma[key] = 0.0
                self._fade[key] = 0.0

    # --- graph ---
    def adjacency(self) -> dict[int, list[int]]:
        adj = {i: [] for i in self.ids}
        thr = self.cfg.prr_link_min
        for key in self.pairs:
            if float(prr(self.mean_snr[key], self.cfg.packet_bytes)) >= thr:
                u, v = key
                adj[u].append(v)
                adj[v].append(u)
        return adj

    # --- time evolution ---
    def _prepare_fading(self):
        keys = [k for k, sg in self._sigma.items() if sg > 0.0]
        self._fkeys = keys
        self._fset = [frozenset(k) for k in keys]
        self._fsig = np.array([self._sigma[k] for k in keys])
        self._fmean = np.array([self.mean_snr[k] for k in keys])
        self._fx = np.zeros(len(keys))
        grid = np.linspace(-20.0, 30.0, 2001)
        self._snr_grid, self._prr_grid = grid, prr(grid, self.cfg.packet_bytes)

    def step(self) -> dict[frozenset, bool]:
        """Advance the correlated fading one tick; return {link: up?} for faded links only."""
        if not hasattr(self, "_fkeys"):
            self._prepare_fading()
        if not self._fkeys:
            return {}
        cfg = self.cfg
        rho = math.exp(-cfg.dt / cfg.fade_tau_s)
        m = len(self._fkeys)
        self._fx = rho * self._fx + math.sqrt(1.0 - rho * rho) * self._fsig * self._rng.standard_normal(m)
        p = np.interp(self._fmean + self._fx, self._snr_grid, self._prr_grid)
        up = self._rng.random(m) < p
        return dict(zip(self._fset, up.tolist()))
