import mitsuba as mi
mi.set_variant("llvm_ad_mono_polarized")

import numpy as np
import networkx as nx
import sionna.rt as rt
import json

from pathlib import Path
from sionna.rt import load_scene, PlanarArray
from sionna.rt import Transmitter, Receiver, PathSolver

ROOT = Path(__file__).resolve().parents[1]

frequency = 2.4e9
threshold = 90
steps = 16
speed = 2.0

initial_positions = [
    [-23, -25, 1.5],
    [-23, -5, 1.5],
    [-23, 20, 1.5],
    [24, -25, 1.5],
    [24, 5, 1.5],
    [24, 30, 1.5],
    [-65, 0, 1.5],
    [0, 0, 1.5],
    [65, 0, 1.5]
]

directions = [
    [0, 1],
    [0, 1],
    [0, 1],
    [0, 1],
    [0, 1],
    [0, -1],
    [1, 0],
    [1, 0],
    [-1, 0]
]

layout = load_scene(
    rt.scene.simple_street_canyon,
    merge_shapes=False
)

buildings = []

for name, obj in layout.objects.items():

    box = obj.mi_mesh.bbox()

    buildings.append({
        "name": name,
        "min": [
            float(box.min.x),
            float(box.min.y),
            float(box.min.z)
        ],
        "max": [
            float(box.max.x),
            float(box.max.y),
            float(box.max.z)
        ]
    })

solver = PathSolver(deterministic=True)

snapshots = []


def generate_nodes(step):

    nodes = []

    for i, position in enumerate(initial_positions):

        x = position[0] + directions[i][0] * speed * step
        y = position[1] + directions[i][1] * speed * step
        z = position[2]

        for building in buildings:

            if building["name"] == "floor":
                continue

            low = building["min"]
            high = building["max"]

            if (
                low[0] <= x <= high[0]
                and low[1] <= y <= high[1]
                and low[2] <= z <= high[2]
            ):
                raise ValueError(
                    f"Node {i} is inside a building"
                )

        nodes.append({
            "id": format(i, "04x"),
            "x": x,
            "y": y,
            "z": z
        })

    return nodes


def calculate_links(nodes):

    links = []
    measurements = []

    for i in range(len(nodes) - 1):

        scene = load_scene(
            rt.scene.simple_street_canyon,
            merge_shapes=False
        )

        scene.frequency = frequency

        scene.tx_array = PlanarArray(
            num_rows=1,
            num_cols=1,
            pattern="iso",
            polarization="V"
        )

        scene.rx_array = scene.tx_array

        source = nodes[i]

        scene.add(Transmitter(
            name="tx",
            position=[
                source["x"],
                source["y"],
                source["z"]
            ]
        ))

        targets = nodes[i + 1:]

        for target in targets:

            scene.add(Receiver(
                name="rx_" + target["id"],
                position=[
                    target["x"],
                    target["y"],
                    target["z"]
                ]
            ))

        paths = solver(
            scene,
            max_depth=3,
            los=True,
            specular_reflection=True,
            diffuse_reflection=False,
            refraction=False,
            samples_per_src=200000,
            seed=42
        )

        real, imag = paths.a

        power = real.numpy()**2 + imag.numpy()**2

        for j, target in enumerate(targets):

            gain = np.sum(power[j])

            loss = (
                float(-10 * np.log10(gain))
                if gain > 0 else float("inf")
            )

            connected = loss <= threshold

            measurement = {
                "source": source["id"],
                "target": target["id"],
                "path_loss_db": (
                    round(loss, 2)
                    if np.isfinite(loss) else None
                ),
                "connected": bool(connected)
            }

            measurements.append(measurement)

            if connected:
                links.append({
                    "source": source["id"],
                    "target": target["id"],
                    "path_loss_db": round(loss, 2)
                })

        print("Source completed:", i + 1, "/", len(nodes) - 1)

    return links, measurements


for step in range(steps):

    print("\nTime Step:", step)
    print("--------------------------")

    nodes = generate_nodes(step)

    links, measurements = calculate_links(nodes)

    G = nx.Graph()

    G.add_nodes_from(node["id"] for node in nodes)

    G.add_edges_from(
        (link["source"], link["target"])
        for link in links
    )

    isolated = list(nx.isolates(G))

    snapshot = {
        "time": step,
        "nodes": nodes,
        "links": links,
        "measurements": measurements,
        "statistics": {
            "total_nodes": len(nodes),
            "connected_links": len(links),
            "isolated_nodes": isolated,
            "connected_components":
                nx.number_connected_components(G),
            "network_connected": nx.is_connected(G)
        }
    }

    snapshots.append(snapshot)

    print("Connected links:", len(links))
    print("Isolated nodes:", isolated)
    print("Network connected:", nx.is_connected(G))


output = {
    "frequency": frequency,
    "threshold": threshold,
    "speed": speed,
    "buildings": buildings,
    "snapshots": snapshots
}

with open(ROOT / "results/urban_mobility.json", "w") as f:
    json.dump(output, f, indent=4)

print("\nUrban Mobility Simulation Completed")
print("Total snapshots:", len(snapshots))
print("Saved: results/urban_mobility.json")