"""Paired-by-seed analysis of study_raw.csv.
Usage: python3 -I analyze.py study_raw.csv out_dir
Each seed is a replicate (own forest, jitter, dropouts, fading). Differences are
paired within (grid, theta, seed) and summarised with t-based 95% CIs plus a
sign-flip permutation p-value.
"""
import sys, os, itertools
import numpy as np, pandas as pd
from scipy import stats

raw, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
df = pd.read_csv(raw)
EP = ["links", "delivery", "orphan_frac", "mean_hops", "false_pos", "dir_err", "eta_err"]
KEY = ["grid", "theta", "seed"]


def ci(d):
    d = np.asarray(d, float); d = d[~np.isnan(d)]
    n = len(d)
    if n < 2:
        return np.nan, np.nan, np.nan, np.nan, n
    m, se = d.mean(), d.std(ddof=1) / np.sqrt(n)
    h = stats.t.ppf(0.975, n - 1) * se
    rng = np.random.default_rng(0)
    signs = rng.choice([-1, 1], size=(5000, n))
    p = (np.abs((signs * d).mean(1)) >= abs(m) - 1e-12).mean()
    return m, m - h, m + h, p, n


# 1. cell means
cell = df.groupby(["canopy", "wind"])[EP + ["sink_dead"]].mean().round(3)
cell.to_csv(f"{out}/cell_means.csv")

# 2. paired contrasts
rows = []
def contrast(name, a, b, filt=None):
    """a - b where a,b are (canopy,wind) tuples."""
    A = df[(df.canopy == a[0]) & (df.wind == a[1])].set_index(KEY)
    B = df[(df.canopy == b[0]) & (df.wind == b[1])].set_index(KEY)
    idx = A.index.intersection(B.index)
    for e in EP:
        m, lo, hi, p, n = ci((A.loc[idx, e] - B.loc[idx, e]).values)
        rows.append(dict(contrast=name, endpoint=e, mean=m, lo=lo, hi=hi, p=p, n=n))

for c in ["sparse", "medium", "dense"]:
    contrast(f"{c} vs open | calm", (c, "calm"), ("open", "calm"))
    contrast(f"{c} vs open | w20_fire+radio", (c, "w20_fire+radio"), ("open", "w20_fire+radio"))
    contrast(f"{c} vs open | w40_fire+radio", (c, "w40_fire+radio"), ("open", "w40_fire+radio"))
for c in ["open", "sparse", "medium", "dense"]:
    contrast(f"radio fading on vs off | w20 | {c}", (c, "w20_fire+radio"), (c, "w20_fire"))
    contrast(f"radio fading on vs off | w40 | {c}", (c, "w40_fire+radio"), (c, "w40_fire"))
    contrast(f"wind40 fire only vs calm | {c}", (c, "w40_fire"), (c, "calm"))

pd.DataFrame(rows).round(4).to_csv(f"{out}/paired_contrasts.csv", index=False)

# 3. interaction canopy x radio fading at w40 (difference of differences)
inter = []
for c in ["sparse", "medium", "dense"]:
    for e in EP:
        def d(canopy, wind):
            return df[(df.canopy == canopy) & (df.wind == wind)].set_index(KEY)[e]
        dd = (d(c, "w40_fire+radio") - d(c, "w40_fire")) - (d("open", "w40_fire+radio") - d("open", "w40_fire"))
        m, lo, hi, p, n = ci(dd.dropna().values)
        inter.append(dict(canopy=c, endpoint=e, did=m, lo=lo, hi=hi, p=p, n=n))
pd.DataFrame(inter).round(4).to_csv(f"{out}/interaction_did.csv", index=False)

# 4. sanity: open-field + calm must equal the distance graph link count
print(cell.to_string())
print(pd.DataFrame(rows).round(3).to_string())
