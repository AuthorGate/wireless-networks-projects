"""
platform_core.py -- logic of the "Neighbourhood Water-Tank Monitoring Platform"
==============================================================================
No HTTP in this file, so it can be unit-tested directly.

Idea: the simulator (wsn_sim.py) computes, round by round, which sensor node
sends to whom and how much energy it burns.  This file adds

  * a synthetic TANK-LEVEL model (what each rooftop tank "really" contains),
  * a snapshot function  state(run, round)  that merges both into one JSON-ready
    dictionary: node positions, energy, alive/dead, roles, links, tank levels, alerts.

One round = one hour (one level report per tank per hour).
"""
from __future__ import annotations
import json, os, threading, time
from dataclasses import replace
import numpy as np
from wsn_sim import Params, PROTOCOLS, make_layout

PROTOCOL_NAMES = ["PEGASIS", "PEGASIS-2opt", "PEGASIS-E", "PEGASIS-MC", "LEACH", "Direct"]
LOW_LEVEL = 15.0        # % -> "tank almost empty" alert
HIGH_LEVEL = 99.5       # % -> "tank overflowing" alert
MAX_CACHE = 24
REAL_LAYOUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "real_layout.json")

_cache: dict = {}


# ------------------------------------------------------------------ tanks ---
def tank_levels(pos: np.ndarray, field: float, rounds: int, seed: int) -> np.ndarray:
    """Synthetic level (%) of every tank for t = 0..rounds   (array [rounds+1, N]).

    Assumptions (all synthetic, see README):
      * the block is split into 4 supply zones that get public water in turn:
        8 hours of supply every 72 hours per zone, filling +5 % of the tank per hour
      * each household consumes 0.25-0.90 % of its tank per hour (random per tank)
    """
    n = len(pos)
    rng = np.random.default_rng(90_000 + seed)
    zone = (pos[:, 0] > field / 2).astype(int) * 2 + (pos[:, 1] > field / 2).astype(int)
    phase = zone * 18 + rng.integers(0, 3, n)
    cons = rng.uniform(0.25, 0.90, n)
    L = np.empty((rounds + 1, n))
    L[0] = rng.uniform(40, 100, n)
    for t in range(1, rounds + 1):
        supply = ((t + phase) % 72) < 8
        noise = rng.uniform(0.7, 1.3, n)
        L[t] = np.clip(L[t - 1] + np.where(supply, 5.0, 0.0) - cons * noise, 0, 100)
    return L


# ------------------------------------------------------------------- runs ---
LAYOUTS = ("real", "random")


def default_layout() -> str:
    """'real' when engine/real_layout.json exists (real OpenStreetMap buildings), otherwise 'random'."""
    return "real" if os.path.exists(REAL_LAYOUT) else "random"


def real_count() -> int:
    if not os.path.exists(REAL_LAYOUT):
        return 0
    with open(REAL_LAYOUT) as f:
        return len(json.load(f)["positions"])


class Run:
    """One complete simulated life of the network for (protocol, seed, n, layout).

    layout = "real"   : the buildings of real_layout.json.  n >= number of buildings -> all of them;
                        n < number of buildings -> a random subset of n buildings (chosen by `seed`),
                        i.e. 'what if only n households join the monitoring programme?'
    layout = "random" : n random positions in a 200 m x 200 m block (seed decides where)."""

    def __init__(self, protocol: str, seed: int, n: int, layout: str):
        self.protocol, self.seed, self.layout = protocol, seed, layout
        if layout == "real":
            with open(REAL_LAYOUT) as f:
                L = json.load(f)
            allpos = np.array(L["positions"], float)
            if n < len(allpos):
                keep = np.sort(np.random.default_rng(seed).choice(len(allpos), size=n, replace=False))
                self.pos = allpos[keep]
            else:
                self.pos = allpos
            n = len(self.pos)
            self.P = replace(Params(), n_nodes=n, field=float(L["field"]), sink=tuple(L["sink"]))
        else:
            self.P = replace(Params(), n_nodes=n)
            self.pos = make_layout(self.P, np.random.default_rng(seed))
        self.n = n
        res = PROTOCOLS[protocol](self.P, self.pos, np.random.default_rng(10_000 + seed), record=True)
        self.res = res
        self.log = res["log"]
        self.rounds = len(self.log)
        self.death = res["death_round"]                       # 1-based round of death, NaN if never
        self.levels = tank_levels(self.pos, self.P.field, self.rounds, seed)


def get_run(protocol: str, seed: int, n: int, layout: str | None = None) -> Run:
    layout = layout or default_layout()
    key = (protocol, seed, n, layout)
    if key not in _cache:
        if len(_cache) >= MAX_CACHE:
            _cache.pop(next(iter(_cache)))
        _cache[key] = Run(protocol, seed, n, layout)
    return _cache[key]


def check_args(protocol, seed, n, layout=None):
    if protocol not in PROTOCOLS:
        raise ValueError(f"protocol must be one of {list(PROTOCOLS)}")
    if not (0 <= seed <= 100_000):
        raise ValueError("seed must be 0..100000")
    if not (10 <= n <= 300):
        raise ValueError("n must be 10..300")
    if layout is not None and layout not in LAYOUTS:
        raise ValueError(f"layout must be one of {list(LAYOUTS)}")
    if layout == "real" and not os.path.exists(REAL_LAYOUT):
        raise ValueError("there is no real_layout.json: run prepare_layout.py first, or use layout=random")


# ---------------------------------------------------------------- outputs ---
def bottleneck(run: Run):
    """The first node to die: who was it, how far from the base station, how often had it been leader / cluster head."""
    if np.all(np.isnan(run.death)):
        return None
    i = int(np.nanargmin(run.death))
    d = int(run.death[i])
    served = 0
    for entry in run.log[:d]:
        role = entry["role"]
        if role is None:
            continue
        if role["kind"] == "pegasis":
            served += int(role["leader"] == i)
        elif role["kind"] == "pegasis_mc":
            served += int(i in role["leaders"])
        elif role["kind"] == "leach":
            served += int(bool(np.any(role["heads"] == i)))
    dist = float(np.hypot(run.pos[i, 0] - run.P.sink[0], run.pos[i, 1] - run.P.sink[1]))
    return dict(node=i, round=d, dist_bs=round(dist, 1), served_as_leader=served)


def summary(run: Run) -> dict:
    r = run.res
    return dict(
        protocol=run.protocol, seed=run.seed, n=run.n, rounds=run.rounds, layout=run.layout,
        fnd=r["fnd"], hnd=r["hnd"], lnd=r["lnd"],
        avg_hops=round(r["hops"], 2),
        sink_packets=int(r["sink_packets"]), readings=int(r["readings"]),
        alive_curve=[int(x) for x in r["alive"]],
        energy_curve=[round(float(x), 4) for x in r["energy"]],
        field=run.P.field, sink=list(run.P.sink), e0=run.P.e0, bottleneck=bottleneck(run),
    )


def _pct(new, old):
    return None if not old or new is None else round(100.0 * (new / old - 1.0), 1)


def compare(seed: int, n: int, layout: str | None = None) -> dict:
    """All protocols on the SAME deployment, plus the change of every protocol relative to LEACH and plain PEGASIS."""
    layout = layout or default_layout()
    out = {}
    for p in PROTOCOL_NAMES:
        run = get_run(p, seed, n, layout)
        s = summary(run)
        out[p] = dict(fnd=s["fnd"], hnd=s["hnd"], lnd=s["lnd"], avg_hops=s["avg_hops"], alive_curve=s["alive_curve"])
        n_actual = run.n
    for p in out:
        for ref, key in (("LEACH", "vs_leach"), ("PEGASIS", "vs_pegasis")):
            out[p][key] = [_pct(out[p][m], out[ref][m]) for m in ("fnd", "hnd", "lnd")]
    return dict(seed=seed, n=n_actual, layout=layout, results=out)


def state(run: Run, rnd: int) -> dict:
    """Everything the dashboard needs to draw the network after `rnd` rounds."""
    rnd = int(max(0, min(rnd, run.rounds)))
    n, P = run.n, run.P
    if rnd == 0:
        E = np.full(n, P.e0, dtype=float)
        alive = np.ones(n, bool)
        role = None
    else:
        entry = run.log[rnd - 1]
        E, alive, role = entry["E"].astype(float), entry["alive"], entry["role"]

    # --- what does each node play this round?
    kinds = ["idle"] * n
    links = []
    packets, hops = 0, 0
    if role is not None:
        if role["kind"] == "leach":
            for h in role["heads"]:
                kinds[int(h)] = "head"
                links.append([int(h), -1])
            for m, h in zip(role["members"], role["assign"]):
                kinds[int(m)] = "member"
                links.append([int(m), int(h)])
            packets, hops = len(role["heads"]), (2 if len(role["members"]) else 1)
        elif role["kind"] == "pegasis":
            ch = [int(c) for c in role["chain"]]
            for c in ch:
                kinds[c] = "chain"
            kinds[role["leader"]] = "leader"
            links += [[ch[i], ch[i + 1]] for i in range(len(ch) - 1)]
            links.append([role["leader"], -1])
            L = ch.index(role["leader"])
            packets, hops = 1, max(L, len(ch) - 1 - L) + 1
        elif role["kind"] == "pegasis_mc":
            packets = len(role["chains"])
            for chain_arr, ld in zip(role["chains"], role["leaders"]):
                ch = [int(c) for c in chain_arr]
                for c in ch:
                    kinds[c] = "chain"
                kinds[ld] = "leader"
                links += [[ch[i], ch[i + 1]] for i in range(len(ch) - 1)]
                links.append([ld, -1])
                L = ch.index(ld)
                hops = max(hops, max(L, len(ch) - 1 - L) + 1)
        else:  # direct
            for i in np.flatnonzero(alive):
                kinds[int(i)] = "member"
                links.append([int(i), -1])
            packets, hops = int(alive.sum()), 1

    # --- tank levels as the BASE STATION knows them
    nodes, alerts = [], []
    for i in range(n):
        dr = run.death[i]
        if alive[i] or rnd == 0:
            seen_t, age = rnd, 0
        else:                                   # dead node: last report was before it died
            seen_t = int(max(0, dr - 1)) if not np.isnan(dr) else rnd
            seen_t = min(seen_t, rnd)
            age = rnd - seen_t
        lvl = float(run.levels[seen_t, i])
        nodes.append(dict(id=i, x=round(float(run.pos[i, 0]), 1), y=round(float(run.pos[i, 1]), 1),
                          energy=round(float(E[i] / P.e0), 4), alive=bool(alive[i]), role=kinds[i],
                          level=round(lvl, 1), age=int(age)))
        if alive[i]:
            if lvl <= LOW_LEVEL:
                alerts.append(dict(node=i, type="low", level=round(lvl, 1)))
            elif lvl >= HIGH_LEVEL:
                alerts.append(dict(node=i, type="overflow", level=round(lvl, 1)))
    n_alive = int(alive.sum())
    return dict(
        protocol=run.protocol, seed=run.seed, n=n, round=rnd, rounds=run.rounds,
        alive=n_alive, dead=n - n_alive, coverage=round(100.0 * n_alive / n, 1),
        total_energy=round(float(E.sum()), 4), sink_packets=packets, hops=hops,
        nodes=nodes, links=links, alerts=alerts, sink=list(P.sink), field=P.field,
        blind=[i for i in range(n) if not alive[i]],
    )


# ------------------------------------------------------------ live session ---
# The "live" session is a simulated clock that lives in the ENGINE but is driven from OUTSIDE: Node-RED's flow calls
# POST /api/live/step every couple of seconds, and the dashboard (mode "Live") just shows the current round.
# Nothing advances unless something calls step -> if Node-RED is stopped, the live clock stops (and the dashboard says so).
LIVE = dict(protocol="PEGASIS-E", layout=None, seed=0, n=100, round=0, loops=0, steps=0, last_step=None, paused=True)   # paused = READY: nothing moves until a session is started


def live_reset(protocol: str, seed: int, n: int, layout: str | None = None) -> dict:
    layout = layout or default_layout()
    check_args(protocol, seed, n, layout)
    LIVE.update(protocol=protocol, layout=layout, seed=seed, n=n, round=0, loops=0, steps=0, paused=False)
    return live_status(with_state=False)


def live_pause(on: bool) -> dict:
    """Pause / resume the live clock (Node-RED stops ticking; the dashboard shows PAUSED instead of STOPPED)."""
    LIVE["paused"] = bool(on)
    return live_status(with_state=False)


def live_step(steps: int = 5) -> dict:
    if LIVE["layout"] is None:
        LIVE["layout"] = default_layout()
    run = get_run(LIVE["protocol"], LIVE["seed"], LIVE["n"], LIVE["layout"])
    wrapped = False
    if LIVE["paused"]:                                  # the clock does not move while paused
        st = state(run, LIVE["round"])
        return dict(round=st["round"], rounds=run.rounds, alive=st["alive"], coverage=st["coverage"], alerts=st["alerts"],
                    wrapped=False, protocol=run.protocol, layout=run.layout, paused=True)
    if LIVE["round"] >= run.rounds:                     # the network died: start the demo again
        LIVE["round"], wrapped = 0, True
        LIVE["loops"] += 1
    else:
        LIVE["round"] = min(LIVE["round"] + int(steps), run.rounds)
    LIVE["steps"] += 1
    LIVE["last_step"] = time.time()
    st = state(run, LIVE["round"])
    return dict(round=st["round"], rounds=run.rounds, alive=st["alive"], coverage=st["coverage"], alerts=st["alerts"],
                wrapped=wrapped, protocol=run.protocol, layout=run.layout, paused=False)


def live_status(with_state: bool = True) -> dict:
    if LIVE["layout"] is None:
        LIVE["layout"] = default_layout()
    run = get_run(LIVE["protocol"], LIVE["seed"], LIVE["n"], LIVE["layout"])
    age = None if LIVE["last_step"] is None else round(time.time() - LIVE["last_step"], 1)
    out = dict(protocol=LIVE["protocol"], layout=LIVE["layout"], seed=LIVE["seed"], n=run.n, round=LIVE["round"],
               rounds=run.rounds, loops=LIVE["loops"], steps=LIVE["steps"], age_s=age, paused=LIVE["paused"])
    if with_state:
        out["state"] = state(run, LIVE["round"])
    return out
