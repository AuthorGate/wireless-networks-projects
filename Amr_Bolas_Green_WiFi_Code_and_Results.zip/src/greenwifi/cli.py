from __future__ import annotations

import argparse
import json
from pathlib import Path

from .scheduler import SchedulerConfig, evaluate, load_trace, write_outputs


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Evaluate a conservative traffic-aware Wi-Fi AP sleep advisory policy."
    )
    parser.add_argument("--input", default="data/demo_trace.csv", help="CSV telemetry trace")
    parser.add_argument("--config", default="config/config.json", help="JSON scheduler and power configuration")
    parser.add_argument("--out", default="results", help="Output directory")
    args = parser.parse_args()

    try:
        config = SchedulerConfig.from_json(args.config)
        rows = load_trace(args.input)
        decisions, summary = evaluate(rows, config)
        write_outputs(decisions, summary, args.out)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))

    print(json.dumps(summary, indent=2))
    print(f"\nDetailed decisions: {Path(args.out) / 'decisions.csv'}")
    print(f"Evaluation report:  {Path(args.out) / 'report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
