import json
import random
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

random.seed(42)

with open(ROOT / "results/network.json") as f:
    network = json.load(f)

nodes = network["nodes"]
distance = 2.0

for node in nodes:
    angle = random.uniform(0, 2 * math.pi)

    node["x"] += distance * math.cos(angle)
    node["y"] += distance * math.sin(angle)

    print(
        node["id"],
        "| X:", round(node["x"], 2),
        "| Y:", round(node["y"], 2)
    )

with open(ROOT / "results/mobile_positions.json", "w") as f:
    json.dump({"nodes": nodes}, f, indent=4)

print("-------------------------")
print("Total nodes:", len(nodes))
print("Movement distance:", distance, "m")
print("Mobility scenario generated")