import json
import networkx as nx
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/network.json") as f:
    static = json.load(f)

with open(ROOT / "results/mobile_network.json") as f:
    mobile = json.load(f)


def build_graph(network):
    G = nx.Graph()

    for node in network["nodes"]:
        G.add_node(node["id"])

    for link in network["links"]:
        G.add_edge(
            link["source"],
            link["target"],
            loss=link["path_loss_db"]
        )

    return G


def create_clusters(G, scores):
    remaining = set(G.nodes)
    clusters = {}

    while remaining:
        head = max(
            remaining,
            key=lambda n: (scores[n], n)
        )

        members = (
            set(G.neighbors(head)) & remaining
        ) | {head}

        clusters[head] = sorted(members)
        remaining -= members

    return clusters


old = build_graph(static)
new = build_graph(mobile)

old_scores = dict(old.degree())
old_clusters = create_clusters(old, old_scores)

old_heads = set(old_clusters)

max_degree = max(1, max(dict(new.degree()).values()))

scores = {}

for node in new.nodes:

    neighbors = set(new.neighbors(node))
    previous = set(old.neighbors(node))

    degree = len(neighbors) / max_degree

    quality = 0

    if neighbors:
        quality = sum(
            max(0, min(1, (62 - new[node][n]["loss"]) / 10))
            for n in neighbors
        ) / len(neighbors)

    common = neighbors & previous
    total = neighbors | previous

    stability = len(common) / len(total) if total else 0

    retention = 1 if node in old_heads and neighbors else 0

    scores[node] = (
        0.3 * degree +
        0.3 * quality +
        0.3 * stability +
        0.1 * retention
    )

traditional = create_clusters(new, dict(new.degree()))
adaptive = create_clusters(new, scores)

output = {
    "initial_clusters": old_clusters,
    "traditional_clusters": traditional,
    "adaptive_clusters": adaptive,
    "scores": scores,
    "isolated_nodes": list(nx.isolates(new))
}

with open(ROOT / "results/clusters.json", "w") as f:
    json.dump(output, f, indent=4)

print("Adaptive Clustering Results")
print("---------------------------")

for head, members in adaptive.items():
    print("Cluster Head:", head)
    print("Members:", members)
    print("Score:", round(scores[head], 4))
    print()

print("Total nodes:", new.number_of_nodes())
print("Initial clusters:", len(old_clusters))
print("Traditional clusters:", len(traditional))
print("Adaptive clusters:", len(adaptive))
print("Traditional retained heads:", len(old_heads & set(traditional)))
print("Adaptive retained heads:", len(old_heads & set(adaptive)))
print("Assigned nodes:", sum(len(m) for m in adaptive.values()))
print("Isolated nodes:", list(nx.isolates(new)))
print("Clustering completed")