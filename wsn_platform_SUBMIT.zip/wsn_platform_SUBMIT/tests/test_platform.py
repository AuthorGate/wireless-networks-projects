"""
test_platform.py -- automated checks for the whole platform.   Run:  python tests/test_platform.py
Covers: simulator regression, tank model, state snapshots, HTTP API (good and bad input),
dashboard JavaScript (with a fake DOM via Node.js, skipped if Node is not installed),
and the Node-RED flow file (structure + embedded JavaScript syntax).
"""
import io, json, os, shutil, socket, struct, subprocess, sys, tempfile, threading, time, unittest, urllib.request, urllib.error

os.environ["WSN_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")        # tests never touch your real database

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")
sys.path.insert(0, os.path.join(ROOT, "engine"))

import numpy as np
import platform_core as core
import server
import store
import wsn_sim
import ablation
core.REAL_LAYOUT = os.path.join(ROOT, "__no_real_layout__")      # tests use the random layout


def get(port, path):
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=30) as r:
            return r.status, r.read(), r.headers.get("Content-Type")
    except urllib.error.HTTPError as e:
        return e.code, e.read(), e.headers.get("Content-Type")


class CoreTests(unittest.TestCase):
    def test_regression_seed0(self):
        # numbers identical to the report's simulator (seed 0, 100 nodes)
        exp = {"PEGASIS": (107, 980, 1122), "LEACH": (152, 530, 878), "Direct": (20, 149, 1563)}
        for p, e in exp.items():
            s = core.summary(core.get_run(p, 0, 100))
            self.assertEqual((s["fnd"], s["hnd"], s["lnd"]), e, p)

    def test_tank_levels_bounds(self):
        run = core.get_run("PEGASIS", 3, 60)
        self.assertTrue(run.levels.min() >= 0 and run.levels.max() <= 100)
        self.assertEqual(run.levels.shape, (run.rounds + 1, 60))

    def test_state_invariants_all_protocols(self):
        for p in core.PROTOCOL_NAMES:
            run = core.get_run(p, 1, 80)
            for r in (0, 1, 7, run.rounds // 2, run.rounds, run.rounds + 50):
                st = core.state(run, r)
                self.assertEqual(st["alive"] + st["dead"], 80)
                self.assertEqual(st["alive"], sum(n["alive"] for n in st["nodes"]))
                rr = min(r, run.rounds)                                     # the engine clamps r to the last round
                prev = core.state(run, rr - 1) if rr > 0 else st
                for a, b in st["links"]:
                    self.assertTrue(-1 <= a < 80 and -1 <= b < 80)
                    # a node that dies DURING round r still transmits in round r,
                    # so the sender must have been alive at the START of the round
                    self.assertTrue(prev["nodes"][a]["alive"])
                for al in st["alerts"]:
                    self.assertTrue(st["nodes"][al["node"]]["alive"])    # dead nodes cannot alert
                self.assertTrue(all(0 <= n["energy"] <= 1.0001 for n in st["nodes"]))
            self.assertEqual(core.state(run, 0)["alive"], 80)
            self.assertEqual(core.state(run, run.rounds)["alive"], 0)
            self.assertEqual(core.state(run, 10**6)["round"], run.rounds)   # clamped

    def test_pegasis_link_count_and_leach_structure(self):
        run = core.get_run("PEGASIS", 2, 50)
        st = core.state(run, 5)
        self.assertEqual(len(st["links"]), st["alive"])                  # (alive-1) chain links + 1 to BS
        self.assertEqual(st["sink_packets"], 1)
        run = core.get_run("LEACH", 2, 50)
        st = core.state(run, 5)
        heads = [n for n in st["nodes"] if n["role"] == "head"]
        self.assertEqual(st["sink_packets"], len(heads))
        self.assertTrue(len(st["links"]) >= len(heads))

    def test_dead_node_keeps_last_known_level(self):
        run = core.get_run("Direct", 0, 100)
        st = core.state(run, run.rounds // 2)
        dead = [n for n in st["nodes"] if not n["alive"]]
        self.assertTrue(dead and all(n["age"] > 0 or True for n in dead))
        n0 = dead[0]
        d = int(run.death[n0["id"]])
        self.assertAlmostEqual(n0["level"], round(float(run.levels[d - 1, n0["id"]]), 1), places=1)

    def test_bad_arguments(self):
        for args in (("Nope", 0, 100), ("PEGASIS", -1, 100), ("PEGASIS", 0, 5), ("PEGASIS", 0, 1000)):
            with self.assertRaises(ValueError):
                core.check_args(*args)


class AlgorithmTests(unittest.TestCase):
    def test_simulator_selftests(self):
        self.assertTrue(wsn_sim.selftest(verbose=False))

    def test_multichain_partitions_alive_nodes(self):
        run = core.get_run("PEGASIS-MC", 4, 80)
        for r in (1, 50, run.rounds // 2):
            role = run.log[r - 1]["role"]
            allnodes = np.concatenate(role["chains"])
            self.assertEqual(len(allnodes), len(set(allnodes.tolist())))          # no node in two chains
            self.assertEqual(len(role["chains"]), len(role["leaders"]))
            for ch, ld in zip(role["chains"], role["leaders"]):
                self.assertIn(ld, ch.tolist())
                links = np.hypot(np.diff(run.pos[ch, 0]), np.diff(run.pos[ch, 1]))
                self.assertTrue((links < run.P.d0).all())                          # no long links inside a chain


class LayoutTests(unittest.TestCase):
    def setUp(self):
        self.tmp = os.path.join(tempfile.mkdtemp(), "real.json")
        rng = np.random.default_rng(0)
        json.dump(dict(positions=rng.uniform(0, 300, (30, 2)).round(1).tolist(), field=300.0, sink=[150.0, 350.0]), open(self.tmp, "w"))
        self.old = core.REAL_LAYOUT
        core.REAL_LAYOUT = self.tmp
        core._cache.clear()

    def tearDown(self):
        core.REAL_LAYOUT = self.old
        core._cache.clear()

    def test_real_layout_default_and_subsets(self):
        self.assertEqual(core.default_layout(), "real")
        self.assertEqual(core.real_count(), 30)
        all_ = core.get_run("PEGASIS-E", 0, 100)                       # n >= 30 -> every real building
        self.assertEqual((all_.layout, all_.n), ("real", 30))
        a, b = core.get_run("PEGASIS-E", 1, 15), core.get_run("PEGASIS-E", 2, 15)
        self.assertEqual((a.n, b.n), (15, 15))
        self.assertFalse(np.array_equal(a.pos, b.pos))                   # the seed picks different buildings
        self.assertTrue(all(any(np.allclose(p, q) for q in all_.pos) for p in a.pos))   # ...but always real ones
        self.assertEqual(core.summary(a)["n"], 15)

    def test_random_layout_still_available(self):
        r = core.get_run("LEACH", 0, 40, "random")
        self.assertEqual((r.layout, r.n, r.P.field), ("random", 40, 200.0))

    def test_real_layout_needs_file(self):
        core.REAL_LAYOUT = os.path.join(os.path.dirname(self.tmp), "missing.json")
        with self.assertRaises(ValueError):
            core.check_args("PEGASIS", 0, 50, "real")
        with self.assertRaises(ValueError):
            core.check_args("PEGASIS", 0, 50, "moon")

    def test_compare_relative_changes_and_bottleneck(self):
        c = core.compare(0, 100)
        self.assertEqual(c["results"]["LEACH"]["vs_leach"], [0.0, 0.0, 0.0])
        self.assertEqual(c["results"]["PEGASIS"]["vs_pegasis"], [0.0, 0.0, 0.0])
        b = core.summary(core.get_run("PEGASIS", 0, 100))["bottleneck"]
        self.assertEqual(set(b), {"node", "round", "dist_bs", "served_as_leader"})
        self.assertEqual(b["round"], core.get_run("PEGASIS", 0, 100).res["fnd"])


class StoreAndParallelTests(unittest.TestCase):
    def test_store_roundtrip_and_replace(self):
        s = core.summary(core.get_run("LEACH", 7, 60))
        n0 = store.count()
        rid = store.save_run(s, "random")
        rid2 = store.save_run(s, "random")                                   # same key -> replaced, not duplicated
        self.assertEqual(store.count(), n0 + 1)
        c = store.curve(rid2)
        self.assertEqual(c["alive"], s["alive_curve"])
        self.assertIsNone(store.curve(rid))                                  # AUTOINCREMENT ids are never reused
        self.assertEqual(store.history(1)[0]["protocol"], "LEACH")
        self.assertEqual(store.history(5, "LEACH")[0]["seed"], 7)

    def test_notifications_since_filter(self):
        store.add_notification("old-test-note", 1)
        self.assertEqual(store.notifications(5, "2999-01-01 00:00:00"), [])               # nothing newer than the far future
        self.assertTrue(any(n["text"] == "old-test-note" for n in store.notifications(50, "2000-01-01 00:00:00")))

    def test_live_session_starts_paused_until_started(self):
        r = subprocess.run([sys.executable, "-c", "import platform_core as c; print(c.live_status(False)['paused'])"],
                           cwd=os.path.join(ROOT, "engine"), capture_output=True, text=True)
        self.assertEqual(r.stdout.strip(), "True")                                       # READY: nothing moves by itself

    def test_sql_injection_is_harmless(self):
        n0 = store.count()
        self.assertEqual(store.history(5, "x'; DROP TABLE runs; --"), [])
        self.assertEqual(store.count(), n0)
        self.assertIsNone(store.curve(-5))

    def test_parallel_equals_sequential(self):
        jobs = [(v, "random", s) for v in ablation.VARIANTS[:3] for s in range(3)]
        self.assertEqual(sorted(ablation.run_jobs(jobs, 1), key=str), sorted(ablation.run_jobs(jobs, 2), key=str))


class ServerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = server.make_server("127.0.0.1", 0)
        cls.port = cls.srv.server_address[1]
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def test_health_config_and_dashboard(self):
        s, b, ct = get(self.port, "/api/health"); self.assertEqual((s, json.loads(b)), (200, {"ok": True}))
        s, b, _ = get(self.port, "/api/config"); self.assertIn("PEGASIS", json.loads(b)["protocols"])
        s, b, ct = get(self.port, "/"); self.assertEqual(s, 200); self.assertIn(b"Water-Tank", b)
        self.assertIn("text/html", ct)

    def test_summary_state_compare(self):
        s, b, _ = get(self.port, "/api/summary?protocol=LEACH&seed=0&n=100")
        d = json.loads(b); self.assertEqual(s, 200); self.assertEqual(d["protocol"], "LEACH"); self.assertEqual(d["lnd"], d["rounds"])
        s, b, _ = get(self.port, "/api/state?protocol=PEGASIS&seed=0&n=100&round=300")
        d = json.loads(b); self.assertEqual((s, d["round"], len(d["nodes"])), (200, 300, 100))
        s, b, _ = get(self.port, "/api/compare?seed=0&n=100")
        d = json.loads(b)["results"]; self.assertEqual(set(d), set(core.PROTOCOL_NAMES))
        self.assertGreater(d["PEGASIS"]["hnd"], d["LEACH"]["hnd"])          # the report's main finding

    def test_history_endpoint_after_summary(self):
        get(self.port, "/api/summary?protocol=PEGASIS-E&seed=3&n=50")
        s, b, _ = get(self.port, "/api/history?limit=5&protocol=PEGASIS-E")
        d = json.loads(b); self.assertEqual(s, 200); self.assertEqual(d["runs"][0]["seed"], 3)
        s, b, _ = get(self.port, f"/api/curve?id={d['runs'][0]['id']}")
        self.assertEqual(s, 200); self.assertEqual(len(json.loads(b)["alive"]), d["runs"][0]["rounds"])
        for path in ("/api/history?limit=0", "/api/history?limit=999", "/api/history?protocol=x'--"):
            self.assertEqual(get(self.port, path)[0], 400, path)
        self.assertEqual(get(self.port, "/api/curve?id=99999")[0], 404)

    def test_live_session_and_notifications_over_http(self):
        def post(path):
            req = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}", method="POST", data=b"")
            try:
                with urllib.request.urlopen(req, timeout=30) as r:
                    return r.status, json.loads(r.read())
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read())
        s, d = post("/api/live/reset?protocol=PEGASIS-E&layout=random&seed=4&n=50")
        self.assertEqual((s, d["round"], d["protocol"]), (200, 0, "PEGASIS-E"))
        s, d = post("/api/live/step?steps=10"); self.assertEqual((s, d["round"]), (200, 10))
        s, d = post("/api/live/step?steps=10"); self.assertEqual(d["round"], 20)
        live = json.loads(get(self.port, "/api/live")[1])
        self.assertEqual((live["round"], live["steps"], live["state"]["round"]), (20, 2, 20))
        self.assertLess(live["age_s"], 10)
        self.assertEqual(get(self.port, "/api/live/step")[0], 405)             # state-changing endpoints reject GET
        self.assertEqual(post("/api/live/step?steps=0")[0], 400)
        self.assertEqual(post("/api/live/reset?protocol=Nope")[0], 400)
        self.assertEqual(post("/api/nothing")[0], 404)
        self.assertEqual(post("/api/notify?text=")[0], 400)
        s, d = post("/api/notify?hour=20&text=Tank%20%233%20LOW%20%289%20%25%29")
        self.assertEqual(s, 200)
        notes = json.loads(get(self.port, "/api/notifications?limit=3")[1])["notifications"]
        self.assertEqual(notes[0]["text"], "Tank #3 LOW (9 %)")
        # run to the end: the clock wraps around and starts again
        for _ in range(400):
            s, d = post("/api/live/step?steps=500")
            if d["wrapped"]:
                break
        self.assertTrue(d["wrapped"] and d["round"] == 0)

    def test_activity_log_records_who_did_what(self):
        def post(path):
            req = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}", method="POST", data=b"")
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read())
        get(self.port, "/api/summary?protocol=PEGASIS-MC&layout=random&seed=41&n=35&action=load")      # dashboard Load
        get(self.port, "/api/summary?protocol=LEACH&layout=random&seed=42&n=35")                       # no action -> not logged
        post("/api/live/reset?protocol=LEACH&layout=random&seed=43&n=35&source=node-red")
        post("/api/live/pause?on=1&source=node-red"); post("/api/live/pause?on=0&source=we!rd/../x")
        acts = json.loads(get(self.port, "/api/activity?limit=20")[1])["activity"]
        kinds = [(a["kind"], a["protocol"], a["seed"], a["source"]) for a in acts]
        self.assertIn(("replay-load", "PEGASIS-MC", 41, "dashboard"), kinds)
        self.assertNotIn(("replay-load", "LEACH", 42, "dashboard"), kinds)
        self.assertIn(("live-start", "LEACH", 43, "node-red"), kinds)
        self.assertIn(("live-pause", "LEACH", 43, "node-red"), kinds)
        self.assertIn(("live-resume", "LEACH", 43, "unknown"), kinds)                                  # odd source is sanitised
        get(self.port, "/api/compare?seed=41&n=35&layout=random")
        dep = [d for d in json.loads(get(self.port, "/api/deployments?limit=50")[1])["deployments"] if d["seed"] == 41][0]
        self.assertEqual((dep["opened_with"]["protocol"], dep["opened_with"]["mode"]), ("PEGASIS-MC", "Replay"))
        dep = [d for d in json.loads(get(self.port, "/api/deployments?limit=50")[1])["deployments"] if d["seed"] == 43]
        s, body, ct = get(self.port, "/api/activity.csv")
        self.assertEqual((s, ct.split(";")[0]), (200, "text/csv"))
        self.assertTrue(body.decode().startswith("id,created,action,selected_protocol"))
        self.assertEqual(get(self.port, "/api/activity?limit=0")[0], 400)

    def test_pause_deployments_and_csv(self):
        def post(path):
            req = urllib.request.Request(f"http://127.0.0.1:{self.port}{path}", method="POST", data=b"")
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read())
        post("/api/live/reset?protocol=LEACH&layout=random&seed=9&n=40")
        self.assertEqual(post("/api/live/step?steps=5")["round"], 5)
        self.assertTrue(post("/api/live/pause?on=1")["paused"])
        d = post("/api/live/step?steps=5"); self.assertEqual((d["round"], d["paused"]), (5, True))
        self.assertTrue(json.loads(get(self.port, "/api/live")[1])["paused"])
        self.assertFalse(post("/api/live/pause?on=0")["paused"])
        self.assertEqual(post("/api/live/step?steps=5")["round"], 10)
        get(self.port, "/api/compare?seed=31&n=45&layout=random")
        dep = json.loads(get(self.port, "/api/deployments?limit=50")[1])
        row = [x for x in dep["deployments"] if x["seed"] == 31 and x["n"] == 45][0]
        self.assertEqual(row["protocols"], 6)
        self.assertEqual(set(row["best"]), {"fnd", "hnd", "lnd"})
        s, body, ct = get(self.port, "/api/export.csv")
        text = body.decode()
        self.assertEqual((s, ct.split(";")[0]), (200, "text/csv"))
        self.assertTrue(text.startswith("id,created,protocol,layout,tanks,seed"))
        self.assertGreaterEqual(len([l for l in text.splitlines() if ",random,45,31," in l]), 6)
        self.assertEqual(get(self.port, "/api/deployments?limit=0")[0], 400)

    def test_layout_parameter_and_config(self):
        d = json.loads(get(self.port, "/api/config")[1])
        self.assertEqual(d["layouts"], ["real", "random"])
        self.assertEqual(get(self.port, "/api/summary?layout=real")[0], 400)   # no real_layout.json in the tests
        self.assertEqual(json.loads(get(self.port, "/api/summary?layout=random&n=30")[1])["layout"], "random")

    def test_compare_logs_every_protocol(self):
        get(self.port, "/api/compare?seed=11&n=40")
        s, b, _ = get(self.port, "/api/history?limit=50")
        got = {r["protocol"] for r in json.loads(b)["runs"] if r["seed"] == 11 and r["n"] == 40}
        self.assertEqual(got, set(core.PROTOCOL_NAMES))               # all six runs are in the database

    def test_summary_is_logged_with_layout(self):
        get(self.port, "/api/summary?protocol=LEACH&seed=12&n=40")
        row = [r for r in json.loads(get(self.port, "/api/history?limit=50&protocol=LEACH")[1])["runs"] if r["seed"] == 12][0]
        self.assertEqual(row["layout"], "random")
        self.assertIsNotNone(row["fnd"])

    def test_client_disconnect_is_silent(self):
        """A browser that refreshes mid-request (WinError 10053 / reset / broken pipe) must not print a traceback."""
        old, buf = sys.stderr, io.StringIO()
        sys.stderr = buf
        try:
            for _ in range(5):
                c = socket.create_connection(("127.0.0.1", self.port))
                c.sendall(b"GET /api/compare?seed=21&n=60 HTTP/1.1\r\nHost: x\r\n\r\n")
                c.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))   # close with RST
                c.close()
            time.sleep(1.5)
            for exc in (ConnectionAbortedError(10053, "aborted"), ConnectionResetError(), BrokenPipeError()):
                try:
                    raise exc
                except Exception:
                    self.srv.handle_error(None, ("127.0.0.1", 0))
        finally:
            sys.stderr = old
        self.assertNotIn("Traceback", buf.getvalue())
        self.assertEqual(get(self.port, "/api/health")[0], 200)          # still alive
        old, buf = sys.stderr, io.StringIO()
        sys.stderr = buf
        try:
            try:
                raise ValueError("a real bug")
            except ValueError:
                self.srv.handle_error(None, ("127.0.0.1", 0))
        finally:
            sys.stderr = old
        self.assertIn("a real bug", buf.getvalue())                      # real errors are NOT hidden

    def test_errors_do_not_crash_server(self):
        for path, code in (("/api/state?protocol=BAD", 400), ("/api/state?n=abc", 400), ("/api/state?seed=-5", 400),
                           ("/api/nope", 404), ("/not-a-page", 404), ("/../../etc/passwd", 404)):
            s, b, _ = get(self.port, path)
            self.assertEqual(s, code, path)
        s, _, _ = get(self.port, "/api/health"); self.assertEqual(s, 200)     # still alive

    @unittest.skipUnless(shutil.which("node"), "Node.js not installed")
    def test_dashboard_javascript_with_fake_dom(self):
        r = subprocess.run(["node", os.path.join(HERE, "js_smoke.js"), str(self.port)], capture_output=True, text=True, timeout=120)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)
        self.assertIn("JS SMOKE OK", r.stdout)


class FlowTests(unittest.TestCase):
    @unittest.skipUnless(os.path.exists(os.path.join(ROOT, "node-red", "flow.json")), "flow not built yet")
    def test_flow_structure_and_function_nodes(self):
        r = subprocess.run([sys.executable, os.path.join(ROOT, "node-red", "check_flow.py")], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stdout + r.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
