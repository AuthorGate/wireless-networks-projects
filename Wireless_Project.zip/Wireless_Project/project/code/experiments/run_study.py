"""Main study: canopy density x wind (fire + radio) on grids with random layouts.

Usage:  python3 -I experiments/run_study.py [out.csv]
Each seed draws its own forest, node jitter, link dropouts and foliage fading, so seeds are real
replicates. Metrics are computed from the unmodified Engine loop plus the network's routing state.
"""
import sys, csv, time, os
from multiprocessing import Pool
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CANOPY = {"open": 0.0, "sparse": 100.0, "medium": 300.0, "dense": 600.0}
# name -> (wind km/h for the fire, radio fading on?)
WIND = {"calm": (0, False), "w20_fire": (20, False), "w20_fire+radio": (20, True),
        "w40_fire": (40, False), "w40_fire+radio": (40, True)}

def one(a):
    size, theta, seed, canopy, wind = a[:5]
    ov = a[5] if len(a) > 5 else {}
    sys.path.insert(0, ROOT)
    from sim.config import Config
    from sim.engine import Engine
    from sim.node import NodeState
    W, fade = WIND[wind]
    kw = dict(seed=seed, mode="ours", grid_rows=size, grid_cols=size, theta_deg=theta, speed_true=1.5,
              placement_jitter=0.1, channel_model="scene", tree_density_ha=CANOPY[canopy], radio_wind_fading=fade)
    if W > 0:
        kw.update(fire_shape="ellipse", wind_kmh=float(W))
    kw.update(ov)
    cfg = Config(**kw)
    e = Engine(cfg)
    links = sum(len(v) for v in e.net.neighbors.values()) // 2
    dt = cfg.dt
    orph = alive_s = 0.0
    hops = []
    sink_dead = None
    t = 0.0
    for _ in e.stream():
        t += dt
        if e.nodes[0].state == NodeState.DEAD:
            if sink_dead is None:
                sink_dead = t
            continue
        alive = [nd.id for nd in e.nodes if nd.state != NodeState.DEAD and nd.id != 0]
        if not alive:
            continue
        nh = e.net.next_hop
        iso = [i for i in alive if nh.get(i) is None]
        orph += len(iso) * dt
        alive_s += len(alive) * dt
        for i in alive:
            if nh.get(i) is not None:
                p = e.net.route_path(i)
                if p:
                    hops.append(len(p) - 1)
    r = e.summarize()
    return dict(grid=f"{size}x{size}", theta=theta, seed=seed, canopy=canopy, wind=wind, links=links,
                delivery=100 * r["final_delivery_rate"], orphan_frac=(orph / alive_s) if alive_s else 0.0,
                mean_hops=float(np.mean(hops)) if hops else 0.0, false_pos=r["false_positives"],
                confirmed=r["confirmed_deaths"], dir_err=r["final_dir_err_deg"], speed_err=r["final_speed_err_pct"],
                eta_err=r["final_arrival_err_s"], sink_dead=int(sink_dead is not None))

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "study_raw.csv"
    jobs = [(s, th, sd, c, w) for s in (4, 6) for th in (0, 90) for sd in range(20) for c in CANOPY for w in WIND]
    print(len(jobs), "runs", flush=True); t0 = time.time()
    with Pool(os.cpu_count()) as p:
        rows = p.map(one, jobs, chunksize=8)
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
    print("done", round(time.time() - t0), "s", flush=True)
