
import numpy as np
import csv
from pathlib import Path

# Read current propagation calculations directly, without intermediate files.
import runpy
BASE_DIR = Path(__file__).resolve().parent
RESULTS = BASE_DIR / "results"
RESULTS.mkdir(exist_ok=True)
_los = runpy.run_path(str(BASE_DIR / "01_validate_los.py"))
LOS_LOSS_DB = -10 * np.log10(_los["absorbed_path_power"](_los["paths"]))
_reflection = runpy.run_path(str(BASE_DIR / "04_room_reflection.py"),
                             init_globals={"CALCULATE_ONLY": True})
if _reflection["num_reflections"] == 0:
    raise RuntimeError("No reflection is available for the link-budget comparison")
REFLECTION_LOSS_DB = _reflection["reflected_loss"]

# Assumed link parameters
TX_POWER_DBM = 10.0
BANDWIDTH_HZ = 1e9
NOISE_FIGURE_DB = 7.0

# Thermal noise approximation at 290 K
NOISE_POWER_DBM = (
    -174
    + 10 * np.log10(BANDWIDTH_HZ)
    + NOISE_FIGURE_DB
)

results = []

for name, path_loss in [
    ("Clear LoS", LOS_LOSS_DB),
    ("Blocked LoS with Reflection", REFLECTION_LOSS_DB)
]:
    received_power = TX_POWER_DBM - path_loss
    snr_db = received_power - NOISE_POWER_DBM

    snr_linear = 10 ** (snr_db / 10)
    capacity_gbps = (
        BANDWIDTH_HZ * np.log2(1 + snr_linear) / 1e9
    )

    results.append({
        "Scenario": name,
        "Path Loss (dB)": round(path_loss, 4),
        "Received Power (dBm)": round(received_power, 4),
        "SNR (dB)": round(snr_db, 4),
        "Shannon Capacity (Gbps)": round(capacity_gbps, 6)
    })

    print(f"\nScenario: {name}")
    print(f"Path Loss: {path_loss:.4f} dB")
    print(f"Received Power: {received_power:.4f} dBm")
    print(f"SNR: {snr_db:.4f} dB")
    print(f"Theoretical Capacity: {capacity_gbps:.6f} Gbps")

# Save the results
RESULTS.mkdir(exist_ok=True)

with open(
    RESULTS / "link_budget_comparison.csv",
    "w",
    newline=""
) as file:
    writer = csv.DictWriter(
        file,
        fieldnames=results[0].keys()
    )
    writer.writeheader()
    writer.writerows(results)

print("\nLink budget results saved successfully!")
