"""Traffic-aware AP sleep advisory scheduler.

The scheduler is deliberately advisory: it never disables a radio. A site
operator must first confirm client migration and then perform any radio
state change using the router's supported management mechanism.
"""

from __future__ import annotations

import csv
import json
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Any

REQUIRED_COLUMNS = {
    "timestamp",
    "ap_id",
    "clients",
    "traffic_mbps",
    "channel_load_pct",
    "critical_clients",
    "best_backup_rssi_dbm",
    "backup_ap_id",
    "backup_base_load_pct",
    "backup_increment_pct",
}


@dataclass(frozen=True)
class SchedulerConfig:
    interval_minutes: int = 15
    low_traffic_mbps: float = 2.0
    wake_traffic_mbps: float = 5.0
    low_channel_load_pct: float = 15.0
    wake_channel_load_pct: float = 35.0
    min_consecutive_low_windows: int = 3
    min_backup_rssi_dbm: int = -67
    max_projected_backup_load_pct: float = 70.0
    minimum_active_aps: int = 1
    active_power_w: float = 5.64
    radio_sleep_power_w: float = 5.42

    @classmethod
    def from_json(cls, path: str | Path) -> "SchedulerConfig":
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        known = {k: data[k] for k in cls.__dataclass_fields__ if k in data}
        return cls(**known)

    def validate(self) -> None:
        if self.interval_minutes <= 0:
            raise ValueError("interval_minutes must be positive")
        if self.min_consecutive_low_windows < 1:
            raise ValueError("min_consecutive_low_windows must be at least 1")
        if self.minimum_active_aps < 1:
            raise ValueError("minimum_active_aps must be at least 1")
        if self.active_power_w < 0 or self.radio_sleep_power_w < 0:
            raise ValueError("Power values cannot be negative")
        if self.radio_sleep_power_w > self.active_power_w:
            raise ValueError("radio_sleep_power_w cannot exceed active_power_w")
        if self.low_traffic_mbps < 0 or self.wake_traffic_mbps < 0:
            raise ValueError("Traffic thresholds cannot be negative")
        if self.low_traffic_mbps >= self.wake_traffic_mbps:
            raise ValueError("low_traffic_mbps must be below wake_traffic_mbps")
        if self.low_channel_load_pct >= self.wake_channel_load_pct:
            raise ValueError("low_channel_load_pct must be below wake_channel_load_pct")
        if not -120 <= self.min_backup_rssi_dbm <= 0:
            raise ValueError("min_backup_rssi_dbm must be in [-120, 0] dBm")
        for name in ("low_channel_load_pct", "wake_channel_load_pct", "max_projected_backup_load_pct"):
            value = getattr(self, name)
            if not 0 <= value <= 100:
                raise ValueError(f"{name} must be between 0 and 100")


def _as_float(row: dict[str, str], key: str) -> float:
    try:
        value = float(row[key])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"Invalid numeric value for {key!r}: {row.get(key)!r}") from exc
    if not (value == value and abs(value) != float("inf")):
        raise ValueError(f"Non-finite numeric value for {key!r}")
    return value


def load_trace(path: str | Path) -> list[dict[str, Any]]:
    """Load and validate AP telemetry from a CSV file."""
    with Path(path).open("r", newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        columns = set(reader.fieldnames or [])
        missing = REQUIRED_COLUMNS - columns
        if missing:
            raise ValueError("CSV is missing required columns: " + ", ".join(sorted(missing)))
        rows: list[dict[str, Any]] = []
        for line_no, raw in enumerate(reader, start=2):
            try:
                timestamp = datetime.fromisoformat(raw["timestamp"])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"Invalid ISO timestamp on CSV line {line_no}") from exc
            clients_value = _as_float(raw, "clients")
            critical_value = _as_float(raw, "critical_clients")
            if not clients_value.is_integer() or not critical_value.is_integer():
                raise ValueError(f"Client counts must be whole numbers on CSV line {line_no}")
            row: dict[str, Any] = {
                "timestamp": timestamp.isoformat(sep=" "),
                "ap_id": raw["ap_id"].strip(),
                "clients": int(clients_value),
                "traffic_mbps": _as_float(raw, "traffic_mbps"),
                "channel_load_pct": _as_float(raw, "channel_load_pct"),
                "critical_clients": int(critical_value),
                "best_backup_rssi_dbm": _as_float(raw, "best_backup_rssi_dbm"),
                "backup_ap_id": raw["backup_ap_id"].strip(),
                "backup_base_load_pct": _as_float(raw, "backup_base_load_pct"),
                "backup_increment_pct": _as_float(raw, "backup_increment_pct"),
            }
            if not row["ap_id"]:
                raise ValueError(f"Empty ap_id on CSV line {line_no}")
            if row["clients"] < 0 or row["critical_clients"] < 0:
                raise ValueError(f"Negative client count on CSV line {line_no}")
            if row["critical_clients"] > row["clients"]:
                raise ValueError(f"critical_clients exceeds clients on CSV line {line_no}")
            if row["traffic_mbps"] < 0 or row["backup_increment_pct"] < 0:
                raise ValueError(f"Negative traffic or load increment on CSV line {line_no}")
            for key in ("channel_load_pct", "backup_base_load_pct"):
                if not 0 <= row[key] <= 100:
                    raise ValueError(f"{key} must be in [0, 100] on CSV line {line_no}")
            if not -120 <= row["best_backup_rssi_dbm"] <= 0:
                raise ValueError(f"best_backup_rssi_dbm must be in [-120, 0] on CSV line {line_no}")
            rows.append(row)
    if not rows:
        raise ValueError("The input CSV contains no telemetry rows")
    return rows


def evaluate(rows: list[dict[str, Any]], config: SchedulerConfig) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Evaluate a sequence of fixed-duration snapshots.

    Low demand must persist for N consecutive windows. An AP may be advised
    for radio sleep only if critical devices are absent, the weakest client's
    best alternate RSSI meets the configured threshold, and the projected
    target-AP channel load remains within its limit.
    """
    config.validate()
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["timestamp"]].append(row)

    timestamps = sorted(grouped)
    ap_ids = sorted({row["ap_id"] for row in rows})
    known_aps = set(ap_ids)
    for row in rows:
        backup = row["backup_ap_id"]
        if backup and (backup not in known_aps or backup == row["ap_id"]):
            raise ValueError(
                f"Invalid backup_ap_id {backup!r} for {row['ap_id']!r}; "
                "backup must identify a different AP present in the trace"
            )

    low_counts = {ap_id: 0 for ap_id in ap_ids}
    decisions: list[dict[str, Any]] = []
    previous_timestamp: datetime | None = None

    for timestamp in timestamps:
        current_timestamp = datetime.fromisoformat(timestamp)
        if previous_timestamp is not None:
            elapsed = (current_timestamp - previous_timestamp).total_seconds() / 60.0
            if elapsed != config.interval_minutes:
                # Missing, duplicated, or irregular windows must not be treated
                # as consecutive low-demand observations.
                low_counts = {ap_id: 0 for ap_id in ap_ids}
        previous_timestamp = current_timestamp
        window = grouped[timestamp]
        by_ap = {r["ap_id"]: r for r in window}
        if len(by_ap) != len(window):
            raise ValueError(f"Duplicate AP rows at timestamp {timestamp}")
        if set(by_ap) != set(ap_ids):
            raise ValueError(f"Every timestamp must contain the same AP set; issue at {timestamp}")

        eligible: list[dict[str, Any]] = []
        wake_reason: dict[str, str] = {}
        for ap_id in ap_ids:
            r = by_ap[ap_id]
            reasons = []
            if r["critical_clients"] > 0:
                reasons.append("protected client is connected")
            if r["traffic_mbps"] >= config.wake_traffic_mbps:
                reasons.append("traffic reached wake threshold")
            if r["channel_load_pct"] >= config.wake_channel_load_pct:
                reasons.append("channel load reached wake threshold")
            if r["clients"] > 0 and r["best_backup_rssi_dbm"] < config.min_backup_rssi_dbm:
                reasons.append("backup signal is insufficient")
            if r["clients"] > 0 and not r["backup_ap_id"]:
                reasons.append("no alternate AP is defined")
            if reasons:
                low_counts[ap_id] = 0
                wake_reason[ap_id] = "; ".join(reasons)
                continue

            low_now = (
                r["traffic_mbps"] <= config.low_traffic_mbps
                and r["channel_load_pct"] <= config.low_channel_load_pct
            )
            low_counts[ap_id] = low_counts[ap_id] + 1 if low_now else 0
            if low_counts[ap_id] >= config.min_consecutive_low_windows:
                eligible.append(r)

        # Candidate order is conservative: lower traffic is considered first.
        eligible.sort(key=lambda item: (item["traffic_mbps"], item["channel_load_pct"], item["ap_id"]))
        selected_sleep: set[str] = set()
        predicted_load: dict[str, float] = {}

        for candidate in eligible:
            currently_available = len(ap_ids) - len(selected_sleep)
            if currently_available <= config.minimum_active_aps:
                wake_reason[candidate["ap_id"]] = "minimum active AP floor would be violated"
                continue

            # Never recommend sleeping an AP that another still-connected AP
            # currently depends on as its declared backup target. This guard
            # is deliberately conservative and avoids order-dependent plans.
            depended_on = any(
                other["ap_id"] != candidate["ap_id"]
                and other["clients"] > 0
                and other["backup_ap_id"] == candidate["ap_id"]
                for other in window
            )
            if depended_on:
                wake_reason[candidate["ap_id"]] = (
                    "another AP currently depends on this AP as its backup target"
                )
                continue

            target = candidate["backup_ap_id"]
            if target and (target in selected_sleep):
                wake_reason[candidate["ap_id"]] = "selected backup AP is also scheduled to sleep"
                continue
            if target:
                base = predicted_load.get(target, candidate["backup_base_load_pct"])
                projected = base + candidate["backup_increment_pct"]
                if projected > config.max_projected_backup_load_pct:
                    wake_reason[candidate["ap_id"]] = (
                        f"backup AP {target} would reach {projected:.1f}% load "
                        f"(limit {config.max_projected_backup_load_pct:.1f}%)"
                    )
                    continue
                predicted_load[target] = projected
            selected_sleep.add(candidate["ap_id"])

        for ap_id in ap_ids:
            r = by_ap[ap_id]
            sleeping = ap_id in selected_sleep
            if sleeping:
                action = "SLEEP_RECOMMENDED"
                reason = (
                    f"low demand persisted for {low_counts[ap_id]} windows; "
                    "backup coverage and capacity checks passed"
                )
            elif ap_id in wake_reason:
                action = "KEEP_ON"
                reason = wake_reason[ap_id]
            elif low_counts[ap_id] < config.min_consecutive_low_windows:
                action = "KEEP_ON"
                reason = f"waiting for stable low demand ({low_counts[ap_id]}/{config.min_consecutive_low_windows})"
            else:
                action = "KEEP_ON"
                reason = "no safe sleep decision was selected"

            decisions.append({
                "timestamp": timestamp,
                "ap_id": ap_id,
                "clients": r["clients"],
                "traffic_mbps": round(r["traffic_mbps"], 3),
                "channel_load_pct": round(r["channel_load_pct"], 2),
                "critical_clients": r["critical_clients"],
                "backup_ap_id": r["backup_ap_id"],
                "action": action,
                "reason": reason,
                "energy_power_w": config.radio_sleep_power_w if sleeping else config.active_power_w,
                "operator_guard": "Do not disable radio until associated clients have migrated and live checks pass" if sleeping else "No action required",
            })

    interval_h = Decimal(config.interval_minutes) / Decimal(60)
    active_power = Decimal(str(config.active_power_w))
    radio_off_power = Decimal(str(config.radio_sleep_power_w))
    sleep_count = sum(d["action"] == "SLEEP_RECOMMENDED" for d in decisions)
    baseline_wh = len(decisions) * active_power * interval_h
    proposed_wh = (
        (len(decisions) - sleep_count) * active_power + sleep_count * radio_off_power
    ) * interval_h
    saved_wh = baseline_wh - proposed_wh
    saving_pct = (Decimal(100) * saved_wh / baseline_wh) if baseline_wh else Decimal(0)

    def rounded(value: Decimal, places: str) -> float:
        return float(value.quantize(Decimal(places), rounding=ROUND_HALF_UP))

    summary = {
        "windows": len(timestamps),
        "access_points": len(ap_ids),
        "interval_minutes": config.interval_minutes,
        "baseline_energy_wh": rounded(baseline_wh, "0.001"),
        "proposed_energy_wh": rounded(proposed_wh, "0.001"),
        "estimated_energy_saved_wh": rounded(saved_wh, "0.001"),
        "estimated_saving_percent": rounded(saving_pct, "0.01"),
        "sleep_recommendations": sum(d["action"] == "SLEEP_RECOMMENDED" for d in decisions),
        "active_power_w_assumption": config.active_power_w,
        "radio_sleep_power_w_assumption": config.radio_sleep_power_w,
        "measurement_status": "Modeled scenario using synthetic telemetry and published AP reference powers; no site measurements",
    }
    return decisions, summary


def write_outputs(decisions: list[dict[str, Any]], summary: dict[str, Any], out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / "decisions.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(decisions[0].keys()))
        writer.writeheader()
        writer.writerows(decisions)
    (out / "summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    lines = [
        "# Traffic-aware Green Wi-Fi evaluation",
        "",
        "> IMPORTANT: This run uses the supplied trace and configured power assumptions. It is not a field measurement.",
        "",
        f"- Time windows: {summary['windows']}",
        f"- Access points: {summary['access_points']}",
        f"- Baseline estimated energy: {summary['baseline_energy_wh']:.3f} Wh",
        f"- Proposed estimated energy: {summary['proposed_energy_wh']:.3f} Wh",
        f"- Estimated energy saved: {summary['estimated_energy_saved_wh']:.3f} Wh ({summary['estimated_saving_percent']:.2f}%)",
        f"- Sleep recommendations: {summary['sleep_recommendations']}",
        "",
        "## Decisions",
        "",
        "| Time | AP | Action | Reason |",
        "|---|---|---|---|",
    ]
    for d in decisions:
        lines.append(f"| {d['timestamp']} | {d['ap_id']} | {d['action']} | {d['reason']} |")
    lines += [
        "",
        "## Safety note",
        "",
        "The software is advisory-only. It does not switch off an AP. Any real radio shutdown requires a controlled maintenance window, verified client migration, a protected-device check, a minimum-coverage check, and an operator-approved rollback plan.",
    ]
    (out / "report.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
