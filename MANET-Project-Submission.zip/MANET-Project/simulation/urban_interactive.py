import json
import plotly.graph_objects as go
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

with open(ROOT / "results/urban_mobility.json") as f:
    data = json.load(f)

buildings = data["buildings"]
snapshots = data["snapshots"]

fig = go.Figure()

colors = [
    "#64748b",
    "#475569",
    "#94a3b8",
    "#78716c",
    "#71717a",
    "#52525b"
]

index = 0

for building in buildings:

    if building["name"] == "floor":
        continue

    x0, y0, z0 = building["min"]
    x1, y1, z1 = building["max"]

    fig.add_trace(go.Mesh3d(
        x=[x0, x1, x1, x0, x0, x1, x1, x0],
        y=[y0, y0, y1, y1, y0, y0, y1, y1],
        z=[z0, z0, z0, z0, z1, z1, z1, z1],

        i=[0, 0, 4, 4, 0, 0, 1, 1, 2, 2, 3, 3],
        j=[1, 2, 5, 6, 1, 5, 2, 6, 3, 7, 0, 4],
        k=[2, 3, 6, 7, 5, 4, 6, 5, 7, 6, 4, 7],

        color=colors[index % len(colors)],
        opacity=0.45,
        name=building["name"],
        hoverinfo="name",
        showlegend=False,
        flatshading=True
    ))

    index += 1


def network_traces(snapshot):

    nodes = snapshot["nodes"]
    links = snapshot["links"]

    positions = {
        node["id"]: node
        for node in nodes
    }

    x = []
    y = []
    z = []

    for link in links:

        a = positions[link["source"]]
        b = positions[link["target"]]

        x.extend([a["x"], b["x"], None])
        y.extend([a["y"], b["y"], None])
        z.extend([a["z"], b["z"], None])

    link_trace = go.Scatter3d(
        x=x,
        y=y,
        z=z,
        mode="lines",
        line=dict(color="#22c55e", width=4),
        name="Wireless Links",
        hoverinfo="skip"
    )

    isolated = snapshot["statistics"]["isolated_nodes"]

    node_trace = go.Scatter3d(
        x=[n["x"] for n in nodes],
        y=[n["y"] for n in nodes],
        z=[n["z"] for n in nodes],

        text=[n["id"] for n in nodes],
        ids=[n["id"] for n in nodes],

        mode="markers+text",
        textposition="top center",

        marker=dict(
            size=7,
            color=[
                "red" if n["id"] in isolated
                else "#38bdf8"
                for n in nodes
            ],
            line=dict(color="white", width=1)
        ),

        name="Mobile Nodes"
    )

    return [link_trace, node_trace]


def frame_title(snapshot):

    return (
        "MANET 3D Urban Simulation"
        f" | Time: {snapshot['time']} s"
        f" | Links: {len(snapshot['links'])}"
    )


first_trace = len(fig.data)

for trace in network_traces(snapshots[0]):
    fig.add_trace(trace)

fig.frames = [

    go.Frame(
        name=str(snapshot["time"]),

        data=network_traces(snapshot),

        traces=[
            first_trace,
            first_trace + 1
        ],

        layout=go.Layout(
            title_text=frame_title(snapshot)
        )
    )

    for snapshot in snapshots
]

slider_steps = []

for snapshot in snapshots:

    slider_steps.append(dict(
        label=f"{snapshot['time']} s",
        method="animate",
        args=[
            [str(snapshot["time"])],
            {
                "mode": "immediate",
                "frame": {
                    "duration": 0,
                    "redraw": True
                },
                "transition": {"duration": 0}
            }
        ]
    ))

fig.update_layout(

    title=frame_title(snapshots[0]),

    template="plotly_dark",

    paper_bgcolor="#0b1120",

    scene=dict(

        xaxis=dict(
            title="X (m)",
            range=[-95, 95]
        ),

        yaxis=dict(
            title="Y (m)",
            range=[-62, 62]
        ),

        zaxis=dict(
            title="Z (m)",
            range=[0, 55]
        ),

        aspectmode="data",

        camera=dict(
            eye=dict(x=1.5, y=-1.8, z=1.3)
        ),

        uirevision="urban"
    ),

    updatemenus=[dict(

        type="buttons",
        direction="left",
        x=0.1,
        y=0,

        buttons=[

            dict(
                label="Play",
                method="animate",
                args=[
                    None,
                    {
                        "frame": {
                            "duration": 1000,
                            "redraw": True
                        },
                        "transition": {"duration": 0},
                        "fromcurrent": True
                    }
                ]
            ),

            dict(
                label="Pause",
                method="animate",
                args=[
                    [None],
                    {
                        "mode": "immediate",
                        "frame": {
                            "duration": 0,
                            "redraw": True
                        },
                        "transition": {"duration": 0}
                    }
                ]
            )
        ]
    )],

    sliders=[dict(
        active=0,
        currentvalue={"prefix": "Time: "},
        steps=slider_steps
    )],

    margin=dict(l=0, r=0, t=65, b=80)
)

fig.write_html(
    str(ROOT / "figures/urban_interactive.html"),
    include_plotlyjs=True,
    auto_play=False
)

print("Interactive 3D Simulation Created")
print("Saved: figures/urban_interactive.html")