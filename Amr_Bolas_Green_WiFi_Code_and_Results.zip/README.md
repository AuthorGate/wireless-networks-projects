# Traffic-Aware Energy-Efficient Wi-Fi Network Management

**Course project code and reproducibility package**  
**Author:** Amr Bolas  
**Affiliation:** An-Najah National University, Nablus, Palestine  
**Contact:** s12218389@stu.najah.edu

This archive contains the companion implementation, reproducible scenario inputs, generated analysis results, plots, tests, and documentation. The final IEEE tutorial report is submitted separately as a PDF.

## Project summary

The prototype is an advisory decision layer inspired by OpenWrt's `wifischedule` package. It evaluates whether an access point (AP) could be considered for a lower-power state during sustained low demand, while applying safeguards for protected clients, alternate-AP signal, projected backup capacity, AP dependencies, minimum active AP count, and sudden traffic or channel-load increases.

The prototype **does not control routers or turn off Wi-Fi radios**. It outputs recommendations for review. Scenario input data are synthetic and represent a plausible late-evening university or institutional setting in Nablus, Palestine. No field measurements or site-specific energy savings are claimed.

## Selected upstream repository and pinned version

- Repository: <https://github.com/openwrt/packages>
- Selected package: `net/wifischedule`
- Commit: `1ac54403af4a7b0f2743e92bbe7f2c5fe17a61df`
- Detailed version record and checkout commands: [`docs/REPOSITORY_VERSION.md`](docs/REPOSITORY_VERSION.md)

The companion Python decision layer is separate from the upstream package and does not modify it.

## Requirements

- Python 3.10 or newer
- Dependencies listed in `requirements.txt` (Matplotlib is used for plotting)
- Git is only needed if you want to check out the pinned upstream repository

## Reproduce the analysis

From the root of this extracted archive, create and activate a virtual environment, then run:

```bash
python -m venv .venv
```

On Linux/macOS:

```bash
source .venv/bin/activate
```

On Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Install dependencies and run the tests and analysis:

```bash
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Linux/macOS:

```bash
export PYTHONPATH=src
python -m unittest discover -s tests -v
python -m greenwifi.cli --input data/demo_trace.csv --config config/config.json --out results
python scripts/run_sensitivity.py
python scripts/plot_results.py
```

Windows PowerShell:

```powershell
$env:PYTHONPATH = "src"
python -m unittest discover -s tests -v
python -m greenwifi.cli --input data/demo_trace.csv --config config/config.json --out results
python scripts/run_sensitivity.py
python scripts/plot_results.py
```

The commands write the decision output, summary, sensitivity analysis, and plot into `results/`.

## Included results

The bundled primary scenario contains 3 APs and 9 fifteen-minute windows:

- Always-on reference energy: **38.070 Wh**
- Modeled policy energy: **37.685 Wh**
- Scenario difference: **0.385 Wh (1.01%)**
- Sleep recommendations: **7 AP-windows**, with at least two APs kept active

A sensitivity run with the Aruba AP-505 reference power pair gives **3.045 Wh (7.96%)** for the same synthetic trace. These are scenario calculations based on the documented reference values, not measured results for a Nablus site. See [`docs/scenario_assumptions.md`](docs/scenario_assumptions.md) and [`docs/TEST_RESULTS.md`](docs/TEST_RESULTS.md) for assumptions and recorded verification.

The generated energy-comparison plot is [`results/energy_comparison.png`](results/energy_comparison.png). Machine-readable outputs are also included as CSV and JSON files.

## Project structure

```text
config/       Policy thresholds and safeguards
data/         Synthetic demo telemetry trace
docs/         English repository, scenario, measurement, and test documentation
results/      Generated decisions, summaries, sensitivity results, and plot
scripts/      Optional telemetry collection and analysis utilities
src/          Python decision-layer implementation
 tests/       Unit tests
```

## Safety and limitations

A `SLEEP_RECOMMENDED` output is a planning recommendation, not proof that disabling an AP is safe. The software contains no automatic router configuration or radio shutdown commands. Any real deployment would require site authorization, locally collected measurements, coverage and capacity checks, protected-device checks, a maintenance window, and a tested rollback plan. The procedure and input-data definitions are documented in [`docs/measurement_protocol.md`](docs/measurement_protocol.md).

## License

The companion code in this project is released under the MIT License. OpenWrt `wifischedule` is a separate upstream project and retains its own license and notices.

