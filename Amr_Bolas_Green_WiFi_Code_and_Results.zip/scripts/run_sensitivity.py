"""Compare published AP idle/standby reference powers on the same trace."""

from __future__ import annotations

import csv
from dataclasses import replace
from pathlib import Path

from greenwifi.scheduler import SchedulerConfig, evaluate, load_trace

ROOT = Path(__file__).resolve().parents[1]
TRACE = ROOT / "data" / "demo_trace.csv"
CONFIG = ROOT / "config" / "config.json"
OUT = ROOT / "results" / "sensitivity.csv"

REFERENCE_MODELS = (
    ("Ruckus H550", 5.64, 5.42),
    ("Aruba AP-505", 5.67, 3.93),
)


def main() -> None:
    rows = load_trace(TRACE)
    base_config = SchedulerConfig.from_json(CONFIG)
    fields = [
        "reference_ap",
        "active_power_w",
        "radio_off_power_w",
        "baseline_energy_wh",
        "policy_energy_wh",
        "estimated_energy_saved_wh",
        "estimated_saving_percent",
        "sleep_recommendations",
    ]
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for model, active_power, radio_off_power in REFERENCE_MODELS:
            config = replace(
                base_config,
                active_power_w=active_power,
                radio_sleep_power_w=radio_off_power,
            )
            _, summary = evaluate(rows, config)
            writer.writerow(
                {
                    "reference_ap": model,
                    "active_power_w": active_power,
                    "radio_off_power_w": radio_off_power,
                    "baseline_energy_wh": summary["baseline_energy_wh"],
                    "policy_energy_wh": summary["proposed_energy_wh"],
                    "estimated_energy_saved_wh": summary["estimated_energy_saved_wh"],
                    "estimated_saving_percent": summary["estimated_saving_percent"],
                    "sleep_recommendations": summary["sleep_recommendations"],
                }
            )
    print(f"Sensitivity results written to {OUT}")


if __name__ == "__main__":
    main()
