
import time
import random
import json
import paho.mqtt.client as mqtt

BROKER = "localhost"
PORT = 1883
TOPIC = "iot/temperature"

client = mqtt.Client(
    callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
    client_id="temperature_sensor"
)

def on_connect(client, userdata, flags, reason_code, properties):
    if reason_code == 0:
        print("Connected to MQTT Broker!")
    else:
        print("Connection failed:", reason_code)

client.on_connect = on_connect

try:
    client.connect(BROKER, PORT, 60)
    client.loop_start()

    for i in range(1, 21):
        temperature = round(random.uniform(20, 35), 2)

        message = {
            "id": i,
            "temperature": temperature
        }

        client.publish(TOPIC, json.dumps(message), qos=1)

        print(f"Sending message {i}: {message}")

        time.sleep(2)

except KeyboardInterrupt:
    print("Publisher stopped.")

except OSError as e:
    print("Cannot connect to MQTT Broker:", e)

finally:
    client.loop_stop()
    client.disconnect()
