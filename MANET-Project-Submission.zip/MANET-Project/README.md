# Clustering and Scalability in Mobile Ad Hoc Networks

## About the Project

This project studies clustering and routing problems
in mobile ad hoc networks (MANETs).

The main problem is that network links and clusters
change when nodes move.

The proposed solution is called SAAC.
It uses signal quality, node degree, and link
stability to select cluster heads.

## Tools

- Python
- Linux
- Sionna RT
- Mesh Network Lab
- NetworkX
- Matplotlib
- Plotly
- Pandas

## Project Folders

- simulation: Network and 3D simulation.
- algorithms: Clustering and routing code.
- experiments: Network tests.
- results: Test results.
- figures: Images, graphs and 3D views.
- meshnet-lab: Network emulator.

## Installation

Install the required Linux packages:

```bash
sudo apt update
sudo apt install python3 python3-venv python3-pip git iproute2 iputils-ping babeld
```

Create a Python environment:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run the Project

Test Sionna RT:

```bash
python simulation/test_sionna.py
```

Run the 3D network simulation:

```bash
python simulation/urban_mobility.py
python algorithms/urban_clustering.py
```

Create the 3D views:

```bash
python simulation/urban_interactive.py
python simulation/urban_clustering_3d.py
```

Create the signal coverage maps:

```bash
python simulation/urban_heatmap.py
```

Analyze the scalability results:

```bash
python experiments/clustering_scalability.py
```

Create the routing graphs:

```bash
python experiments/plot_routing_results.py
```

## Routing Test

```bash
python experiments/export_meshnet.py
python algorithms/routing_backbone.py
sudo .venv/bin/python experiments/routing_comparison.py --repeats 5
```

Run this test in a dedicated Linux test environment.
It clears the Mesh Network Lab network before testing
and replaces the saved routing results.

## Results

The clustering algorithm was tested using networks
from 9 to 200 nodes.

In the nine-node urban network, SAAC achieved:

- 92.31% fewer cluster head changes.
- 94.44% fewer cluster membership changes.
- 71.43% fewer routing updates.
- 94.44% packet delivery after movement.

## Limitations

The project uses simulation and virtual networks.
The routing method is centralized.

The results are not from real wireless devices.

## Reference

https://github.com/mwarning/meshnet-lab
## Larger Network Routing Experiments

Additional routing experiments were performed
using 25-node and 50-node free-space networks.

Four routing methods were evaluated:

- Babel routing
- Full-graph routing
- Traditional cluster-based routing
- SAAC-based routing

Each method was tested once for each network
size using random seed 42.

## Development Environment

- Ubuntu Linux (WSL2)
- Python 3.14.4
- Sionna RT 2.2.0
- NetworkX
- Matplotlib
- Plotly
- Mesh Network Lab

## Experiment Summary

- 25 clustering scenarios
- Network sizes: 9, 25, 50, 100, and 200 nodes
- 16 urban mobility snapshots
- 20 urban routing experiments
- 8 larger-network routing experiments
- 28 routing experiments in total

The results, figures, and experiment logs
are included in the project.

The routing experiments use virtual Linux
networks rather than physical wireless devices.

## Run Larger Network Routing Tests

Prepare the 25-node and 50-node networks:

```bash
python experiments/prepare_large_routing.py
```

Run the 25-node routing experiment:

```bash
sudo .venv/bin/python experiments/large_routing_comparison.py --nodes 25 --repeats 1
```

Run the 50-node routing experiment:

```bash
sudo .venv/bin/python experiments/large_routing_comparison.py --nodes 50 --repeats 1
```

The results are stored in:

- results/large_routing/25/
- results/large_routing/50/

Completed experiments are skipped when running again.
Run routing tests in a dedicated Linux test environment.
The tests clear the Mesh Network Lab virtual network.

