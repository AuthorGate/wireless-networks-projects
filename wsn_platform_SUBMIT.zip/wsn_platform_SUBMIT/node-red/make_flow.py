"""
make_flow.py -- generates node-red/flow.json  (run:  python node-red/make_flow.py)

Only CORE Node-RED nodes are used (http in/request/response, template, function, inject, catch, debug, comment).

  Flow 1 (optional)  serves the dashboard at /wsn and forwards /wsn/api/* to the Python engine (default port 8000).
  Flow 2             controls the dashboard's LIVE mode:  a 2-second tick calls POST /api/live/step (the engine advances
                     its simulated clock), a rule picks the tank alerts that are NEW, and POST /api/notify sends them to the
                     engine, which shows them on the dashboard.  Four 'START live' buttons begin a session with a protocol.
"""
import json, os

HERE = os.path.dirname(os.path.abspath(__file__))
html = open(os.path.join(HERE, "..", "dashboard", "index.html"), encoding="utf-8").read()
TAB = "a1b2c3d4e5f60001"

URL_BUILDER = r'''// Forward /wsn/api/<endpoint>?<query> to the Python engine
const allowed = ["health", "config", "summary", "state", "compare", "history", "curve", "live", "notifications", "deployments", "activity"];
const ep = msg.req.params.endpoint;
if (!allowed.includes(ep)) {
    msg.statusCode = 404;
    msg.payload = { error: "unknown endpoint" };
    return [null, msg];
}
const qs = new URLSearchParams(msg.req.query).toString();
const base = env.get("ENGINE_URL") || "http://127.0.0.1:8000";
msg.url = base + "/api/" + ep + (qs ? "?" + qs : "");
return [msg, null];'''

ENGINE_DOWN = r'''// The http request node failed -> the Python engine is not running
msg.statusCode = 502;
msg.payload = { error: "The Python engine is not running. Start it with:  python engine/server.py" };
return msg;'''

PREP_STEP = r'''// Ask the engine to advance the LIVE clock. The engine owns the clock; Node-RED decides WHEN it moves.
const step = parseInt(env.get("STEP") || "5", 10);
const base = env.get("ENGINE_URL") || "http://127.0.0.1:8000";
msg.url = base + "/api/live/step?steps=" + step;
delete msg.payload;
return msg;'''

DETECT = r'''// Rule: notify only about tank alerts that were NOT present in the previous tick
const st = msg.payload;
if (!st || st.error || !Array.isArray(st.alerts)) { return null; }
if (st.paused) { node.status({ fill: "yellow", shape: "ring", text: "paused / ready" }); return null; }
const before = flow.get("alerted") || {};
const now = {};
const fresh = [];
for (const a of st.alerts) {
    const key = a.node + ":" + a.type;
    now[key] = true;
    if (!before[key]) {
        fresh.push("Tank #" + a.node + " " + a.type.toUpperCase() + " (" + a.level + " %)");
    }
}
flow.set("alerted", st.wrapped ? {} : now);      // a new demo run starts: forget old alerts
node.status({ fill: fresh.length ? "red" : "green", shape: "dot",
              text: "h" + st.round + ": " + st.alive + " alive, " + fresh.length + " new alerts" });
if (fresh.length === 0) { return null; }
msg.payload = { hour: st.round, nodes_alive: st.alive, coverage_pct: st.coverage, new_alerts: fresh };
return msg;'''

BUILD_NOTIFY = r'''// Turn the new alerts into ONE notification and send it to the engine (the dashboard shows it)
const p = msg.payload;
const text = p.new_alerts.slice(0, 3).join("; ") + (p.new_alerts.length > 3 ? " (+" + (p.new_alerts.length - 3) + " more)" : "");
const base = env.get("ENGINE_URL") || "http://127.0.0.1:8000";
msg.url = base + "/api/notify?hour=" + p.hour + "&source=node-red&text=" + encodeURIComponent(text);
msg.report = p;
delete msg.payload;
return msg;'''

PREP_PAUSE = r'''// PAUSE / RESUME buttons: tell the engine to freeze / continue the live clock, so the dashboard says PAUSED
const base = env.get("ENGINE_URL") || "http://127.0.0.1:8000";
const on = msg.topic === "pause" ? 1 : 0;
msg.url = base + "/api/live/pause?on=" + on + "&source=node-red";
node.status({ fill: on ? "yellow" : "green", shape: "ring", text: on ? "paused" : "resumed" });
delete msg.payload;
return msg;'''

PREP_RESET = r'''// A 'start live' button was clicked: start a new live session with the protocol written on the button
const base = env.get("ENGINE_URL") || "http://127.0.0.1:8000";
const protocol = msg.topic || "PEGASIS-E";
const layout = env.get("LAYOUT") || "real";
const seed = env.get("SEED") || "0";
const n = env.get("N") || "100";
msg.url = base + "/api/live/reset?protocol=" + encodeURIComponent(protocol) + "&layout=" + layout + "&seed=" + seed + "&n=" + n + "&source=node-red";
flow.set("alerted", {});
node.status({ fill: "blue", shape: "ring", text: "starting " + protocol });
delete msg.payload;
return msg;'''

DROP_HEADERS = r'''// 1) a failed request arrives here with a non-numeric statusCode (e.g. "ECONNREFUSED") -> make it a clean 502
if (typeof msg.statusCode !== "number") {
    msg.statusCode = 502;
    msg.payload = { error: "The Python engine is not reachable. Start it with:  python engine/server.py" };
}
// 2) the engine's Content-Length would be wrong after Node-RED re-serialises the JSON -> drop its headers
delete msg.headers;
return msg;'''

GUARD = r'''// Answer each browser request ONLY ONCE. A failed http request can reach this point twice
// (once via the catch node, once via the normal output); the second answer would raise ERR_HTTP_HEADERS_SENT.
const res = msg.res && msg.res._res;
if (res && (res.headersSent || res.writableEnded)) { return null; }
return msg;'''

def node(id, type, x, y, **kw):
    d = dict(id=id, type=type, z=TAB, x=x, y=y)
    d.update(kw)
    return d

nodes = [
    dict(id=TAB, type="tab", label="WSN Water-Tank Platform", disabled=False,
         info="Dashboard + API gateway for the Python engine, and a tank-alert monitor.",
         env=[dict(name="ENGINE_URL", value="http://127.0.0.1:8000", type="str"),
              dict(name="LAYOUT", value="real", type="str"),
              dict(name="SEED", value="0", type="str"),
              dict(name="N", value="100", type="str"),
              dict(name="STEP", value="5", type="str")]),

    node("c0000001", "comment", 200, 40, name="FLOW 1 (optional) - the SAME dashboard through Node-RED at http://localhost:1880/wsn. Normally use http://localhost:8000",
         info="Start the Python engine first:  python engine/server.py", wires=[]),
    node("n0000001", "http in", 130, 100, name="GET /wsn", url="/wsn", method="get", upload=False, swaggerDoc="", wires=[["n0000002"]]),
    node("n0000002", "template", 340, 100, name="Dashboard HTML", field="payload", fieldType="msg", format="html",
         syntax="plain", template=html, output="str", wires=[["n0000003"]]),
    node("n0000003", "http response", 560, 100, name="", statusCode="", headers={"Content-Type": "text/html; charset=utf-8"}, wires=[]),

    node("n0000004", "http in", 160, 180, name="GET /wsn/api/:endpoint", url="/wsn/api/:endpoint", method="get", upload=False, swaggerDoc="", wires=[["n0000005"]]),
    node("n0000005", "function", 400, 180, name="build engine URL", func=URL_BUILDER, outputs=2, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000006"], ["n0000020"]]),
    node("n0000006", "http request", 640, 180, name="Python engine", method="GET", ret="obj", paytoqs="ignore", url="",
         tls="", persist=False, proxy="", insecureHTTPParser=False, authType="", senderr=False, headers=[], wires=[["n0000019"]]),
    node("n0000007", "http response", 1290, 180, name="", statusCode="", headers={}, wires=[]),
    node("n0000019", "function", 860, 180, name="drop engine headers", func=DROP_HEADERS, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000020"]]),
    node("n0000020", "function", 1080, 180, name="answer only once", func=GUARD, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000007"]]),
    node("n0000008", "catch", 640, 250, name="engine down?", scope=["n0000006"], uncaught=False, wires=[["n0000009"]]),
    node("n0000009", "function", 860, 250, name="502 message", func=ENGINE_DOWN, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000020"]]),

    node("c0000002", "comment", 260, 320, name="FLOW 2 - Node-RED DRIVES the dashboard's LIVE mode (clock + alert rules + notifications)",
         info="Open the dashboard, choose Mode = Live. Then click one of the 'start live' buttons below.", wires=[]),
    node("n0000010", "inject", 140, 380, name="tick every 2 s", props=[dict(p="payload"), dict(p="topic", vt="str")],
         repeat="2", crontab="", once=False, onceDelay=0.1, topic="", payload="", payloadType="date", wires=[["n0000011"]]),
    node("n0000011", "function", 330, 380, name="prepare step", func=PREP_STEP, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000012"]]),
    node("n0000012", "http request", 520, 380, name="POST /api/live/step", method="POST", ret="obj", paytoqs="ignore", url="",
         tls="", persist=False, proxy="", insecureHTTPParser=False, authType="", senderr=False, headers=[], wires=[["n0000013"]]),
    node("n0000013", "function", 720, 380, name="detect NEW alerts", func=DETECT, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000014"]]),
    node("n0000014", "function", 920, 380, name="build notification", func=BUILD_NOTIFY, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000015"]]),
    node("n0000015", "http request", 1120, 380, name="POST /api/notify", method="POST", ret="obj", paytoqs="ignore", url="",
         tls="", persist=False, proxy="", insecureHTTPParser=False, authType="", senderr=False, headers=[], wires=[["n0000016"]]),
    node("n0000016", "debug", 1300, 380, name="notification sent", active=True, tosidebar=True, console=False, tostatus=False,
         complete="report", targetType="msg", statusVal="", statusType="auto", wires=[]),
    node("n0000017", "catch", 520, 440, name="engine down?", scope=["n0000012", "n0000015", "n0000026", "n0000033"], uncaught=False, wires=[["n0000018"]]),
    node("n0000018", "debug", 720, 440, name="engine unreachable", active=True, tosidebar=True, console=False, tostatus=False,
         complete="error.message", targetType="msg", statusVal="", statusType="auto", wires=[]),

    node("c0000003", "comment", 200, 520, name="Click a button to START a live session with that protocol (the dashboard follows)",
         info="Settings (layout, seed, tanks, step size) are the tab's environment variables.", wires=[]),
    node("n0000028", "inject", 170, 570, name="START live: PEGASIS-E", props=[dict(p="payload"), dict(p="topic", vt="str")], repeat="", crontab="",
         once=False, onceDelay=0.1, topic="PEGASIS-E", payload="", payloadType="date", wires=[["n0000024"]]),
    node("n0000021", "inject", 170, 620, name="START live: PEGASIS", props=[dict(p="payload"), dict(p="topic", vt="str")], repeat="", crontab="",
         once=False, onceDelay=0.1, topic="PEGASIS", payload="", payloadType="date", wires=[["n0000024"]]),
    node("n0000022", "inject", 170, 670, name="START live: LEACH", props=[dict(p="payload"), dict(p="topic", vt="str")], repeat="", crontab="",
         once=False, onceDelay=0.1, topic="LEACH", payload="", payloadType="date", wires=[["n0000024"]]),
    node("n0000023", "inject", 170, 720, name="START live: Direct", props=[dict(p="payload"), dict(p="topic", vt="str")], repeat="", crontab="",
         once=False, onceDelay=0.1, topic="Direct", payload="", payloadType="date", wires=[["n0000024"]]),
    node("n0000024", "function", 420, 640, name="prepare reset", func=PREP_RESET, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000026"]]),
    node("n0000026", "http request", 620, 640, name="POST /api/live/reset", method="POST", ret="obj", paytoqs="ignore", url="",
         tls="", persist=False, proxy="", insecureHTTPParser=False, authType="", senderr=False, headers=[], wires=[["n0000027"]]),
    node("n0000027", "debug", 840, 640, name="live session started", active=True, tosidebar=True, console=False, tostatus=False,
         complete="payload", targetType="msg", statusVal="", statusType="auto", wires=[]),
    node("c0000004", "comment", 200, 790, name="PAUSE stops the live clock (the dashboard shows PAUSED); RESUME continues; START (above) begins a new session",
         info="Pause is also kept inside the engine, so the dashboard can tell PAUSED from STOPPED.", wires=[]),
    node("n0000030", "inject", 170, 840, name="PAUSE live", props=[dict(p="payload"), dict(p="topic", vt="str")], repeat="", crontab="",
         once=False, onceDelay=0.1, topic="pause", payload="", payloadType="date", wires=[["n0000032"]]),
    node("n0000031", "inject", 170, 890, name="RESUME live", props=[dict(p="payload"), dict(p="topic", vt="str")], repeat="", crontab="",
         once=False, onceDelay=0.1, topic="resume", payload="", payloadType="date", wires=[["n0000032"]]),
    node("n0000032", "function", 420, 865, name="prepare pause", func=PREP_PAUSE, outputs=1, timeout=0, noerr=0,
         initialize="", finalize="", libs=[], wires=[["n0000033"]]),
    node("n0000033", "http request", 620, 865, name="POST /api/live/pause", method="POST", ret="obj", paytoqs="ignore", url="",
         tls="", persist=False, proxy="", insecureHTTPParser=False, authType="", senderr=False, headers=[], wires=[["n0000034"]]),
    node("n0000034", "debug", 840, 865, name="pause state", active=True, tosidebar=True, console=False, tostatus=False,
         complete="payload", targetType="msg", statusVal="", statusType="auto", wires=[]),
]

out = os.path.join(HERE, "flow.json")
with open(out, "w", encoding="utf-8") as f:
    json.dump(nodes, f, indent=2, ensure_ascii=False)
print("wrote", out, "-", len(nodes), "nodes")
