import json
import csv
import time
import random
import re
import sys
import os
import argparse
import subprocess

from pathlib import Path
from statistics import mean
from concurrent.futures import ThreadPoolExecutor

ROOT = Path(__file__).resolve().parents[1]
MESH = ROOT / "meshnet-lab"

parser = argparse.ArgumentParser()
parser.add_argument("--repeats", type=int, default=1)
args = parser.parse_args()

if args.repeats < 1:
    parser.error("--repeats must be at least 1")

modes = ["babel", "full", "traditional", "adaptive"]

nodes = [format(i, "04x") for i in range(9)]

pairs = [
    (a, b)
    for a in nodes
    for b in nodes
    if a != b
]

random.Random(42).shuffle(pairs)
pairs = pairs[:36]

results = []
packet_results = []


def run(command):

    result = subprocess.run(
        command,
        cwd=MESH,
        capture_output=True,
        text=True
    )

    if result.returncode != 0:

        print(result.stdout)
        print(result.stderr)

        raise RuntimeError(
            "Command failed: " + str(command)
        )

    return result.stdout


def apply_topology(step):

    start = time.perf_counter()

    output = run([
        "./network.py", "apply",
        str(ROOT / f"results/urban_t{step}.json")
    ])

    elapsed = (time.perf_counter() - start) * 1000

    print(output)

    return elapsed


def prepare_nodes():

    output = run([
        sys.executable,
        str(ROOT / "algorithms/prepare_nodes.py")
    ])

    print(output)


def install_routes(mode, step):

    start = time.perf_counter()

    output = run([
        sys.executable,
        str(ROOT / "algorithms/install_routes.py"),
        "--mode", mode,
        "--time", str(step)
    ])

    elapsed = (time.perf_counter() - start) * 1000

    match = re.search(
        r"Updated routes:\s*(\d+)", output
    )

    updated = int(match.group(1)) if match else None

    return elapsed, updated


def get_addresses():

    addresses = {}

    for node in nodes:

        output = run([
            "ip", "-n", "ns-" + node,
            "-j", "-6", "addr", "show",
            "dev", "uplink"
        ])

        for interface in json.loads(output):

            for address in interface["addr_info"]:

                if address["scope"] == "global":
                    addresses[node] = address["local"]

    if len(addresses) != len(nodes):
        raise ValueError("Missing IPv6 addresses")

    return addresses


def ping_pair(source, destination, addresses, start):

    sent_at = (time.perf_counter() - start) * 1000

    result = subprocess.run(
        [
            "ip", "netns", "exec", "ns-" + source,
            "ping", "-6", "-n",
            "-c", "1", "-W", "1",
            addresses[destination]
        ],
        capture_output=True,
        text=True,
        env={**os.environ, "LC_ALL": "C"}
    )

    if result.returncode not in [0, 1]:
        raise RuntimeError(
            "Ping error: " + result.stderr
        )

    match = re.search(
        r"time[=<]\s*([\d.]+)",
        result.stdout
    )

    rtt = float(match.group(1)) if match else None

    return {
        "source": source,
        "destination": destination,
        "sent_at_ms": round(sent_at, 3),
        "success": int(result.returncode == 0),
        "rtt_ms": rtt
    }


def measure(addresses, update_mode=None):

    with ThreadPoolExecutor(max_workers=40) as pool:

        start = time.perf_counter()

        update = None

        if update_mode:

            update = pool.submit(
                install_routes,
                update_mode,
                15
            )

        futures = []

        for i, (source, destination) in enumerate(pairs):

            scheduled = start + i * 0.14

            time.sleep(max(
                0,
                scheduled - time.perf_counter()
            ))

            futures.append(
                pool.submit(
                    ping_pair,
                    source,
                    destination,
                    addresses,
                    start
                )
            )

        packets = [f.result() for f in futures]

        update_ms, updated_routes = (
            update.result() if update
            else (None, None)
        )

    return packets, update_ms, updated_routes


def summarize(packets):

    received = sum(p["success"] for p in packets)

    rtts = [
        p["rtt_ms"]
        for p in packets
        if p["success"] and p["rtt_ms"] is not None
    ]

    return {
        "sent": len(packets),
        "received": received,
        "failed": len(packets) - received,
        "success_pct": round(
            100 * received / len(packets), 2
        ),
        "average_rtt_ms": (
            round(mean(rtts), 4) if rtts else None
        )
    }


def save_results():

    if results:

        with open(
            ROOT / "results/routing_comparison.csv",
            "w"
        ) as f:

            writer = csv.DictWriter(
                f,
                fieldnames=list(results[0])
            )

            writer.writeheader()
            writer.writerows(results)

    if packet_results:

        with open(
            ROOT / "results/packet_measurements.csv",
            "w"
        ) as f:

            writer = csv.DictWriter(
                f,
                fieldnames=list(packet_results[0])
            )

            writer.writeheader()
            writer.writerows(packet_results)

    print("Current results saved")


print("Cleaning previous experimental network")

run(["./software.py", "stop", "babel"])
run(["./network.py", "clear"])


for trial in range(1, args.repeats + 1):

    for mode in modes:

        print("\n==========================")
        print("Trial:", trial)
        print("Mode:", mode)
        print("==========================")

        try:

            apply_topology(0)

            if mode == "babel":

                print(run([
                    "./software.py", "start", "babel"
                ]))

            else:

                prepare_nodes()

                install_routes(mode, 0)

            print("Network warm-up...")
            time.sleep(30)

            addresses = get_addresses()

            before, _, _ = measure(addresses)

            print("Applying mobility scenario...")

            topology_ms = apply_topology(15)

            after, update_ms, updated = measure(
                addresses,
                update_mode=(
                    mode if mode != "babel" else None
                )
            )

            before_stats = summarize(before)
            after_stats = summarize(after)

            result = {
                "trial": trial,
                "mode": mode,

                "before_success_pct":
                    before_stats["success_pct"],

                "after_success_pct":
                    after_stats["success_pct"],

                "after_received":
                    after_stats["received"],

                "after_failed":
                    after_stats["failed"],

                "before_rtt_ms":
                    before_stats["average_rtt_ms"],

                "after_rtt_ms":
                    after_stats["average_rtt_ms"],

                "topology_update_ms":
                    round(topology_ms, 3),

                "route_update_ms":
                    round(update_ms, 3)
                    if update_ms is not None else None,

                "updated_routes": updated
            }

            results.append(result)

            for stage, packets in [
                ("before", before),
                ("after", after)
            ]:

                for packet in packets:

                    packet_results.append({
                        "trial": trial,
                        "mode": mode,
                        "stage": stage,
                        **packet
                    })

            print("\nExperiment Results")
            print("--------------------------")

            for key, value in result.items():
                print(key, ":", value)

            save_results()

        finally:

            if mode == "babel":

                run([
                    "./software.py",
                    "stop",
                    "babel"
                ])

            run(["./network.py", "clear"])


save_results()

print("\nAll Routing Experiments Completed")
print("Total experiments:", len(results))
print("Results saved successfully")